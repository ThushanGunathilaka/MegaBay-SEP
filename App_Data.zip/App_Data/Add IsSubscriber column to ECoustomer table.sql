﻿SELECT * FROM ECustomer;
GO

SELECT ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
       , IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ECustomer'
GO

SELECT CONSTRAINT_NAME
FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE
WHERE TABLE_NAME = 'ECustomer'
GO

SELECT name, type_desc, is_unique, is_primary_key
FROM sys.indexes
WHERE [object_id] = OBJECT_ID('dbo.ECustomer')
GO

-- Adding New Column to check if user subscribed to news letters
ALTER TABLE ECustomer
ADD IsSubscriber Varchar(6) NOT NULL DEFAULT('false');
GO
-- Updating it with Default not subscribed option ('false')
UPDATE ECustomer
SET IsSubscriber = 'false';
GO

-- Adding New Column to get view count of a product
--ALTER TABLE Product
--ADD IsSubscriber Varchar(10) NOT NULL DEFAULT('0');
--GO
-- Set default view count for currently added products
--UPDATE Product
--SET IsSubscriber = '0';
--GO

SELECT * FROM ECustomer;
GO

SELECT ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
       , IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ECustomer'

SELECT CONSTRAINT_NAME
FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE
WHERE TABLE_NAME = 'ECustomer'

SELECT name, type_desc, is_unique, is_primary_key
FROM sys.indexes
WHERE [object_id] = OBJECT_ID('dbo.ECustomer')