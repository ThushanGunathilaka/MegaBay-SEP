﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    ReportMethods reportMethods = new ReportMethods();
    DataTable productsSellByMe_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["CusID"] == null)
        {
            Response.Redirect("Login.aspx");
        }        
        int CusID = Convert.ToInt32(Session["CusID"].ToString());
        if (!IsPostBack)
        {
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Reports/ReportGetProducts.rdlc");
            productsSellByMe_dt = reportMethods.GetMyProducts(CusID);
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DataSetGetProducts";
            source1.Value = productsSellByMe_dt;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(source1);
            ReportViewer1.LocalReport.Refresh();
           
        }
    }
}