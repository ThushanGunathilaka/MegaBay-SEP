﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Diagnostics;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = "0";
        Label4.Text = "0";
        Label5.Text = "0";

        //int prId = (int)Session["pid_fdb"];
        int prId = 4; /////

        DataSet ds = dba.viewProdFeedbak(prId);
        int rowCount = ds.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount; i++)
        {
            int rate = (int)ds.Tables[0].Rows[i][0];
            if (rate == 1)
                Label3.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 2)
                Label4.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 3)
                Label5.Text = ds.Tables[0].Rows[i][1].ToString();
        }


        DataSet ds2 = dba.getProdFeed(prId);
        /*int rowCount2 = ds.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount2; i++)
        {
            if (ds2.Tables[0].Rows[i][0].ToString() == "1")
                ds2.Tables[0].Rows[i][0] = 4;

            else if (ds2.Tables[0].Rows[i][0].ToString() == "2")
                ds2.Tables[0].Rows[i][0] = 5;

            else if (ds2.Tables[0].Rows[i][0].ToString() == "3")
                ds2.Tables[0].Rows[i][0] = 6;
        }*/
        GridView1.DataSource = ds2.Tables[0].DefaultView;
        GridView1.DataBind();
        
        int c = GridView1.Rows.Count;
        for (int i = 0; i < c; i++)
        {
            if (GridView1.Rows[i].Cells[0].Text == "1")
                GridView1.Rows[i].Cells[0].Text = "Positive";

            else if (GridView1.Rows[i].Cells[0].Text == "2")
                GridView1.Rows[i].Cells[0].Text = "Neutral";

            else if (GridView1.Rows[i].Cells[0].Text == "3")
                GridView1.Rows[i].Cells[0].Text ="Negative";
        }
    }
  
}