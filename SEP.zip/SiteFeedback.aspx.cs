﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Diagnostics;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        Label10.Text = "0";
        Label12.Text = "0";
        Label15.Text = "0";
        Label17.Text = "0";
        Label20.Text = "0";


        DataSet ds = dba.viewSiteFeedbak();
        int rowCount = ds.Tables[0].Rows.Count;
        //int qtyInStock = (int)ds.Tables[0].Rows[2][1];
        //Debug.WriteLine(qtyInStock);
        for (int i = 0; i < rowCount; i++)
        {
            int rate = (int)ds.Tables[0].Rows[i][0];
            if (rate == 1)
                Label10.Text = ds.Tables[0].Rows[i][1].ToString();
            else if ( rate==2)
                Label12.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 3)
                Label15.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 4)
                Label17.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 5)
                Label19.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 6)
                Label20.Text = ds.Tables[0].Rows[i][1].ToString();
            

        }
    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {     

        Feedback feedB = new Feedback();

        if (RadioButton1.Checked)
            feedB.Rating = 1;
        else if (RadioButton2.Checked)
            feedB.Rating = 2;
        else if (RadioButton3.Checked)
            feedB.Rating = 3;
        else if (RadioButton4.Checked)
            feedB.Rating = 4;
        else if (RadioButton5.Checked)
            feedB.Rating = 5;
        else if (RadioButton6.Checked)
            feedB.Rating = 6;
        else
            feedB.Rating = 0;

        
        feedB.FeedBack = TextBox1.Text;

        if (feedB.FeedBack == "" || feedB.Rating == 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter all \")</SCRIPT>");
            ////TextBox1.Text = "hhh";

            //if(feedB.Rating == 1)
              //  RadioButton1.
        }
        else
        {
            if (Session["id"] == null)
                feedB.User = null;
            else
                feedB.User = (string)Session["id"];

            //db_access dba = new db_access();
            if (dba.insertFeedbak(feedB) >= 0)
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Feedback successfully added.\")</SCRIPT>");
            else
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error ! \")</SCRIPT>");

            TextBox1.Text = "";
            RadioButton1.Checked = false;
            RadioButton2.Checked = false;
            RadioButton3.Checked = false;
            RadioButton4.Checked = false;
            RadioButton5.Checked = false;
            RadioButton6.Checked = false;
        }

    }
    protected void RadioButton1_CheckedChanged1(object sender, EventArgs e)
    {
       
    }
}