﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        //Page load first time
        if (!Page.IsPostBack)
        {
            //fill the gridview with not expire promotions products
            dba.BindGridViewListPromotions(GridView1);
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["promoClick"] = pid;
        Response.Redirect("ViewProductPromotion.aspx");
    }
}