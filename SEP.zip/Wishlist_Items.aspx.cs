﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{

    db_access dba = new db_access();
    int cusid = 2; 

    protected void Page_Load(object sender, EventArgs e)
    {
        String usersID = Session["CusID"].ToString();
        cusid = Convert.ToInt32((usersID == null || usersID.CompareTo("") == 0) ? "-1" : usersID);
        //Page load first time 
        if (!Page.IsPostBack)
        {
            //get the count of names in the list  
            DataSet ds1 = dba.getWishListnames(cusid);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                Label1.Text = "You dont have any lists created";
                Label1.Visible = true;
            }
            else
            {
                Label1.Visible = false;
                for (int i = 0; i < rowCount; i++)
                {
                    //Add names to the dropdown list
                    DropDownList1.Items.Add(ds1.Tables[0].Rows[i][0].ToString());
                }
            }
        }
    }

    
    protected void Button1_Click(object sender, EventArgs e)
    {
        //get the dropdown list selected item and display items
        String selectedList = DropDownList1.SelectedItem.ToString();
        dba.BindGridViewList(GridView1, selectedList, cusid);
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        
        int count = 0;

        //go to the each in the gridview
        foreach (GridViewRow row in GridView1.Rows)
        {
            //check each row is a data row
            if (row.RowType == DataControlRowType.DataRow)
            {
                //find the checkbox1 and check cell[0] is checked or not
                CheckBox chkRow = (row.Cells[0].FindControl("CheckBox1") as CheckBox);
                if (chkRow.Checked)
                {
                    //get the cell[1] is having label2 with id
                    string id = (row.Cells[1].FindControl("Label2") as Label).Text;
                    //delete product from wishlistItems table and form the listname in the wishlist table 
                    dba.removeWishItem(DropDownList1.SelectedItem.ToString(), id, cusid);
                    Button1_Click(this, e);
                    count++;
                }
            }           
        }
        if (count == 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Select valid Item to Remove. \")</SCRIPT>");
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Items successfully Removed \")</SCRIPT>");
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}