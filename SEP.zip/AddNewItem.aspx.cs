﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       if (catdrop.Text == "Fashion")
        {
            subcatdrop.Items.Add("Jewelry & Watches");
            subcatdrop.Items.Add("Handbags & Accessories");
            subcatdrop.Items.Add("Health & Beauty");
            subcatdrop.Items.Add("Shoes");
            subcatdrop.Items.Add("Sales & Events");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }
        else if (catdrop.Text == "Electronics")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Add("Cell Phones & Accessories");
            subcatdrop.Items.Add("Cameras & Photo");
            subcatdrop.Items.Add("Computers & Tablets");
            subcatdrop.Items.Add("Car audio,video & GPS");
            subcatdrop.Items.Add("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }

        else if (catdrop.Text == "Collectibles & Art")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Antiques");
            subcatdrop.Items.Add("Sports Memorabilia");
            subcatdrop.Items.Add("Entertainment Memorabilia");
            subcatdrop.Items.Add("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");

        }
        else if (catdrop.Text == "Home & Garden")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Home Decor");
            subcatdrop.Items.Add("Crafts");
            subcatdrop.Items.Add("Kitchen, Dining & Bar");
            subcatdrop.Items.Add("Yard, Garden & Outdoor");
            subcatdrop.Items.Add("Baby");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");
            subcatdrop.Items.Remove("Motors");

        }
        else
        {
            subcatdrop.Items.Add("motors");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

        }
      if (Session["CusID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      try
        {
            if (FileUpload1.PostedFile.FileName != "")
            {
                byte[] image;
                Stream s = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(s);
                image = br.ReadBytes((Int32)s.Length);

                Item item = new Item();
                item.CusID1 = Convert.ToInt32(Session["CusID"].ToString());
                item.Pname = (TextBox2.Text);
                item.Condition = (TextBox3.Text);
                item.Company1 = (TextBox4.Text);
                item.Image = (image);
                item.Price = double.Parse(pricetxt.Text);
                item.Modle = modletxt.Text;
                item.Description = descrtxt.Text;
                item.Priority = prioritytxt.Text;
                item.Category = catdrop.SelectedItem.ToString();
                item.SubCategory = subcatdrop.SelectedItem.ToString();
                item.Availability = availdrop.SelectedItem.ToString();
                item.Height = 0;
                item.Width = 0;
                item.Depth = 0;
                item.Size = heighttxt.Text;
                item.Colour = widthtxt.Text;
                item.Material = depthtxt.Text;
                
                item.AddedDate = DateTime.Now;
                item.ExpDate = DateTime.Today;

                Insert_Item InsItem = new Insert_Item();
                InsItem.insertItem(item);
                Label6.Text = "Successfully inserted!!!";

                //BindGrid();
            }
        }
        catch (Exception ex)
        {
            Label20.Text = "Error occured while inserting product,Please check all fields...";
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Image2.ImageUrl = "~/Handler.ashx?PID=3";
        Image2.Width = 100;
        Image2.Height = 100;
        Label20.Text = "hi";
    }

    //void BindGrid()
    //{
    //    string EmarketingConnectionString = @"Data Source=RAVI\SQLEXPRESS;Initial Catalog=Eportal;Integrated Security=True";
    //    SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);
    //    SqlDataAdapter da = new SqlDataAdapter("select PID,pname,condition,company,Image from Product", conn1);
    //    DataSet ds = new DataSet();
    //    da.Fill(ds);
    //    GridView2.DataSource = ds;
    //    GridView2.DataBind();

    //}

     protected void catdrop_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Label6.Text = "hi";
        string selectedValue = catdrop.SelectedItem.ToString();

        //Label6.Text = selectedValue;
        if (selectedValue == "Fashion")
        {
            subcatdrop.Items.Add("Jewelry & Watches");
            subcatdrop.Items.Add("Handbags & Accessories");
            subcatdrop.Items.Add("Health & Beauty");
            subcatdrop.Items.Add("Shoes");
            subcatdrop.Items.Add("Sales & Events");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }
        else if (selectedValue == "Electronics")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Add("Cell Phones & Accessories");
            subcatdrop.Items.Add("Cameras & Photo");
            subcatdrop.Items.Add("Computers & Tablets");
            subcatdrop.Items.Add("Car audio,video & GPS");
            subcatdrop.Items.Add("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }

        else if (selectedValue == "Collectibles & Art")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Antiques");
            subcatdrop.Items.Add("Sports Memorabilia");
            subcatdrop.Items.Add("Entertainment Memorabilia");
            subcatdrop.Items.Add("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");

        }
        else if (selectedValue == "Home & Garden")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Home Decor");
            subcatdrop.Items.Add("Crafts");
            subcatdrop.Items.Add("Kitchen, Dining & Bar");
            subcatdrop.Items.Add("Yard, Garden & Outdoor");
            subcatdrop.Items.Add("Baby");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");
            subcatdrop.Items.Remove("Motors");

        }
        else
        {
            subcatdrop.Items.Add("motors");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

        }
}

    protected void Button3_Click(object sender, EventArgs e)
    {
        //string username = TextBox5.Text;
        //string pwd = TextBox6.Text;
        //Login1 l = new Login1(username, pwd);
        //Label8.Text= Login1.user.uid.ToString();
        
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Image2.ImageUrl = "~/Handler.ashx?PID=3";
        Image2.Width = 100;
        Image2.Height = 100;
    }
protected void Button2_Click1(object sender, EventArgs e)
    {
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        pricetxt.Text = null;
        modletxt.Text = "";
        descrtxt.Text = "";
        prioritytxt.Text = "";
        heighttxt.Text = "";
        widthtxt.Text = "";
        depthtxt.Text = "";
        Label20.Text = "";
        Label6.Text = "";
    }
}















