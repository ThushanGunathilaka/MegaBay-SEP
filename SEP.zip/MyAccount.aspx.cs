﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class MyAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
                
        ClientScript.RegisterStartupScript(this.GetType(), "myalert", " document.getElementById(\"<%= buttonlogin.ClientID %>\").value = \"Logout\"; $('#accountlink').show(); $('#a').show();$('#b').show();$('#d').show();", false);

    }
    public void asp_click(object sender, EventArgs e)
    {
        Session["New"] = null;
        Response.Redirect("Home.aspx");

        
    }
}