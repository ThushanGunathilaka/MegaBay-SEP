﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    ReportMethods reportMethods = new ReportMethods();
    DataTable ProductsInPriceRange_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        decimal lb = decimal.Parse(txtLb.Text);
        decimal ub = decimal.Parse(txtUb.Text);
        if (!IsPostBack)
        {
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsInPriceRangeToday.rdlc");
            ProductsInPriceRange_dt = reportMethods.GetProductsByPriceRange(ub, lb);
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsInPriceRange";
            source1.Value = ProductsInPriceRange_dt;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(source1);
            ReportViewer1.LocalReport.Refresh();

        }
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        decimal lb = decimal.Parse(txtLb.Text);
        decimal ub = decimal.Parse(txtUb.Text);
      
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsInPriceRangeToday.rdlc");
            ProductsInPriceRange_dt = reportMethods.GetProductsByPriceRange(ub,lb);
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsInPriceRange";
            source1.Value = ProductsInPriceRange_dt;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(source1);
            ReportViewer1.LocalReport.Refresh();
        
    }
}