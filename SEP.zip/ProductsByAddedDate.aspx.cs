﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    //Make instance from ReportMethods class
    ReportMethods reportMethods = new ReportMethods();
    DataTable ProductsBySelectedDate_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
       // get selected date
        DateTime date = CalendarAddedDate.SelectedDate;
        //Load the report
        if (!IsPostBack)
        {
            rpvProductsByAddedDate.ProcessingMode = ProcessingMode.Local;
            rpvProductsByAddedDate.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsByRegisteredDateRpt.rdlc");
            ProductsBySelectedDate_dt = reportMethods.GetProductsByAddedDate(date);
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsByRegisterdDate";
            source1.Value = ProductsBySelectedDate_dt;
            rpvProductsByAddedDate.LocalReport.DataSources.Clear();
            rpvProductsByAddedDate.LocalReport.DataSources.Add(source1);
            rpvProductsByAddedDate.LocalReport.Refresh();

        }
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        //Load the report
            DateTime date = CalendarAddedDate.SelectedDate;        
            rpvProductsByAddedDate.ProcessingMode = ProcessingMode.Local;
            rpvProductsByAddedDate.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsByRegisteredDateRpt.rdlc");
            ProductsBySelectedDate_dt = reportMethods.GetProductsByAddedDate(date);
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsByRegisterdDate";
            source1.Value = ProductsBySelectedDate_dt;
            rpvProductsByAddedDate.LocalReport.DataSources.Clear();
            rpvProductsByAddedDate.LocalReport.DataSources.Add(source1);
            rpvProductsByAddedDate.LocalReport.Refresh();

        
    }
    protected void CalendarAddedDate_SelectionChanged(object sender, EventArgs e)
    {
        //Load the report
        DateTime date = CalendarAddedDate.SelectedDate;
        rpvProductsByAddedDate.ProcessingMode = ProcessingMode.Local;
        rpvProductsByAddedDate.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsByRegisteredDateRpt.rdlc");
        ProductsBySelectedDate_dt = reportMethods.GetProductsByAddedDate(date);
        ReportDataSource source1 = new ReportDataSource();
        source1.Name = "DsProductsByRegisterdDate";
        source1.Value = ProductsBySelectedDate_dt;
        rpvProductsByAddedDate.LocalReport.DataSources.Clear();
        rpvProductsByAddedDate.LocalReport.DataSources.Add(source1);
        rpvProductsByAddedDate.LocalReport.Refresh();
    }
}