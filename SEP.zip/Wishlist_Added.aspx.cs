﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    String selectedList;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)  
        {
            LoadData();
        }
    }

    private void LoadData()
    {
        int cusId;

        //cusId = (int)Session["uid"];        
        cusId = 2;//////
        DataSet ds = dba.getWishListNames(cusId);
        int rowCount = ds.Tables[0].Rows.Count;

        if (rowCount == 0)
        {
            Label2.Text = "You dont have any lists created";
            //DropDownList1.Visible = false;
            Label2.Visible = true;
        }
        else
        {
            //DropDownList1.Visible = true;
            Label2.Visible = false;
            for (int i = 0; i < rowCount; i++)
            {
                DropDownList1.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }

        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    //    int cusId;

    //    //cusId = (int)Session["uid"];        
    //    cusId = 2;//////

    //    String listName = DropDownList1.SelectedItem.ToString();
    //    dba.BindGridViewList(GridView1,listName,cusId.ToString());
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int cusId;

        //cusId = (int)Session["uid"];        
        cusId = 2;//////

        selectedList = DropDownList1.SelectedItem.ToString();
        dba.BindGridViewList(GridView1, selectedList, cusId);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int cusId;

        //cusId = (int)Session["uid"];        
        cusId = 2;//////
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chkRow = (row.Cells[0].FindControl("CheckBox1") as CheckBox);
                if (chkRow.Checked)
                {
                    string id = (row.Cells[1].FindControl("Label5") as Label).Text;
                    
                    dba.removeWishItem(DropDownList1.SelectedItem.ToString(), id, cusId);
                    System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Item successfully Removed \")</SCRIPT>");
                    Button1_Click(this, e);
                    //GridView1.Item.Clear();
                    //DropDownList1.Text = "";
                    //Response.Redirect("~/Wishlist_Added.aspx");
                    //Page.Response.Redirect(Page.Request.Url.ToString(), true);

                }
            }
            
        }
    
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}