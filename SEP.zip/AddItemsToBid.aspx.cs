﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.PostedFile.FileName != "")
            {
                byte[] image;
                Stream s = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(s);
                image = br.ReadBytes((Int32)s.Length);

                BidItem item = new BidItem();
                item.BItemName = TextBox2.Text;
                item.BItemPrice = decimal.Parse(pricetxt.Text);
                item.BDescription = TextBox1.Text;
                item.Image = image;
                item.BEndDate = Calendar1.SelectedDate;
                Bidding bidding = new Bidding();
                bidding.insertItem(item);
                Label20.Text = "Successfully inserted!!!";

                //BindGrid();
            }
        }
        catch (SqlException exc)
        {
            Label4.Text = "Error occured while inserting product to database";
        }
        catch (HttpException)
        {
            Label4.Text = "Error occured while uploading file";
        }
        catch (Exception ex)
        {
            Label4.Text = "Error occured while inserting product,Please check all fields...";
        }
    }
}