﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        //Page load first time
        if (!Page.IsPostBack)
        {
            //fill the gridview with not expire deals products
            dba.BindGridViewListDeals(GridView1);    
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["dealClick"] = pid;
        Response.Redirect("view_product.aspx");
    }

    //public void testFn(String c)
    //{
    //    
    //}
}