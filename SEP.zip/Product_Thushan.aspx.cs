﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Product_Thushan : System.Web.UI.Page
{
    protected List<Item> items;
    protected Item item;
    protected string addedDate = "";
    protected int UId = -1;
    protected int PId = -1;
    db_access dba = new db_access();
    Star1 st = new Star1();
    protected string productIDFinal = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            
            String viewCount = "";
            productIDFinal = Request.QueryString["product"];
            //if (v!=null && v.Length > 6)
           // {
                productIDFinal = productIDFinal.Substring(7);
            String usersID = Session["New"].ToString();
            UId = int.Parse((usersID != null && usersID.CompareTo("admin")==0)?"1":"-1");
            PId = int.Parse((productIDFinal == null) ? "-1" : productIDFinal);
                     // }



                     SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            SqlCommand cmd = new System.Data.SqlClient.SqlCommand("select * from product where PID = \'"+productIDFinal+"\'", con);

            if (con.State == System.Data.ConnectionState.Closed)
            {
                con.Open();
            }

            items = new List<Item>();

            try
            {
                System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        item = new Item();

                        byte[] bytes = new byte[0];
                        try
                        {

                            item.Pname = dr["pname"].ToString().Trim();

                            bytes = (byte[])dr["Image"];
                            item.Image = bytes;
                        
                            item.Price = double.Parse(dr["Price"].ToString());

                            item.Description = dr["Description"].ToString();

                            item.Condition = dr["condition"].ToString();

                            item.Company1 = dr["company"].ToString();

                            item.Modle = dr["modle"].ToString();

                            item.CusID1 = int.Parse(dr["CusID"].ToString().Trim());

                            addedDate = dr["added_date"].ToString();

                            viewCount = dr["viewCount"].ToString();

                            items.Add(item);
                        }
                        catch (Exception e2) {}
                    }   //while
                }   //if
            }
            catch (Exception vr) { }

            int iviewCount = int.Parse(viewCount)+1;
            //SqlCommand insertCommand = new SqlCommand("UPDATE Product SET viewCount = '"+ iviewCount.ToString() + "' WHERE PID="+ v + ";", con);
            //insertCommand.ExecuteNonQuery();
           // con.Close();

            using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
            {
                String user = Session["New"].ToString();
                String query = "UPDATE Product SET viewCount = @viewCount WHERE PID = @PID;";
                if (user != null && user.Trim().CompareTo("") != 0)
                {
                    query += "INSERT INTO Recent (username,PID) VALUES (@user,@PID);";
                }
                else {
                    List<string> recent = (List<string>)Session["Recent"];
                    if (recent == null || recent.Count < 1)
                    {
                        recent = new List<string>();
                    }
                    recent.Add(productIDFinal);
                    Session["Recent"] = recent;
                    serializeToJSON(recent);
                }
             
                using (SqlCommand cmdx = new SqlCommand(query, conx))
                {
                    cmdx.CommandType = CommandType.Text;
                    cmdx.Parameters.AddWithValue("@viewCount", iviewCount.ToString());
                    cmdx.Parameters.AddWithValue("@PID", productIDFinal);
                    if (user != null && user.Trim().CompareTo("") != 0)
                    {
                        cmdx.Parameters.AddWithValue("@user", user);
                    }
                    conx.Open();
                    int rowsAffected = cmdx.ExecuteNonQuery();
                    conx.Close();
                }
            }




            if (items[0].Image != null)
            {
              /*  String img = "";
                img = "data:image/Png;base64" + Convert.ToBase64String(CreateThumbnail(items[0].Image, 200));

                string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\eportal";

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string thumb = new String(items[0].Pname.Where(char.IsLetter).ToArray()).ToLower() + ".Png";  // set thumbnail name
                string thumbloc = @path + @"\thumb" + new String(items[0].Pname.Where(char.IsLetter).ToArray()).ToLower() + ".Png";    // thumbnail absolute path

                if (!File.Exists(thumbloc))
                {
                    File.WriteAllBytes(thumbloc, CreateThumbnail(items[0].Image, 800));
                }
                */
                int link = Request.Url.Port;   // to show thumbnails from .aspx qstring
                string host = Request.Url.Host;

                string imagelink = "<img src=\"" + @"http://" + @host + @":" + @link.ToString() + @"/getImageFromDB.ashx?param=" + productIDFinal + "\" width=\"200\" height=\"180\" u=\"image\" class=\"img-responsive\" data-u=\"image\" alt=\"" + items[0].Pname + "\" />";
                string linkonly = @"http://" + @host + @":" + @link.ToString() + @"/getImageFromDB.ashx?param=" + productIDFinal + "\"";


                detailspage.Controls.Add(new LiteralControl(appenddata(imagelink, linkonly, items[0].Pname, items[0].Price.ToString(), items[0].Condition, items[0].Company1, items[0].Modle, items[0].Description, items[0].CusID1.ToString(), addedDate)));


                //String jsonItemData = Session["Recents"].ToString();
                //String[] recentItems = new String[] { };
                //recentItems = (string[])new JavaScriptSerializer().DeserializeObject(jsonItemData); ;

                //int pointer = (int)Session["pointer"];
                //if (recentItems != null && recentItems.Length > 0)
                //{
                //    if (!recentItems.Any(str => str.CompareTo(v) == 0))
                //    {
                //        recentItems[pointer] = v;


                //        Session["Recents"] = new JavaScriptSerializer().Serialize(recentItems);
                //        if (pointer >= 20)
                //        {
                //            pointer = 0;
                //        }
                //        else
                //        {
                //            pointer++;
                //        }
                //        Session["pointer"] = pointer;
                //    }
                //}
                //else
                //{
                ////    string[] recems = new string[] {};
                // //   recems[0] = v;
                // //   Session["Recents"] = JavascriptWrapper.Serialize(recems);
                //  //  Session["pointer"] = 1;
                //}
                ////String usernameModal = Session["New"].ToString();
                //// if (usernameModal != null && usernameModal.CompareTo("") == 0) {

                //// }


            }
          
        }catch(Exception er){
            Response.Redirect("Content_Thushan.aspx");
    
        }

        //----------viraji-------------
        st.PID1 = PId;
        st.CusID1 = UId;

        //gridwiew fill with given product
        dba.BindGridpro_ratings(GridView1, st.PID1);

        //clear the lables
        Label4.Text = "0";
        Label5.Text = "0";
        Label6.Text = "0";
        Label7.Text = "0";
        Label8.Text = "0";

        //get single user rate and fill stars with color
        DataSet ds1 = dba.viewStarRate(st.PID1, st.CusID1);
        int rowCount1 = ds1.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount1; i++)
        {
            int rate = (int)ds1.Tables[0].Rows[i][0];
            if (rate == 1)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 2)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 3)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
                ImageButton3.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 4)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
                ImageButton3.ImageUrl = "~/images/Star_2.png";
                ImageButton4.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 5)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
                ImageButton3.ImageUrl = "~/images/Star_2.png";
                ImageButton4.ImageUrl = "~/images/Star_2.png";
                ImageButton5.ImageUrl = "~/images/Star_2.png";
            }
        }


        //view the given ratings 
        DataSet ds = dba.viewStarRatings();
        int rowCount = ds.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount; i++)
        {
            int rate = (int)ds.Tables[0].Rows[i][0];
            if (rate == 1)
            {
                Label4.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 2)
            {
                Label5.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 3)
            {
                Label6.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 4)
            {
                Label7.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 5)
            {
                Label8.Text = ds.Tables[0].Rows[i][1].ToString();
            }
        }


        //fill the gridview with given product
        dba.BindGridpro_comment(GridView3, PId);

        //lable5 is clear
        Label5.Text = "0";

        //get the likes count and display like count in the lable
        DataSet ds11 = dba.getProLikes(PId);
        int rowCount11 = ds11.Tables[0].Rows.Count;
        Label5.Text = rowCount11.ToString();

        //paticulr user with paticular product get that and color the like button
        DataSet ds111 = dba.getProLikes_color(PId, UId);
        int rowCount111 = ds111.Tables[0].Rows.Count;

        if (rowCount111 >= 1)
        {
            ImageButton6.ImageUrl = "~/images/like2.JPG";
        }
        else
        {
            ImageButton6.ImageUrl = "~/images/like1.JPG";
        }

        //get the comments and display comments on gridview
        DataSet ds2 = dba.viewProComment(PId);
        GridView2.DataSource = ds2.Tables[0].DefaultView;
        GridView2.DataBind();

        //check pid and uid and get comment and dipaly "delete my comment" button
        DataSet ds3 = dba.displaycommbutton(PId, UId);
        int row = ds3.Tables[0].Rows.Count;

        if (row >= 1)
        {
            Button2.Visible = true;
        }
        else
        {
            Button2.Visible = false;
        }
    }

    private string appenddata(string imagelink, string linkonly,string productName,string price,string condition,string brand,string model,string description,string seller,string addeddate)
    {
        String data = "" +
            "<section>" +
                "<div class=\"container\">" +
                    "<div class=\"row\">" +
                        "<div class=\"col-sm-9 padding-left\">" +
                            "<div class=\"product-details\"><!--product-details-->" +
                                "<div class=\"col-sm-4\">" +
                                    "<div class=\"view-product\">" +
                                        "<a href=\""+
                                        linkonly+
                                        //"images/product-details/1.jpg"+
                                        "\" data-lightbox=\"image-1\" data-title=\""+
                                        productName+
                                        //"i really want by radostina420"+
                                        "\">" +
                                            imagelink +
                                          //  "<img u=\"image\" data-u=\"image\" src=\"images/product-details/1.jpg\" />" +
                                        "</a>" +
                                    "</div>" +
                                "</div>" +
                                "<div class=\"col-sm-5\">" +
                                    "<div class=\"product-information\"><!--/product-information-->" +
                                        "<h2>"+
                                        productName+
        //"Anne Klein Sleeveless Colorblock Scuba"+
            "</h2>" +
                                        "<span>" +
                                            "<span>" + "Rs. " +
                                            price +
       // "LKR. 59"+
            "<br><br></span>" +
                                                "<label>Quantity : </label>" +
                                                "<input type=\"text\" value=\"3\" />" +
                                               
                                                "<i class=\"fa fa-shopping-cart\">&nbsp;<a href=\"ViewCart.aspx\">Add to Cart</a></i>"+
                                                  "<br/><i class=\"fa fa-shopping-cart\">&nbsp;<a href=\"Wishlist.aspx?product=" + productIDFinal+ "\">Add to WishList</a></i>" +
                                            "</span>" +
                                            "<p><b>Availability : </b> In Stock</p>" +
                                            "<p><b>Condition : </b> "+
                                            condition+
                                            //"New"+
                                            "</p>" +
                                            "<p><b>Brand : </b> "+
                                            brand+
                                            //"E-SHOPPER"+
                                            "</p>" +
                                            "<p><b>Model : </b> " +
                                            model +
            //"E-SHOPPER"+
                                            "</p>" +
                                    "</div><!--/product-information-->" +
                                "</div>" +
                            "</div><!--/product-details-->" +
                            "<div class=\"category-tab shop-details-tab\"><!--category-tab-->" +
                                "<div class=\"col-sm-12\">" +
                                        "<ul class=\"nav nav-tabs\">" +
                                            "<li class=\"active\"><a href=\"#reviews\" data-toggle=\"tab\">"+
                                            
                                            "Description"+
                                            "</a></li>" +
                                        "</ul>" +
                                    "</div>" +
                                "<div class=\"tab-content\">" +
                                        "<div class=\"tab-pane fade active in\" id=\"reviews\" >" +
                                            "<div class=\"col-sm-12\">" +
                                                "<ul>" +
                                                    "<li><a href=\"#\"><i class=\"fa fa-user\"></i>"+
                                                    seller+
                                                    //"EUGEN"+
                                                    "</a></li>" +
                                                    "<li><a href=\"#\"><i class=\"fa fa-calendar-o\"></i>"+
                                                    addeddate+
                                                    //"31 DEC 2014"+
                                                    "</a></li>" +
                                                "</ul>" +
                                                "<p>"+
                                                description +
                                                //"description"+
                                                "</p>" +
                                            "</div>" +
                                        "</div>" +
                                    "</div>" +
                            "</div><!--/category-tab-->" +
                        "</div>" +
                    "</div>" +
                "</div>" +
            "</section>";
        return data;
    }
    /*
    // Create a thumbnail in byte array format from the image encoded in the passed byte array.  
    public static byte[] CreateThumbnail(byte[] PassedImage, int LargestSide)
    {
        byte[] ReturnedThumbnail;

        using (MemoryStream StartMemoryStream = new MemoryStream(), NewMemoryStream = new MemoryStream())
        {
            // write the string to the stream  
            StartMemoryStream.Write(PassedImage, 0, PassedImage.Length);

            // create the start Bitmap from the MemoryStream that contains the image  
            Bitmap startBitmap = new Bitmap(StartMemoryStream);

            // set thumbnail height and width proportional to the original image.  
            int newHeight;
            int newWidth;
            double HW_ratio;

            if (startBitmap.Height > startBitmap.Width)
            {
                newHeight = LargestSide;
                HW_ratio = (double)((double)LargestSide / (double)startBitmap.Height);
                newWidth = (int)(HW_ratio * (double)startBitmap.Width);
            }
            else
            {
                newWidth = LargestSide;
                HW_ratio = (double)((double)LargestSide / (double)startBitmap.Width);
                newHeight = (int)(HW_ratio * (double)startBitmap.Height);
            }

            // create a new Bitmap with dimensions for the thumbnail.  
            Bitmap newBitmap = new Bitmap(newWidth, newHeight);

            // Copy the image from the START Bitmap into the NEW Bitmap.  
            // This will create a thumnail size of the same image.  
            newBitmap = ResizeImage(startBitmap, newWidth, newHeight);

            // Save this image to the specified stream in the specified format.  
            newBitmap.Save(NewMemoryStream, System.Drawing.Imaging.ImageFormat.Png);

            // Fill the byte[] for the thumbnail from the new MemoryStream.  
            ReturnedThumbnail = NewMemoryStream.ToArray();
        }

        // return the resized image as a string of bytes.  
        return ReturnedThumbnail;
    }

    private static Bitmap ResizeImage(Bitmap image, int width, int height)
    {
        Bitmap resizedImage = new Bitmap(width, height);

        using (Graphics gfx = Graphics.FromImage(resizedImage))
        {
            gfx.DrawImage(image, new Rectangle(0, 0, width, height), new Rectangle(0, 0, image.Width, image.Height), GraphicsUnit.Pixel);
        }

        return resizedImage;
    } 
    */

    private void serializeToJSON(List<string> list)
    {
        var serializer = new DataSerializer(new JSONSerializerAdapter());
        String serializedString = serializer.Render(list);
        Session["RecentSerialized"] = serializedString;

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public void updatestar(int rate)
    {
        st.PID1 = int.Parse(productIDFinal.ToString());
        st.CusID1 = int.Parse(Session["New"].ToString());

        //clear the stars
        ImageButton1.ImageUrl = "~/images/Star_1.png";
        ImageButton2.ImageUrl = "~/images/Star_1.png";
        ImageButton3.ImageUrl = "~/images/Star_1.png";
        ImageButton4.ImageUrl = "~/images/Star_1.png";
        ImageButton5.ImageUrl = "~/images/Star_1.png";


        //update the rates
        dba.updatestardb(st.PID1, st.CusID1, rate);

        if (rate == 1)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 2)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 3)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 4)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 5)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
            ImageButton5.ImageUrl = "~/images/Star_2.png";
        }

    }

    public void inseartstar(int rate)
    {
        st.PID1 = PId;
        st.CusID1 = UId; 
        //clear the stars
        ImageButton1.ImageUrl = "~/images/Star_1.png";
        ImageButton2.ImageUrl = "~/images/Star_1.png";
        ImageButton3.ImageUrl = "~/images/Star_1.png";
        ImageButton4.ImageUrl = "~/images/Star_1.png";
        ImageButton5.ImageUrl = "~/images/Star_1.png";


        //inseart the rates
        dba.insertstar1(st.PID1, st.CusID1, rate);

        if (rate == 1)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 2)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 3)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 4)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 5)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
            ImageButton5.ImageUrl = "~/images/Star_2.png";
        }

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = UId;
        st.CusID1 = PId;
        st.Rate1 = 1;
        //int rate = 1;

        if (st.Rate1 == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            //check the rate is given by uer and product
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;
            //Debug.WriteLine(rowCount);

            if (rowCount == 0)
            {
                inseartstar(st.Rate1);
            }
            else if (rowCount >= 1)
            {
                updatestar(st.Rate1);
            }
        }
        Page_Load(this, e);
    }


    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = UId;
        st.CusID1 = PId;
        //st.Rate1 = 1;

        int rate = 2;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = UId;
        st.CusID1 = PId;

        int rate = 3;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
    }


    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = UId;
        st.CusID1 = PId;

        int rate = 4;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
    }


    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = UId;
        st.CusID1 = PId;

        int rate = 5;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        Comment com = new Comment();

        //set textbox value to the column called Comment_des 
        com.Comment_des = TextBox1.Text;

        if (com.Comment_des == " ")
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a comment \")</SCRIPT>");
        }
        else
        {
            com.UId = UId;
            com.PId = PId;

            if (dba.insertcomment(com) >= 0)
            {
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Comment successfully added. \")</SCRIPT>");
                //diplay the "delete my comment" button
                Button2.Visible = true;
            }
            else
            {
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error ! \")</SCRIPT>");
            }
        }
        TextBox1.Text = "";
        Page_Load(this, e);
    }


    protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
    {
        Like1 li = new Like1();

        li.Count = 1;
        li.UId = UId;
        li.PId = PId;

        if (li.Count == -1 || li.UId == -1 || li.PId == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a Like \")</SCRIPT>");
        }
        else
        {
            //check the like count 
            DataSet ds = dba.checkuid(li.UId, li.PId);
            int rowCount = ds.Tables[0].Rows.Count;

            if (rowCount >= 1)
            {
                dba.dislike(li.UId);
                ImageButton1.ImageUrl = "~/images/like1.JPG";
                //ImageButton imgButton1 = sender as ImageButton;
                //imgButton1.ImageUrl = "~/images/like1.JPG";
            }
            else if (rowCount == 0)
            {
                dba.insertlike(li);
                ImageButton1.ImageUrl = "~/images/like2.JPG";
            }
        }
        Page_Load(this, e);
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        //remove comment from paticular user
        int comm = dba.removecomment(UId);
        if (comm >= 1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Comment successfully Removed \")</SCRIPT>");
            TextBox1.Text = "";
            Button2.Visible = false;
        }
        else if (comm == 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Select a valid item to remove\")</SCRIPT>");
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error !\")</SCRIPT>");
        }
        Page_Load(this, e);
    }


    protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }

    protected void addtocartbutton_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewCart.aspx");
    }

    protected void addtowishlistbutton_Click(object sender, EventArgs e)
    {
        Response.Redirect("Wishlist.aspx");
    }
}