﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    //Make instance from ReportMethods class
    ReportMethods reportMethods = new ReportMethods();
    DataTable bestBuyers_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Load the report
        if (!IsPostBack)
        {
            RpvBestBuyers.ProcessingMode = ProcessingMode.Local;
            RpvBestBuyers.LocalReport.ReportPath = Server.MapPath("~/Reports/GetBetBuyersRpt.rdlc");
            bestBuyers_dt = reportMethods.GetBestBuyers();
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "GetBestBuyers";
            source1.Value = bestBuyers_dt;
            RpvBestBuyers.LocalReport.DataSources.Clear();
            RpvBestBuyers.LocalReport.DataSources.Add(source1);
            RpvBestBuyers.LocalReport.Refresh();

        }
    }
}