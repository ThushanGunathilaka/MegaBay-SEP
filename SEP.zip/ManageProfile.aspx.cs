﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;

public partial class ManageProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
       {
         
           // TextBoxfirstname.Enabled = false;
           // TextBoxlastname.Enabled = false;
         //   TextBoxemail.Enabled = false;
           TextBoxpassword.Visible = false;

            TextBoxfirstname.ReadOnly = true;
            TextBoxlastname.ReadOnly = true;
            TextBoxemail.ReadOnly = true;
            TextBoxpassword.ReadOnly = true;
        


            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            string cmdText = "SELECT * FROM ECustomer WHERE username='" +  Session["New"] + "';";
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }

            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
           // string userIndex = "";
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    // userIndex =dr["Fname"].ToString().Trim();
                    //Response.Write(reader["Fname"].ToString());
                    TextBoxfirstname.Text = dr["Fname"].ToString();
                    TextBoxlastname.Text = dr["Lname"].ToString();
                    TextBoxemail.Text = dr["email"].ToString();
                    TextBoxpassword.Text = dr["password"].ToString();
                }
            }

            conn.Close();
        }
        
    }

   
    public void asp_click(object sender, EventArgs e)
    {
        HtmlButton btn = (HtmlButton)sender;

        if (btn.InnerText == "edit") {
            btn.InnerText = "update";
            //TextBoxfirstname.Enabled = true;
            TextBoxfirstname.ReadOnly = false;
            TextBoxfirstname.Focus();
        }
        else if (btn.InnerText == "update") {
            Boolean correct = false;

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            string updateSQL;
            updateSQL = "UPDATE ECustomer SET ";
            updateSQL += "Fname=\'" + TextBoxfirstname.Text + "\' ";
            updateSQL += "WHERE username='" + Session["New"] + "';";
            SqlCommand cmd = new SqlCommand(updateSQL, conn);
         //   Response.Write(updateSQL);
            int updated = 0;
            try
            {
                conn.Open();

                updated = cmd.ExecuteNonQuery();
                correct = true;

            }
            catch (Exception err)
            {

            }
            finally
            {
                conn.Close();
            }

            if (correct)
            {
                btn.InnerText = "edit";
                //TextBoxfirstname.Enabled = false;
                TextBoxfirstname.ReadOnly =true;
            }
        }
    
    }

    public void lastname_click(object sender, EventArgs e)
    {
        HtmlButton btn = (HtmlButton)sender;

        if (btn.InnerText == "edit")
        {
            btn.InnerText = "update";
            //TextBoxfirstname.Enabled = true;
            TextBoxlastname.ReadOnly = false;
            TextBoxlastname.Focus();
        }
        else if (btn.InnerText == "update")
        {
            Boolean correct = false;

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            string updateSQL;
            updateSQL = "UPDATE ECustomer SET ";
            updateSQL += "Lname=\'" + TextBoxlastname.Text + "\' ";
            updateSQL += "WHERE username='" + Session["New"] + "';";
            SqlCommand cmd = new SqlCommand(updateSQL, conn);
            //   Response.Write(updateSQL);
            int updated = 0;
            try
            {
                conn.Open();

                updated = cmd.ExecuteNonQuery();
                correct = true;

            }
            catch (Exception err)
            {

            }
            finally
            {
                conn.Close();
            }

            if (correct)
            {
                btn.InnerText = "edit";
                TextBoxlastname.ReadOnly = true;
            }
        }

    }

    public void email_click(object sender, EventArgs e)
    {
        HtmlButton btn = (HtmlButton)sender;

        if (btn.InnerText == "edit")
        {
            btn.InnerText = "update";
            //TextBoxfirstname.Enabled = true;
            TextBoxemail.ReadOnly = false;
            TextBoxemail.Focus();
        }
        else if (btn.InnerText == "update")
        {
            Boolean correct = false;

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            string updateSQL;
            updateSQL = "UPDATE ECustomer SET ";
            updateSQL += "email=\'" + TextBoxemail.Text + "\' ";
            updateSQL += "WHERE username='" + Session["New"] + "';";
            SqlCommand cmd = new SqlCommand(updateSQL, conn);
            //   Response.Write(updateSQL);
            int updated = 0;
            try
            {
                conn.Open();

                updated = cmd.ExecuteNonQuery();
                correct = true;

            }
            catch (Exception err)
            {

            }
            finally
            {
                conn.Close();
            }

            if (correct)
            {
                btn.InnerText = "edit";
                TextBoxemail.ReadOnly = true;
            }
        }
    }

    public void password_click(object sender, EventArgs e)
    {
        HtmlButton btn = (HtmlButton)sender;

        if (btn.InnerText == "edit")
        {
            btn.InnerText = "update";
            //TextBoxfirstname.Enabled = true;
            TextBoxpassword.ReadOnly = false;
            TextBoxpassword.Visible = true;
            TextBoxpassword.Focus();
        }
        else if (btn.InnerText == "update")
        {
            Boolean correct = false;

            if (TextBoxpassword.Text.ToString().Length>2) {
                correct = true;
            }

            if (correct)
            {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
            
                string updateSQL;
                updateSQL = "UPDATE ECustomer SET ";
                updateSQL += "password=\'" + TextBoxpassword.Text + "\' ";
                updateSQL += "WHERE username='" + Session["New"] + "';";
                SqlCommand cmd = new SqlCommand(updateSQL, conn);
                //   Response.Write(updateSQL);
                int updated = 0;
                try
                {
                    conn.Open();                
                    updated = cmd.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                
                }
                finally
                {
                    conn.Close();
                }
                    
           
                        btn.InnerText = "edit";
                        TextBoxpassword.ReadOnly = true;
                        TextBoxpassword.Visible = false;
                    }
                
            

        
    }
}

}

