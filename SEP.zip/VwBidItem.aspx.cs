﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Default3 : System.Web.UI.Page
{
    Bidding bidding = new Bidding();
    protected void Page_Load(object sender, EventArgs e)
    {
        String PID = Session["promoClick"].ToString();       
        bidding.BindGridViewForSeperateBid(GridView1, PID);
        string NumberOfBids = bidding.getNoOfBids(PID);
        lblNofBids.Text = NumberOfBids;
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public string TargetDate
    {
        get
        {
            String PID = Session["promoClick"].ToString();
            //String PID = "7";
            //get the expire date from the database and give to date string
            String date = bidding.getExpireDate(PID);
            DateTime dt = Convert.ToDateTime(date);
            String expDate = dt.ToString("dd MMMM yyyy H:mm:ss");
            return expDate;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            BidItem item = new BidItem();
            item.BidItemId = int.Parse(Session["promoClick"].ToString());
            decimal bidPrice = decimal.Parse(txtNewPrice.Text);
            item.BItemPrice = decimal.Parse(txtNewPrice.Text);
            if (txtNewPrice.Text == null)
            {
                Label14.Text = "Please enter your price for item!!!";
            }
            item.CusID = Convert.ToInt32(Session["CusID"].ToString());
            Bidding bidding = new Bidding();
            decimal MaxPrice = decimal.Parse(bidding.getCurrentMaxPrice(Session["promoClick"].ToString()));
            if (bidPrice < MaxPrice)
            {
                Label14.Text = "Your price must higher than Current max price!!!";
            }
            else
            {
                bidding.PlaceBid(item);
                bidding.UpdateBidPrice(item);
                Label12.Text = "Successsully placed the bid!!!";
                Label14.Text = "";
                string NumberOfBids = bidding.getNoOfBids(Session["promoClick"].ToString());
                lblNofBids.Text = NumberOfBids;
            }
            bidding.BindGridViewForSeperateBid(GridView1, Session["promoClick"].ToString());

        }
        catch (SqlException)
        {
            Label14.Text = "Error occured while placing bid on database";
            Label12.Text = "";
        }
        catch (TimeoutException)
        {
            Label14.Text = "Your session time is out";
            Label12.Text = "";
        }
        catch (Exception ex)
        {
            Label14.Text = "Error occured while placing bid";
            Label12.Text = "";
        }
    }
}