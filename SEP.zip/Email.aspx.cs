﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;


public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    BuyGiftcard giftcard = new BuyGiftcard();

    protected void Page_Load(object sender, EventArgs e)
    {
        String id = Session["BgiftcardClick2"].ToString();
    }

    
    protected void Button1_Click(object sender, EventArgs e)
    {
        String id = Session["BgiftcardClick2"].ToString();
        //String num = dba.getuniqenum(id);

        try
        {
            using (MailMessage mm = new MailMessage("vswickramasekara@gmail.com", txtTo.Text))
            {
                mm.Subject = "MEGA BAY,Gift Card for you";
                mm.Body = "This is the Unique number of Gift Card that sent to you, " + id.ToString();
                if (fuAttachment.HasFile)
                {
                    string FileName = Path.GetFileName(fuAttachment.PostedFile.FileName);
                    mm.Attachments.Add(new Attachment(fuAttachment.PostedFile.InputStream, FileName));
                }
                mm.IsBodyHtml = false;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential("vswickramasekara@gmail.com", "vsaumya7777");
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                smtp.Send(mm);

                //update the buyGiftcard table, sentemail colunm by newly added email.
                String mail = txtTo.Text;
                dba.updateemail(id, mail);

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Gift Card sent via Email.');", true);
            }
        }
        catch (Exception)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Connection Lost, try again \")</SCRIPT>");
        }
    }
    protected void txtBody_TextChanged(object sender, EventArgs e)
    {

    }
}

    
