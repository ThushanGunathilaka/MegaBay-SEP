﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       if (catdrop.Text == "Fashion")
        {
            subcatdrop.Items.Add("Jewelry & Watches");
            subcatdrop.Items.Add("Handbags & Accessories");
            subcatdrop.Items.Add("Health & Beauty");
            subcatdrop.Items.Add("Shoes");
            subcatdrop.Items.Add("Sales & Events");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }
        else if (catdrop.Text == "Electronics")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Add("Cell Phones & Accessories");
            subcatdrop.Items.Add("Cameras & Photo");
            subcatdrop.Items.Add("Computers & Tablets");
            subcatdrop.Items.Add("Car audio,video & GPS");
            subcatdrop.Items.Add("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }

        else if (catdrop.Text == "Collectibles & Art")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Antiques");
            subcatdrop.Items.Add("Sports Memorabilia");
            subcatdrop.Items.Add("Entertainment Memorabilia");
            subcatdrop.Items.Add("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");

        }
        else if (catdrop.Text == "Home & Garden")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Home Decor");
            subcatdrop.Items.Add("Crafts");
            subcatdrop.Items.Add("Kitchen, Dining & Bar");
            subcatdrop.Items.Add("Yard, Garden & Outdoor");
            subcatdrop.Items.Add("Baby");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");
            subcatdrop.Items.Remove("Motors");

        }
        else
        {
            subcatdrop.Items.Add("motors");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

        }      
        if (Session["CusID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        Insert_Item ItemMethods = new Insert_Item();
        int CusID =Convert.ToInt32(Session["CusID"].ToString());
        ItemMethods.BindGrid(GridView2, CusID);
        fillcombo(CusID);

        //if (String.IsNullOrEmpty(TextBox2.Text) || String.IsNullOrEmpty(TextBox3.Text))
        //{
        //    Button2.Enabled = false;
        //}
        //else
        //{
        //    Button2.Enabled = true;
        //}
      
    }
    SqlConnection conn1 = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
    //SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);

    

    void fillcombo(int CusID)
    {

        try
        {
            if (!IsPostBack)
            {

                if (conn1.State == System.Data.ConnectionState.Closed)
                {
                    conn1.Open();
                }
                SqlCommand commn = new SqlCommand("SELECT PID FROM Product where CusID=" + CusID + ";", conn1);
                SqlDataReader myReader;
                myReader = commn.ExecuteReader();
                int count = 0;
                while (myReader.Read())
                {
                    string pid = myReader.GetInt32(count).ToString();
                    DropDownList1.Items.Add(pid);
                    DropDownList2.Items.Add(pid);

                }

                conn1.Close();
            }

        }
        catch (Exception ex)
        {
           // MessageBox.Show(ex.Message);
        }
    }

    protected void selectPIDs_TextChanged(object sender, EventArgs e)
    {
       
    }
   
 protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        try
        {

            if (conn1.State == System.Data.ConnectionState.Closed)
            {
                conn1.Open();
            };

            SqlCommand commn = new SqlCommand("select pname,condition,company,price,modle,description,Size,Colour,Material,priority,availability,category,subCategory from Product where PID='" + DropDownList1.SelectedItem + "'", conn1);
            SqlDataReader myReader;
            myReader = commn.ExecuteReader();
            while (myReader.Read())
            {
                TextBox2.Text = myReader.GetString(0);
                TextBox3.Text = myReader.GetString(1);
                TextBox4.Text = myReader.GetString(2);
                pricetxt.Text = myReader.GetDecimal(3).ToString();
                modletxt.Text = myReader.GetString(4);
                descrtxt.Text = myReader.GetString(5);
                heighttxt.Text =  myReader.GetString(6);
                widthtxt.Text =  myReader.GetString(7);
                depthtxt.Text =  myReader.GetString(8);
                prioritytxt.Text = myReader.GetString(9);
                availdrop.Text = myReader.GetString(10);
                catdrop.Text = myReader.GetString(11);
                subcatdrop.Text = myReader.GetString(12);

            }
            conn1.Close();
        }
        catch (Exception ex)
        {
            //Label8.Text = "Error occured while performing your operation!!!";
        }       
        
    }
    protected void DropDownList1_TextChanged(object sender, EventArgs e)
    {
       // Label8.Text = DropDownList1.SelectedValue;
    }

   
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            Insert_Item insItem = new Insert_Item();
            string msg;
            msg = insItem.deleteItems(DropDownList2);
            Label22.Text = msg;
            insItem.BindGrid(GridView2,Convert.ToInt32(Session["CusID"].ToString()));
        }
        catch (Exception ex)
        {
            Label23.Text = "Error occured while deleting!!!";
        }
    }

    
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            
                Item item = new Item();
                item.CusID1 = (int.Parse(DropDownList1.SelectedItem.ToString()));
                item.Pname = TextBox2.Text;
                item.Condition = TextBox3.Text;
                item.Company1 = TextBox4.Text;
                item.Price = double.Parse(pricetxt.Text);
                item.Modle = modletxt.Text;
                item.Description = descrtxt.Text;
                item.Height =0;
                item.Width =0;
                item.Depth = 0;
                item.Priority = prioritytxt.Text;
                item.Availability = availdrop.SelectedItem.ToString();
                item.Category = catdrop.SelectedItem.ToString();
                item.SubCategory = subcatdrop.SelectedItem.ToString();
                item.AddedDate = DateTime.Now;
                item.Size = heighttxt.Text;
                item.Colour = widthtxt.Text;
                item.Material = depthtxt.Text;


                Insert_Item InsItem = new Insert_Item();
                if (String.IsNullOrEmpty(TextBox2.Text) || String.IsNullOrEmpty(TextBox3.Text))
                {
                    Label8.Text = "Please enter product name and price!!!";
                    Label10.Text = "";

                    
                }
                else
                {
                    InsItem.updateItems(item);
                    Label8.Text = "";
                    Label10.Text = "Data without image Successfully Updated!!!";

                    Insert_Item ItemMethods = new Insert_Item();
                    ItemMethods.BindGrid(GridView2,Convert.ToInt32(Session["CusID"].ToString()));
                }

                
            
            
        }
       catch (Exception ex)
        {
           Label8.Text = "Error occured while updating!!!";
        }
    }
protected void catdrop_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Label6.Text = "hi";
        string selectedValue = catdrop.SelectedItem.ToString();

        //Label6.Text = selectedValue;
        if (selectedValue == "Fashion")
        {
            subcatdrop.Items.Add("Jewelry & Watches");
            subcatdrop.Items.Add("Handbags & Accessories");
            subcatdrop.Items.Add("Health & Beauty");
            subcatdrop.Items.Add("Shoes");
            subcatdrop.Items.Add("Sales & Events");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }
        else if (selectedValue == "Electronics")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Add("Cell Phones & Accessories");
            subcatdrop.Items.Add("Cameras & Photo");
            subcatdrop.Items.Add("Computers & Tablets");
            subcatdrop.Items.Add("Car audio,video & GPS");
            subcatdrop.Items.Add("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");
        }

        else if (selectedValue == "Collectibles & Art")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Antiques");
            subcatdrop.Items.Add("Sports Memorabilia");
            subcatdrop.Items.Add("Entertainment Memorabilia");
            subcatdrop.Items.Add("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Motors");

        }
        else if (selectedValue == "Home & Garden")
        {
            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

            subcatdrop.Items.Add("Home Decor");
            subcatdrop.Items.Add("Crafts");
            subcatdrop.Items.Add("Kitchen, Dining & Bar");
            subcatdrop.Items.Add("Yard, Garden & Outdoor");
            subcatdrop.Items.Add("Baby");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");
            subcatdrop.Items.Remove("Motors");

        }
        else
        {
            subcatdrop.Items.Add("motors");

            subcatdrop.Items.Remove("Antiques");
            subcatdrop.Items.Remove("Sports Memorabilia");
            subcatdrop.Items.Remove("Entertainment Memorabilia");
            subcatdrop.Items.Remove("Art");

            subcatdrop.Items.Remove("Cell Phones & Accessories");
            subcatdrop.Items.Remove("Cameras & Photo");
            subcatdrop.Items.Remove("Computers & Tablets");
            subcatdrop.Items.Remove("Car audio,video & GPS");
            subcatdrop.Items.Remove("TV, Audio");

            subcatdrop.Items.Remove("Home Decor");
            subcatdrop.Items.Remove("Crafts");
            subcatdrop.Items.Remove("Kitchen, Dining & Bar");
            subcatdrop.Items.Remove("Yard, Garden & Outdoor");
            subcatdrop.Items.Remove("Baby");

            subcatdrop.Items.Remove("Jewelry & Watches");
            subcatdrop.Items.Remove("Handbags & Accessories");
            subcatdrop.Items.Remove("Health & Beauty");
            subcatdrop.Items.Remove("Shoes");
            subcatdrop.Items.Remove("Sales & Events");

        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {


            byte[] image;
            Stream s = FileUpload1.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(s);
            image = br.ReadBytes((Int32)s.Length);

            Item item = new Item();
            item.CusID1 = (int.Parse(DropDownList1.SelectedItem.ToString()));
            item.Image = (image);
            Insert_Item InsItem = new Insert_Item();


            InsItem.updateImg(item);
            Label10.Text = "image Successfully Updated!!!";
            Label8.Text = "";
        }
        else
        { 
         Label10.Text="";
         Label8.Text = "Please select image to upload!!!";
        }
    }
}











