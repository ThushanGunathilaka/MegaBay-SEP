﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class restrictUserAccount : System.Web.UI.Page
{
    int selectedindex = -1;
    protected List<String> list;

    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewRestrictedUserAccounts.aspx");
    }

    protected void GridView1_SelectedIndexChanged2(object sender, EventArgs e)
    {
        list = new List<string>();
        list.Add(GridView1.SelectedRow.Cells[1].Text.ToString());
        list.Add(GridView1.SelectedRow.Cells[2].Text.ToString());
        list.Add(GridView1.SelectedRow.Cells[3].Text.ToString());
       
        selectedindex = GridView1.SelectedRow.RowIndex;
    
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            list = new List<string>();
            list.Add(GridView1.SelectedRow.Cells[1].Text.ToString());
            list.Add(GridView1.SelectedRow.Cells[2].Text.ToString());
            list.Add(GridView1.SelectedRow.Cells[3].Text.ToString());
            
        }
        catch (Exception me) { }

        String v = DropDownList1.SelectedItem.Value.ToString();
        if (v != null && list != null && v.Trim().CompareTo("") != 0)
        {
            string insertQuery = "insert into UserRestrictedAccounts (userName,Reason,date) values (@userName,@Reason,@date)";
            System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            SqlCommand com = new SqlCommand(insertQuery, sqlConnection);

            com.Parameters.AddWithValue("@userName", list[0]);
            com.Parameters.AddWithValue("@Reason", v);
            com.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "User Account Restricted!" + "');", true);

           
            string move = "INSERT INTO IECustomer (CusID,username,Fname,Lname,password,registered_date,activeStatusReason,email,rating,fbaccount) SELECT CusID,username,Fname,Lname,password,registered_date,activeStatus,email,rating,fbaccount FROM ECustomer WHERE username = \'" + list[0] + "\'";
            SqlCommand cod = new SqlCommand(move, sqlConnection);
             
            string deleteSQL;
            deleteSQL = "DELETE FROM UserLoginStatus WHERE username=\'" + list[0] + "\'";
            SqlCommand cmd = new SqlCommand(deleteSQL, sqlConnection);

            string deleteSQL2;
            deleteSQL2 = "DELETE FROM ECustomer WHERE username=\'" + list[0] + "\'";
            SqlCommand cmdd = new SqlCommand(deleteSQL2, sqlConnection);

            try
            {
                sqlConnection.Open();
                com.ExecuteNonQuery();
                cod.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
                cmdd.ExecuteNonQuery();
               // GridView1.Rows[selectedindex].Visible = false;

               
            }
            catch (Exception es)
            {
              //  Response.Write(es.Message);
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Error Occured" + "');", true);
                
            }

            sqlConnection.Close();
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Error Occured! Make necessary selections to save the rating details" + "');", true);

        }
    }
}