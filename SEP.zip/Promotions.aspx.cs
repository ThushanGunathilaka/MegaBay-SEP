﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Diagnostics;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        int selec = DropDownList1.SelectedIndex;        
        String selVal="";

        if (selec == 0)
            selVal = "PID";
        else if(selec == 1)
            selVal = "pname";
        else if(selec == 2)
            selVal = "company";
        else if(selec == 3)
            selVal = "promID";

        String search = TextBox4.Text;

        DataSet ds = dba.searchProd(search, selVal);
        GridView1.DataSource=ds.Tables[0].DefaultView;
        GridView1.DataBind();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
    }
    
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        String id = GridView1.SelectedRow.Cells[0].Text;
        TextBox1.Text = id;
        DataSet ds = dba.getPromDisc(id);
        int rowCount = ds.Tables[0].Rows.Count;
        if (rowCount == 0)
        {
            TextBox2.Text = "0";
        }
        else
        {
            TextBox2.Text = ds.Tables[0].Rows[0][2].ToString();
            TextBox3.Text = ds.Tables[0].Rows[0][3].ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String id = TextBox1.Text;
       // Debug.WriteLine(id);
        String disc = TextBox2.Text;
        String prom = TextBox3.Text;
        if (dba.insertProm(id, disc, prom) >= 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Promotion successfully added.  \")</SCRIPT>");
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            Button3_Click(this,e);
        }
        else
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error !\")</SCRIPT>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        String id = TextBox1.Text;
        //Debug.WriteLine(id);
        int stat = dba.removeProm(id);
        if (stat > 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Promotion successfully Removed \")</SCRIPT>");
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            Button3_Click(this, e);
        }
        else if (stat == 0)
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Select a valid item to remove\")</SCRIPT>");
        else
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error !\")</SCRIPT>");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {
        TextBox4.Text = string.Empty;
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        TextBox1.Text = string.Empty;
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        TextBox2.Text = string.Empty;
    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
        TextBox3.Text = string.Empty;
    }
}