﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Content_Thushan : System.Web.UI.Page
{
    protected List<Item> items;
    protected Item item;
    protected int link = -1;   // to show thumbnails from .aspx qstring
    protected string host = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        int link = Request.Url.Port;   // to show thumbnails from .aspx qstring
        string host = Request.Url.Host;

        Session["Port"] = link;   // to show thumbnails from .aspx qstring
        Session["Host"] = host;


        if (!Page.IsPostBack)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            string catlist = "";
            string min = "";
            string max = "";
            string search = "";
            string cmdText = "";

            string sortq = "";
            string dealpromoq = "";
            string filtergenderq = "";
            string filterdealsq = "";
            string filterconditionq = "";

            catlist = (string)Session["thushan"];
            min = (string)Session["minprice"];
            max = (string)Session["maxprice"];
            search = (string)Session["searchtext"];

            sortq = (string)Session["sort"];
            string dealpromoqx = (string)Session["dealpromo"];
            string filtergenderqx = (string)Session["filtergender"];
            string filterdealsqx = (string)Session["filterdeals"];
            string filterconditionqx = (string)Session["filtercondition"];


            Boolean messagenoitems = false;


            //Response.Write(filtergenderqx + filterdealsqx + filterconditionqx);



            if (dealpromoqx.CompareTo("") == 0)
            {
                dealpromoq = "1=1";
            }
            else
            {
                dealpromoq = dealpromoqx;
            }

            if (filtergenderq.CompareTo("") == 0)
            {
                filtergenderq = "";
            }
            else
            {
                filtergenderq = " AND gender = \'" + filtergenderqx + "\' ";
            }

            if (filterdealsqx.CompareTo("") == 0)
            {
                filterdealsq = "";
            }
            else
            {
                filterdealsq = " AND promotion = \'" + filterdealsqx + "\' ";
            }

            if (filterconditionqx.CompareTo("") == 0)
            {
                filterconditionq = "";
            }
            else
            {
                filterconditionq = " AND condition = \'" + filterconditionqx + "\' ";
            }


            // Response.Write(filtergenderqx + filterdealsqx + filterconditionqx);




            //for all test cases
            if (search.Trim().CompareTo("") == 0)
            {
                if (min.Trim().CompareTo("") == 0 && max.Trim().CompareTo("") == 0)
                {
                    if (catlist.Trim().CompareTo("") == 0)
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Use price range and sub categories to customize your search" + "');", true);
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where  (" + catlist + ") AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }
                else
                {
                    if (catlist.Trim().CompareTo("") == 0)
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where  price > " + min + " and price < " + max + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where  price > " + min + " and price < " + max + " AND (" + catlist + ")  AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }

                if (catlist.Trim().CompareTo("") == 0)
                {
                    if ((min.Trim().CompareTo("") == 0 || max.Trim().CompareTo("") == 0))
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where " + dealpromoq + " " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Use price range and sub categories to customize your search" + "');", true);
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where price > " + min + " and price < " + max + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }
                else
                {
                    if ((min.Trim().CompareTo("") == 0 || max.Trim().CompareTo("") == 0))
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where (" + catlist + ") AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where  price > " + min + " and price < " + max + " and  (" + catlist + ")  AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }
            }
            else
            {
                if (min.Trim().CompareTo("") == 0 && max.Trim().CompareTo("") == 0)
                {
                    if (catlist.Trim().CompareTo("") == 0)
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%' " + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Use price range and sub categories to customize your search" + "');", true);
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%' and (" + catlist + ") AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }
                else
                {
                    if (catlist.Trim().CompareTo("") == 0)
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%'  and price > " + min + " and price < " + max + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%' and (" + catlist + ") and price > " + min + " and price < " + max + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }

                if (catlist.Trim().CompareTo("") == 0)
                {
                    if ((min.Trim().CompareTo("") == 0 || max.Trim().CompareTo("") == 0))
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%'  " + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Use price range and sub categories to customize your search" + "');", true);
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%'  and price > " + min + " and price < " + max + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }
                else
                {
                    if ((min.Trim().CompareTo("") == 0 || max.Trim().CompareTo("") == 0))
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%' and (" + catlist + ")  " + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                    else
                    {
                        cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + search + "%' and (" + catlist + ")   and price > " + min + " and price < " + max + " AND (" + dealpromoq + ") " + filtergenderq + filterdealsq + filterconditionq + sortq + ";";
                    }
                }
            }

            // Response.Write(cmdText);

            try
            {
                string qstr = "";
                qstr = Request.QueryString["search"];
                if (qstr != null && qstr.Trim().CompareTo("") != 0)
                {
                    cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where subCategory='" + qstr + "';";
                }
            }
            catch (Exception eqw) { }
            search = (search.Trim().CompareTo("") == 0) ? "Anything" : search;
            showrelatedsearchmessage.Controls.Clear();
            showrelatedsearchmessage.Controls.Add(new LiteralControl("<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a><strong>Looking for: " + search + "</strong>"));

            try
            {
                List<string> relatedList = (List<string>)Session["realatedSYN"];
                string qstr = "";
                qstr = Request.QueryString["related"];
                if (qstr != null && qstr.Trim().CompareTo("related") == 0)
                {
                    string relp = relatedList.Last<string>();
                    cmdText = "select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + relp + "%' ";
                    int xi = relatedList.Count();
                    //xi =(xi>5)?5:xi;
                    while (xi == 0) {
                        cmdText += "union select PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where pname like '%" + relatedList[xi] + "%' ";
                        xi--;
                    }
                    cmdText += ";";
                    //showrelatedsearchmessage
                    relatedList.RemoveAt(relatedList.Count()-1);
                    showrelatedsearchmessage.Controls.Clear();
                    showrelatedsearchmessage.Controls.Add(new LiteralControl("<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a><strong>Looking for: " + relp + ", </strong>"+ String.Join(", ", relatedList.ToArray())));
                    Session["realatedSYN"] = new List<String>() { };
                }
            }
            catch (Exception eqw) { }

           

            SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

            if (con.State == System.Data.ConnectionState.Closed)
            {
                con.Open();
            }

            items = new List<Item>();

            try
            {
                System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        item = new Item();

                        byte[] bytes = new byte[0];
                        try
                        {
                            item.productID = int.Parse(dr["PID"].ToString().Trim());

                            item.Promotion = dr["promotion"].ToString();

                            item.Gender = dr["gender"].ToString();

                            item.Pname = dr["Product Name"].ToString().Trim();

                            bytes = (byte[])dr["Image"];
                            item.Image = bytes;

                            item.Price = double.Parse(dr["Price"].ToString());

                            item.Description = dr["Description"].ToString();

                            item.Category = dr["Category"].ToString();

                            item.SubCategory = dr["SubCategory"].ToString();

                            items.Add(item);
                        }
                        catch (Exception e2) { }
                    }   //while
                }
                else
                {   //if

                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Couldn`t find items you are looking for. Please subscribe to our NewsLetter. we`ll  get back to you as soon as we can."+ "');", true);
                    messagenoitems = true;
                }
            }
            catch (Exception v) { }

            con.Close();

            List<string> tabs = new List<string>();

            foreach (Item it in items)
            {
                if (!tabs.Contains(it.Category))
                {
                    tabs.Add(it.Category);
                }
            }

            string tabcontent = custmnavi(tabs);    //html string start

            int y = tabs.Count;

            foreach (string cat in tabs)
            {
                tabcontent += "<div class=\"tab-pane fade";

                if (tabs.Count == 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Empty result!" + "');", true);
                }
                else
                {
                    tabcontent += " active in";
                }

                tabcontent += "\" id=\"" + new String(cat.Where(char.IsLetter).ToArray()).ToLower() + "\">"; //tab content

                tabcontent += " <div class=\"row\">";
                int iii = 0;    // result row can only have 4 items
                bool check = false;

                string name = "";
                string price = "";
                byte[] url = null;
                string desc = "";
                string pid = "";
                string promo = "";

                if (items != null)
                {
                    foreach (Item ii in items)
                    {
                        if (ii.Category.CompareTo(cat) == 0)
                        {
                            if (iii == 0)
                            {
                                check = true;
                            }

                            name = ii.Pname;
                            pid = ii.productID.ToString();
                            price = String.Format("{0:0.00}", ii.Price);
                            url = ii.Image;
                            desc = ii.Description;
                            promo = ii.Promotion;
                            tabcontent += oneobject(promo, pid, name, price, url, desc);
                            iii++;

                            if (check)
                            {
                                iii = 0;
                                check = false;
                            }
                        }
                    }
                }

                tabcontent += "</div>"; //row
                tabcontent += "</div>";
            }

            tabcontent += "</div>";     //tab content
            tabcontent += "</div>";     //tab all

            searchbar.Controls.Add(new LiteralControl(tabcontent));
            /*

            Boolean isRelatedProductAvailable = false;
            if (isRelatedProductAvailable) {
                if (!Page.ClientScript.IsClientScriptBlockRegistered("relatedSearchData"))
                {
                    var serializedClass = new JavaScriptSerializer().Serialize(items);
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "relatedSearchData", string.Format("var datarr ={0}", serializedClass), true);
                }
            }*/
        }
    }

    private string custmnavi(List<string> list) {
        string navigationbar = ""
        + "<div class=\"col-sm-12\">"
        + "<ul class=\"nav nav-tabs\">";
          
        Boolean c = true;   // set active tab

        foreach (string t in list) {
            if (c) {
                navigationbar += "<li class=\"active\"><a href=\"#" + new String(t.Where(char.IsLetter).ToArray()).ToLower() + "\" data-toggle=\"tab\">" + t + "</a></li>";
                c = false;
            } else {
                navigationbar += "<li><a href=\"#" + new String(t.Where(char.IsLetter).ToArray()).ToLower() + "\" data-toggle=\"tab\">" + t + "</a></li>";
            }
        }

        navigationbar +=  "</ul>"
        + "</div>"
        + "<div class=\"tab-content\">";

        return navigationbar;
    }

    private string oneobject(string promotion,string pid, string name, string value, byte[] image, string alter)
    {
        int link = Request.Url.Port;   // to show thumbnails from .aspx qstring
        string host = Request.Url.Host;
        /*
        String img = "";
        img = "data:image/Png;base64" + Convert.ToBase64String(CreateThumbnail(image, 200));
        
        string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\eportal";
      
        if (!Directory.Exists(path)) {
            Directory.CreateDirectory(path);
        }
        
        string thumb = new String(name.Where(char.IsLetter).ToArray()).ToLower() + ".Png";  // set thumbnail name
        string thumbloc = @path + @"\thumb" + new String(name.Where(char.IsLetter).ToArray()).ToLower() + ".Png";    // thumbnail absolute path
        
        if (!File.Exists(thumbloc)) {
            File.WriteAllBytes(thumbloc, CreateThumbnail(image, 200));
        }
        */

        string i = ""
        + "<div class=\"col-sm-3\">"
        + "<div class=\"product-image-wrapper\">"
        + "<div class=\"single-products\">"
        + "<div class=\"productinfo text-center\">"
        + "<img src=\"" + @"http://" + @host + @":" + @link.ToString() + @"/getImageFromDB.ashx?param=" + @pid + "\" width=\"200\" height=\"180\"  alt=\"" + alter + "\" />"
        + "<h2>RS. " + value + "</h2>"
        + "<p>" + name + "</p>"
        + "<a href=\"" + @"http://" + @host + @":" + @link.ToString() + @"/Product_Thushan.aspx?product=megabay" + @pid + "\" class=\"btn btn-default add-to-cart\"><i class=\"fa fa-shopping-cart\"></i>View Product</a>"
        + "</div><div class=\"product-overlay\">"
        + "<div class=\"overlay-content\">"
        + "<!-- --><!-- -->"
        + "<h2>" + value + "</h2>"
        + "<p>" + name + "</p>"
        + "<a href=\"" + @"http://" + @host + @":" + @link.ToString() + @"/Product_Thushan.aspx?product=megabay" + @pid + "\" class=\"btn btn-default add-to-cart\"><i class=\"fa fa-shopping-cart\"></i>View Product</a>"
        + "</div></div>";
        if (promotion.CompareTo("sale")==0 || promotion.CompareTo("Sale")==0 || promotion.CompareTo("SALE")==0 )
        {
            i+="<img src=\"images/home/sale.png\" class=\"new\" alt=\"\" />";
        }
        else if (promotion.CompareTo("new") == 0 || promotion.CompareTo("New") == 0 || promotion.CompareTo("NEW") == 0)
        {
            i += "<img src=\"images/home/new.png\" class=\"new\" alt=\"\" />";
        }
        i+=  "</div>"
            +"<div class=\"choose\">"
			+ "<ul class=\"nav nav-pills nav-justified\">"
			+ "<li><a href=\"\"><i class=\"fa fa-plus-square\"></i><p>Add to wishlist</p></a></li>"
			+ "<li><a href=\"\"><i class=\"fa fa-plus-square\"></i><p>Add to compare</p></a></li>"
			+ "</ul>"
			+ "</div>"
            + "</div></div>";
        return i;
    }
    /*
    // Create a thumbnail in byte array format from the image encoded in the passed byte array.  
    public static byte[] CreateThumbnail(byte[] PassedImage, int LargestSide)
    {
        byte[] ReturnedThumbnail;

        using (MemoryStream StartMemoryStream = new MemoryStream(), NewMemoryStream = new MemoryStream()) {
            // write the string to the stream  
            StartMemoryStream.Write(PassedImage, 0, PassedImage.Length);

            // create the start Bitmap from the MemoryStream that contains the image  
            Bitmap startBitmap = new Bitmap(StartMemoryStream);

            // set thumbnail height and width proportional to the original image.  
            int newHeight;
            int newWidth;
            double HW_ratio;

            if (startBitmap.Height > startBitmap.Width) {
                newHeight = LargestSide;
                HW_ratio = (double)((double)LargestSide / (double)startBitmap.Height);
                newWidth = (int)(HW_ratio * (double)startBitmap.Width);
            } else {
                newWidth = LargestSide;
                HW_ratio = (double)((double)LargestSide / (double)startBitmap.Width);
                newHeight = (int)(HW_ratio * (double)startBitmap.Height);
            }

            // create a new Bitmap with dimensions for the thumbnail.  
            Bitmap newBitmap = new Bitmap(newWidth, newHeight);

            // Copy the image from the START Bitmap into the NEW Bitmap.  
            // This will create a thumnail size of the same image.  
            newBitmap = ResizeImage(startBitmap, newWidth, newHeight);

            // Save this image to the specified stream in the specified format.  
            newBitmap.Save(NewMemoryStream, System.Drawing.Imaging.ImageFormat.Png);

            // Fill the byte[] for the thumbnail from the new MemoryStream.  
            ReturnedThumbnail = NewMemoryStream.ToArray();
        }

        // return the resized image as a string of bytes.  
        return ReturnedThumbnail;
    }

    private static Bitmap ResizeImage(Bitmap image, int width, int height)
    {
        Bitmap resizedImage = new Bitmap(width, height);

        using (Graphics gfx = Graphics.FromImage(resizedImage)) {
            gfx.DrawImage(image, new Rectangle(0, 0, width, height), new Rectangle(0, 0, image.Width, image.Height), GraphicsUnit.Pixel);
        }

        return resizedImage;
    } 
    */
}


