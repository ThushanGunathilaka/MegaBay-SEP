﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Cart
/// </summary>
public class Cart
{
	public Cart()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public System.Collections.ArrayList list = new ArrayList(20);
}