﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for JSONSerializerAdapter
/// </summary>
public class JSONSerializerAdapter : ISerializerAdapter
{
    public string Serialize<T>(object objToSerialize)
    {
        JavaScriptSerializer js = new JavaScriptSerializer();
        return js.Serialize(objToSerialize);
    }
}