﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

/// <summary>
/// Summary description for DataSerializer
/// </summary>
public class DataSerializer
{
    private readonly ISerializerAdapter _serializer;
    public DataSerializer(ISerializerAdapter serializer)
    {
        _serializer = serializer;
    }
    public string Render(List<Item> list)
    {
        var sb = new StringBuilder();
        foreach (var item in list)
        {
            sb.AppendLine(_serializer.Serialize<Item>(item));
        }
        return sb.ToString();
    }

    public string Render(List<String> list)
    {
        var sb = new StringBuilder();
        foreach (var item in list)
        {
            sb.Append(_serializer.Serialize<String>(item)+',');
        }
        return sb.ToString();
    }
}