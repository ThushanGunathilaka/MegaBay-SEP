﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

/// <summary>
/// Summary description for XMLSerializerAdapter
/// </summary>
public class XMLSerializerAdapter : ISerializerAdapter
{
    public string Serialize<T>(object objToSerialize)
    {
        using (var writer = new StringWriter())
        {
            var serializer = new XmlSerializer(typeof(T));
            serializer.Serialize(writer, objToSerialize);
            return writer.ToString();
        }
    }
}