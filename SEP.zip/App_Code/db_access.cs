﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.Web.UI.WebControls;
using System.Configuration;
/// <summary>
/// Summary description for db_access
/// </summary>
public class db_access
{
    db_conn conn;
    SqlConnection sqlConn;
	public db_access()
	{
        conn = new db_conn();
        sqlConn=conn.connect();
        sqlConn.Open();
	}

    public int insertFeedbak(Feedback feedback)
    {
        string insertFeedback;
        if(feedback.User==null)
            insertFeedback = "INSERT INTO SiteFeedback(cusID,feedback,rating) VALUES(null,@feedback,@rate)";
        else
            insertFeedback = "INSERT INTO SiteFeedback(cusID,feedback,rating) VALUES(@cusid,@feedback,@rate)";

        SqlCommand cmmnd = new SqlCommand(insertFeedback, sqlConn);

        cmmnd.CommandType = CommandType.Text;
        if (feedback.User != null)
        {
            cmmnd.Parameters.AddWithValue("@cusid", feedback.User);
        }
        cmmnd.Parameters.AddWithValue("@feedback", feedback.FeedBack);
        cmmnd.Parameters.AddWithValue("@rate", feedback.Rating);

        return cmmnd.ExecuteNonQuery();
    }

    public DataSet viewSiteFeedbak()
    {
        string query = "SELECT rating,COUNT(rating) FROM SiteFeedback GROUP BY rating";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;

    }

    /// <summary>
    /// view the given ratings
    /// </summary>
    /// <returns>return count of the rate</returns>
    public DataSet viewStarRatings()
    {
        string query = "SELECT Rate,COUNT(Rate) FROM StarRating GROUP BY Rate";
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    /// <summary>
    /// get single user rate and fill stars with color
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <returns></returns>
    public DataSet viewStarRate(int PId, int UId)
    {
        string query = "SELECT Rate FROM StarRating WHERE PID='" + PId + "'and CusID='" + UId + "'";
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;

    }

    public DataSet viewProdFeedbak(int pid)
    {
        string query = "SELECT Pro_rating,COUNT(Pro_rating) FROM ProductFeedback where PID=" + pid + " GROUP BY Pro_rating";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    public DataSet searchProd(String search,String srchBy)
    {
        string query;
        if(srchBy=="promID")
            query = "SELECT p.PID,pname,company,price FROM Product p,Promotions pr  WHERE p.PID=pr.PID AND " + srchBy + " LIKE '%" + search + "%'";
        else
            query = "SELECT PID,pname,company,price FROM Product WHERE " + srchBy + " LIKE '%" + search + "%'";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        int rowc = ds.Tables[0].Rows.Count;

        ds.Tables[0].Columns.Add("discount", typeof(string));
        ds.Tables[0].Columns.Add("promotion", typeof(string));

        for (int i = 0; i < rowc; i++)
        {
            int id = (int)ds.Tables[0].Rows[i][0];
            String query2 = "SELECT discount,promotion FROM Promotions WHERE PID=" + id;
            SqlCommand cmmnd2 = new SqlCommand(query2, sqlConn);
            cmmnd2.CommandType = CommandType.Text;
            SqlDataAdapter da2 = new SqlDataAdapter(query2, sqlConn);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);

            if (ds2.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].Rows[i]["discount"] = ds2.Tables[0].Rows[0][0];
                ds.Tables[0].Rows[i]["promotion"] = ds2.Tables[0].Rows[0][1];
            }
            else
            {
                ds.Tables[0].Rows[i]["discount"] = 0;
                ds.Tables[0].Rows[i]["promotion"] = "";
            }

        }
        return ds;
    }

    public DataSet searchDeal(String search, String srchBy)
    {
        string query;
        if (srchBy == "dealID")
            query = "SELECT p.PID,pname,company,price FROM Product p,Deals dr WHERE p.PID=dr.PID AND " +
                srchBy + " LIKE '%" + search + "%'";
        else
            query = "SELECT PID,pname,company,price FROM Product WHERE " + srchBy + " LIKE '%" + search + "%'";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        int rowc = ds.Tables[0].Rows.Count;

        ds.Tables[0].Columns.Add("discount", typeof(string));
        ds.Tables[0].Columns.Add("deal", typeof(string));

        for (int i = 0; i < rowc; i++)
        {
            int id = (int)ds.Tables[0].Rows[i][0];
            String query2 = "SELECT discount,deal FROM Deals WHERE PID=" + id;
            SqlCommand cmmnd2 = new SqlCommand(query2, sqlConn);
            cmmnd2.CommandType = CommandType.Text;
            SqlDataAdapter da2 = new SqlDataAdapter(query2, sqlConn);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);

            if (ds2.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].Rows[i]["discount"] = ds2.Tables[0].Rows[0][0];
                ds.Tables[0].Rows[i]["deal"] = ds2.Tables[0].Rows[0][1];
            }
            else
            {
                ds.Tables[0].Rows[i]["discount"] = 0;
                ds.Tables[0].Rows[i]["deal"] = "";
            }

        }
        return ds;
    }

    public int insertProductFeedbak(ProductFeedback ProductFeedback)
    {
        string insertProductFeedbak;
        //if (ProductFeedback.CusID == 0)
        //insertProductFeedbak = "INSERT INTO ProductFeedback(PID,cusID,pro_rating,pro_feedback) VALUES(null,null,@pro_rating,@pro_feedback)";
        //else
        insertProductFeedbak = "INSERT INTO ProductFeedback(PID,cusID,pro_rating,pro_feedback) VALUES(@PID,@cusID,@pro_rating,@pro_feedback)";

        SqlCommand cmmnd = new SqlCommand(insertProductFeedbak, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PID", ProductFeedback.PID1);
        cmmnd.Parameters.AddWithValue("@cusID", ProductFeedback.CusID);
        cmmnd.Parameters.AddWithValue("@pro_rating", ProductFeedback.Pro_rating);
        cmmnd.Parameters.AddWithValue("@pro_feedback", ProductFeedback.Pro_feedback);

        return cmmnd.ExecuteNonQuery();
    }

    public DataSet getPromDisc(String pid)
    {
        string query = "SELECT * FROM Promotions WHERE PID="+pid;
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    public DataSet getDealDisc(String pid)
    {
        string query = "SELECT * FROM Deals WHERE PID=" + pid;
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    public int insertProm(String id,String disc,String prom)
    {
        string query = "INSERT INTO Promotions(PID,discount,promotion) VALUES(@id,@disc,@prom)";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@id", id);
        cmmnd.Parameters.AddWithValue("@disc", disc);
        cmmnd.Parameters.AddWithValue("@prom", prom);

        return cmmnd.ExecuteNonQuery();
    }

    public int insertDeals(String id, String disc, String deal)
    {
        ////////
        String query2 = "SELECT PID FROM Deals where PID='" + id + "'";
        SqlCommand cmmnd2 = new SqlCommand(query2, sqlConn);
        cmmnd2.CommandType = CommandType.Text;
        SqlDataAdapter da2 = new SqlDataAdapter(query2, sqlConn);
        DataSet ds2 = new DataSet();
        da2.Fill(ds2);

        if (ds2.Tables[0].Rows.Count == 0)
        {
            string query = "INSERT INTO Deals(PID,discount,deal) VALUES(@id,@disc,@deal)";
            SqlCommand cmmnd = new SqlCommand(query, sqlConn);

            cmmnd.CommandType = CommandType.Text;

            cmmnd.Parameters.AddWithValue("@id", id);
            cmmnd.Parameters.AddWithValue("@disc", disc);
            cmmnd.Parameters.AddWithValue("@deal", deal);

            return cmmnd.ExecuteNonQuery();
        }
        else
        {
            return -1;
        }
    }

    public int removeProm(String id)
    {
        string query = "DELETE FROM Promotions WHERE PID=" +id;
        //Debug.WriteLine(query);
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);

        cmmnd.CommandType = CommandType.Text;
        return cmmnd.ExecuteNonQuery();
    }

    public int removeDeals(String id)
    {
        string query = "DELETE FROM Deals WHERE PID=" + id;
        //Debug.WriteLine(query);
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);

        cmmnd.CommandType = CommandType.Text;
        return cmmnd.ExecuteNonQuery();
    }

    public DataSet getProdFeed(int pid)
    {
        string query = "SELECT pro_rating,pro_feedback FROM ProductFeedback where PID=" + pid;
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);        
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    public int insertNewList(String uid, String liName)
    {
        ///////
        string query = "SELECT listName FROM wishlist where listName='" + liName + "'";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count != 0)
        {
            //Debug.WriteLine(ds.Tables[0].Rows.Count);
            return -1;
        }
        else
        {
            query = "INSERT INTO wishlist(cusID,listName) VALUES(@uid,@liName)";
            cmmnd = new SqlCommand(query, sqlConn);

            cmmnd.CommandType = CommandType.Text;

            cmmnd.Parameters.AddWithValue("@uid", uid);
            cmmnd.Parameters.AddWithValue("@liName", liName);

            return cmmnd.ExecuteNonQuery();
        }

    }

    public DataSet getWishListNames(int uid)
    {
        
        string query = "SELECT listName FROM wishlist where cusID=" + uid;
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }


    public DataSet getWishListnames(int cusid)
    {
        
        string query = "SELECT listName FROM wishlist where cusID=" + cusid;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }


    public int insertWishListItem(String liName, String prodId, String memo)
    {
        string query = "SELECT listId FROM wishlist where listName='" + liName + "'";
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        String listId = ds.Tables[0].Rows[0][0].ToString();


        //check product already exist in selected list
        query = "SELECT productID FROM wishlistItems where productID='" + prodId + "' AND listId='" + listId+"'";
        SqlCommand cmmnd2 = new SqlCommand(query, sqlConn);
        cmmnd2.CommandType = CommandType.Text;
        SqlDataAdapter da2 = new SqlDataAdapter(query, sqlConn);
        DataSet ds2 = new DataSet();
        da2.Fill(ds2);

        if (ds2.Tables[0].Rows.Count == 0 )
        {

            query = "INSERT INTO wishlistItems(listId,productID,memo) VALUES(@listId,@productID,@memo)";
            cmmnd = new SqlCommand(query, sqlConn);

            cmmnd.CommandType = CommandType.Text;

            cmmnd.Parameters.AddWithValue("@listId", listId);
            cmmnd.Parameters.AddWithValue("@productID", prodId);
            cmmnd.Parameters.AddWithValue("@memo", memo);

            return cmmnd.ExecuteNonQuery();
        }
        else
        {
            return -1;
        }
    }

    public void BindGrid(GridView gvname,String pid)
    {
        //SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString1"].ConnectionString);

        SqlDataAdapter da = new SqlDataAdapter("select PID,pname,condition,company,price,modle,description,height,width,depth,priority,availability,category,subCategory,Image from Product where PID=" + pid, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }


    public void BindGridpro_comment(GridView gvname, int pid)
    {
        SqlDataAdapter da = new SqlDataAdapter("select PID,pname,company,price,Image from Product where PID=" + pid, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /// <summary>
    /// gridwiew fill with given product
    /// </summary>
    /// <param name="gvname">return dataset</param>
    /// <param name="pid">product id</param>
    public void BindGridpro_ratings(GridView gvname, int pid)
    {
        SqlDataAdapter da = new SqlDataAdapter("select PID,pname,company,price,Image from Product where PID=" + pid, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    public void BindGridViewList(GridView gvname, String listName, int cusId)
    {
        String query = "select p.PID,p.pname,p.price,p.condition,p.company,p.Image from wishlist w, wishlistItems wi,Product p where wi.productID = p.PID AND w.listId=wi.listId AND w.listName='" + listName + "' AND w.cusID=" + cusId;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    public int removeWishItem(String listName,String prodid, int cusId)
    {
        string query = "DELETE wi FROM wishlistItems wi,wishlist w WHERE w.listId=wi.listId AND w.listName='" + listName + "' AND w.cusID=" + cusId + " AND wi.productID='" + prodid+"'";
        //Debug.WriteLine(query);
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        return cmmnd.ExecuteNonQuery();
    }

    public int insertcomment(Comment comment1)
    {
        string insertcomment;
        insertcomment = "INSERT INTO comment(pId,uId,comment_des) VALUES(@PId,@UId,@Comment)";

        SqlCommand cmmnd = new SqlCommand(insertcomment, sqlConn);
        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId",comment1.PId);
        cmmnd.Parameters.AddWithValue("@UId", comment1.UId);
        cmmnd.Parameters.AddWithValue("@Comment", comment1.Comment_des);
       
        
        return cmmnd.ExecuteNonQuery();
    }


    /// <summary>
    /// update the buyGiftcard table, sentemail colunm by newly added email
    /// </summary>
    /// <param name="id">unique gift id</param>
    /// <param name="mail">sent email address</param>
    /// <returns>update the sentemail colunm</returns>
    public DataSet updateemail(String id,String mail)
    {
        string emaildb;
        emaildb = "UPDATE buyGiftcard SET sentemail='" + mail + "' where uniquegiftId='"+ id +"'";
        SqlDataAdapter da = new SqlDataAdapter(emaildb, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

   

    public int insertlike(Like1 lik)
    {
        string insertlike;
        insertlike = "INSERT INTO likes(pId,uId,count) VALUES(@PId,@UId,@like)";

        SqlCommand cmmnd = new SqlCommand(insertlike, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId", lik.PId);
        cmmnd.Parameters.AddWithValue("@UId", lik.UId);
        cmmnd.Parameters.AddWithValue("@like", lik.Count);

        return cmmnd.ExecuteNonQuery();
    }


    /// <summary>
    /// update the rates
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <param name="rate">star rate</param>
    /// <returns></returns>
    public DataSet updatestardb(int PId, int UId,int rate)
    {
        string stardb;
        stardb = "UPDATE StarRating SET Rate='" + rate + "' WHERE PID='" + PId + "'and CusID='" + UId + "' ";
        SqlDataAdapter da = new SqlDataAdapter(stardb, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    /// <summary>
    /// inseart the rates
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <param name="rate">star rate</param>
    /// <returns></returns>
    public int insertstar1(int PId, int UId, int rate)
    {
        string insertlike;
        insertlike = "INSERT INTO StarRating(PID,CusID,Rate) VALUES(@PId,@UId,@rate)";

        SqlCommand cmmnd = new SqlCommand(insertlike, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId", PId);
        cmmnd.Parameters.AddWithValue("@UId", UId);
        cmmnd.Parameters.AddWithValue("@rate", rate);

        return cmmnd.ExecuteNonQuery();
    }

    /// <summary>
    /// inserting star rating
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <param name="rate">star rating</param>
    /// <returns>query execution of inserting values</returns>
    public int insertstar2(int PId, int UId, int rate)
    {
        string insertlike;
        insertlike = "INSERT INTO StarRating(PID,CusID,Rate) VALUES(@PId,@UId,@rate)";

        SqlCommand cmmnd = new SqlCommand(insertlike, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId", PId);
        cmmnd.Parameters.AddWithValue("@UId", UId);
        cmmnd.Parameters.AddWithValue("@rate", rate);

        return cmmnd.ExecuteNonQuery();
    }
    /// <summary>
    /// inserting star rating
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <param name="rate">star rating</param>
    /// <returns>query execution of inserting values</returns>
    public int insertstar3(int PId, int UId, int rate)
    {
        string insertlike;
        insertlike = "INSERT INTO StarRating(PID,CusID,Rate) VALUES(@PId,@UId,@rate)";

        SqlCommand cmmnd = new SqlCommand(insertlike, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId", PId);
        cmmnd.Parameters.AddWithValue("@UId", UId);
        cmmnd.Parameters.AddWithValue("@rate", rate);

        return cmmnd.ExecuteNonQuery();
    }

    /// <summary>
    /// inserting star rating
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <param name="rate">star rating</param>
    /// <returns>query execution of inserting values</returns>
    public int insertstar4(int PId, int UId, int rate)
    {
        string insertlike;
        insertlike = "INSERT INTO StarRating(PID,CusID,Rate) VALUES(@PId,@UId,@rate)";

        SqlCommand cmmnd = new SqlCommand(insertlike, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId", PId);
        cmmnd.Parameters.AddWithValue("@UId", UId);
        cmmnd.Parameters.AddWithValue("@rate", rate);

        return cmmnd.ExecuteNonQuery();
    }

    /// <summary>
    /// inserting star rating
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <param name="rate">star rating</param>
    /// <returns>query execution of inserting values</returns>
    public int insertstar5(int PId, int UId, int rate)
    {
        string insertlike;
        insertlike = "INSERT INTO StarRating(PID,CusID,Rate) VALUES(@PId,@UId,@rate)";

        SqlCommand cmmnd = new SqlCommand(insertlike, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PId", PId);
        cmmnd.Parameters.AddWithValue("@UId", UId);
        cmmnd.Parameters.AddWithValue("@rate", rate);

        return cmmnd.ExecuteNonQuery();
    }

    public DataSet checkuid(int UId,int PId)
    {
        String checkuid;
        checkuid = "SELECT uId,pId FROM likes where uId='" + UId + "'and pId='" +PId +"'";
        //Debug.WriteLine(checkuid);
        SqlDataAdapter da = new SqlDataAdapter(checkuid, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;

    }

    /// <summary>
    /// check the rate is given by uer and product
    /// </summary>
    /// <param name="PId">product id</param>
    /// <param name="UId">user id</param>
    /// <returns></returns>
    public DataSet checkstar(int PId, int UId)
    {
        String checkuid1;
        checkuid1 = "SELECT PID,CusID FROM StarRating where PID='" + PId + "'and CusID='" + UId + "'";
        //Debug.WriteLine(checkuid1);
        SqlDataAdapter da = new SqlDataAdapter(checkuid1, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;

    }

    public int dislike(int UId)
    {
        string dislike;
        dislike = "DELETE FROM likes WHERE uId=" + UId;

        SqlCommand cmmnd = new SqlCommand(dislike, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        return cmmnd.ExecuteNonQuery();

    }

    public DataSet getProLikes(int pid)
    {
        string query = "SELECT COUNT(count) FROM likes where pId=" + pid + " GROUP BY uId";
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    public DataSet getProLikes_color(int pid ,int cusid)
    {
        string query = "SELECT COUNT(count) FROM likes where pId=" + pid + " AND uId=" +cusid+ " GROUP BY uId";
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }
    
        public DataSet viewProComment(int pid)
    {
        string query = "SELECT comment_des FROM comment where PId=" + pid ;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }


    public DataSet displaycommbutton(int pid, int uid)
    {
        string query = "SELECT uId FROM comment where pId =" +pid +"AND uId=" + uid;
        //Debug.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }


    public int removecomment(int id)
    {
        string query = "DELETE FROM comment WHERE uId=" + id;
        //Debug.WriteLine(query);
        SqlCommand cmmnd = new SqlCommand(query, sqlConn);
        cmmnd.CommandType = CommandType.Text;
        return cmmnd.ExecuteNonQuery();
    }

    public void BindGridViewListDeals(GridView gvname)
    {

        String query = "select p.PID,p.pname,p.company,p.Image,p.price,d.discount,d.endDate from Deals d, Product p where d.PID = p.PID AND d.endDate > GETDATE()";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    public string getExpireDate(string pid)
    {
        String query = "select endDate from Deals where PID =" + pid;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string date = ds.Tables[0].Rows[0][0].ToString();
        return date;
    }

    /// <summary>
    /// get the end date from the database
    /// </summary>
    /// <param name="pid">product id</param>
    /// <returns>end date according to the product id</returns>
    public string getExpireDatepromo(string pid)
    {
        String query = "select endDate from Promotions where PID =" + pid;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string date = ds.Tables[0].Rows[0][0].ToString();
        return date;
    }

    public void BindGrid_viewdeal(GridView gvname,String pid)
    {

        String query = "select p.PID,p.pname,p.company,p.Image,d.discount,d.endDate, cast(ROUND(p.price*(100.0-d.discount)/100.0,2) AS NUMERIC(38,2)) AS price from Deals d, Product p where d.PID =p.PID AND d.PID = " + pid;
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /// <summary>
    /// get the data set of given gift id
    /// </summary>
    /// <param name="gvname">return dataset of the item</param>
    /// <param name="gid">give gift id to the function</param>
   public void BindGrid_viewgiftcard(GridView gvname, String gid)
    {
       String query = "select d.giftId,d.image,d.price,d.quantity from addGiftcard d where d.giftId = " + gid;
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();
   }

    /// <summary>
    /// selecting values by buy gift card id
    /// </summary>
    /// <param name="gvname">dataset of retrun valuves</param>
    /// <param name="BgiftId">buy gift card id</param>
   public void BindGrid_getGiftcard(GridView gvname, String BgiftId)
    {

        String query = "select d.giftId,g.BgiftId,d.image,g.uniquegiftId from addGiftcard d, buyGiftcard g where d.giftId=g.giftId AND g.BgiftId = " + BgiftId;
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /// <summary>
    /// slsecting unique number
    /// </summary>
    /// <param name="id">gift id</param>
    /// <returns>unique number</returns>
   public string getuniqenum(string id)
    {
        String query = "select uniquegiftId from buyGiftcard where giftId =" + id;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string uninum = ds.Tables[0].Rows[0][0].ToString();
        return uninum;
    }

    /// <summary>
    /// display gift card details in the grid view by using user id 
    /// </summary>
    /// <param name="gvname">return dataset of the given items</param>
    /// <param name="uid">give user id to get values </param>
   public void BindGrid_uniqviewgiftcard(GridView gvname, String uid)
    {
       String query = "select g.BgiftId,d.giftId,d.category,d.price,g.uniquegiftId,g.sentemail from addGiftcard d,buyGiftcard g where d.giftId=g.giftId AND g.uId = " + uid;
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();
   }

    /// <summary>
    /// display target item values
    /// </summary>
    /// <param name="gvname">dataset of given column itms</param>
    /// <param name="pid">product id</param>
    public void BindGrid_viewpromo(GridView gvname, String pid)
    {
        String query = "select p.PID,p.pname,p.company,p.Image,d.discount,d.endDate, cast(ROUND(p.price*(100.0-d.discount)/100.0,2) AS NUMERIC(38,2)) AS price from Promotions d, Product p where d.PID =p.PID AND d.PID = " + pid;
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();
    }

   /// <summary>
   /// inserting gift cards to the database
   /// </summary>
    /// <param name="Category">Gift card Category</param>
    /// <param name="Price">Gift card Price</param>
    /// <param name="Quantity">Gift card Quantity</param>
    /// <param name="Image">Gift card Image</param>
    /// <returns>query execution of gift cards</returns>
    public int insertgiftcerds(string Category, int Price, int Quantity, byte[] Image)
    {
        string insertgiftcerd;
        insertgiftcerd = "INSERT INTO addGiftcard(category,price,quantity,image) VALUES(@Category,@Price,@Quantity,@Image)";

        SqlCommand cmmnd = new SqlCommand(insertgiftcerd, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@Category", Category);
        cmmnd.Parameters.AddWithValue("@Price", Price);
        cmmnd.Parameters.AddWithValue("@Quantity", Quantity);
        cmmnd.Parameters.AddWithValue("@Image", Image);
        
        return cmmnd.ExecuteNonQuery();
    }

    /// <summary>
    /// update the quntity of the gift card
    /// </summary>
    /// <param name="qty">gift card quntity</param>
    /// <returns>updated quantity</returns>
    public DataSet updateQtygiftcerds(int qty)
    {
        string qtydb;
        qtydb = "UPDATE addGiftcard SET quantity=quantity-'" + qty + "' ";
        SqlDataAdapter da = new SqlDataAdapter(qtydb, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;
    }

    /// <summary>
    /// give gift id and get the quntity of the database
    /// </summary>
    /// <param name="getQty">give gift id</param>
    /// <returns>return quntity of the giftcard</returns>
    public string selesctQtygiftcerds(int getQty)
    {
        String query = "select quantity from addGiftcard where giftId =" + getQty;
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string num = ds.Tables[0].Rows[0][0].ToString();
        return num;
    }
    /// <summary>
    /// inserting values to the buyGiftcard table
    /// </summary>
    /// <param name="UniqueId">return unique id</param>
    /// <param name="gId">return gift id</param>
    /// <param name="uId">return user id</param>
    /// <returns>inserting values</returns>
    public int insertQtygiftcerds(String UniqueId,int gId,int uId)
    {
        string insertgiftcerd;
        insertgiftcerd = "INSERT INTO buyGiftcard(uniquegiftId,giftId,uId) VALUES(@UniqueId,@gId,@uId)";

        SqlCommand cmmnd = new SqlCommand(insertgiftcerd, sqlConn);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@UniqueId", UniqueId);
        cmmnd.Parameters.AddWithValue("@gId", gId);
        cmmnd.Parameters.AddWithValue("@uId", uId);
        
        return cmmnd.ExecuteNonQuery();
    }

    /// <summary>
    /// Get the items of category common 
    /// </summary>
    /// <param name="gvname">return category "common" data set</param>
    public void BindGridViewGiftcard_common(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Common'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /// <summary>
    /// Get the items of category Electronics
    /// </summary>
    /// <param name="gvname">return category "Electronics" data set</param>
    public void BindGridViewGiftcard_elec(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Electronics'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }
    
    /// <summary>
    /// Get the items of category Collectibles & Art
    /// </summary>
    /// <param name="gvname">return category "Collectibles & Art" data set</param>
    public void BindGridViewGiftcard_fashion(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Collectibles & Art'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /// <summary>
    /// Get the items of category Home & Garden
    /// </summary>
    /// <param name="gvname">return category "Home & Garden" data set</param>
    public void BindGridViewGiftcard_coll(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Home & Garden'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }
       
    /// <summary>
    /// Get the items of category Sporting Goods
    /// </summary>
    /// <param name="gvname">return category "Sporting Goods" data set</param>
    public void BindGridViewGiftcard_home(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Sporting Goods'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }
      
    /// <summary>
    /// Get the items of category Motors
    /// </summary>
    /// <param name="gvname">return category "Motors" data set</param>
    public void BindGridViewGiftcard_sport(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Motors'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }
        
    /// <summary>
    /// Get the items of category Fashion
    /// </summary>
    /// <param name="gvname">return category "Fashion" data set</param>
    public void BindGridViewGiftcard_moto(GridView gvname)
    {

        String query = "select g.giftId,g.image,g.price,g.quantity from addGiftcard g WHERE g.category = 'Fashion'";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /// <summary>
    /// get current date and display not expire items
    /// </summary>
    /// <param name="gvname">return given data set</param>
    public void BindGridViewListPromotions(GridView gvname)
    {
        String query = "select p.PID,p.pname,p.company,p.Image,p.price,d.discount,d.endDate from Promotions d, Product p where d.PID = p.PID AND d.endDate > GETDATE()";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }
}