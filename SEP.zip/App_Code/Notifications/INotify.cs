﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for INotify
/// </summary>
public interface INotify
{
    void Subscribe(ISubscriber i);
    void Unsubscribe(ISubscriber i);
    void NotifyAll();
}