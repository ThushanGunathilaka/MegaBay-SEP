﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Notification
/// </summary>
public class Notification :INotify
{
    private List<ISubscriber> subscribers;
    private List<string> archive;

    public Notification()
    {
        subscribers = new List<ISubscriber>();
        archive = new List<string>();
    }

    public void NotifyAll()
    {
        foreach (ISubscriber i in subscribers)
        {
            i.Update(archive[archive.Count - 1]);
        }
    }

    public void Subscribe(ISubscriber i)
    {
        subscribers.Add(i);
    }

    public void Unsubscribe(ISubscriber i)
    {
        subscribers.Remove(i);
    }

    public void PublishNotification(string notification)
    {
        archive.Add(notification);
        ArchiveChanged();
    }

    private void ArchiveChanged()
    {
        NotifyAll();
    }
}