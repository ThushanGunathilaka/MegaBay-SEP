﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EmailEvents
/// </summary>
public class EmailEvents
{
    private string eMail;
    private List<string> eMailArchive;

    public string Email
    {
        get { return eMail; }
        set
        {
            if (!eMailArchive.Contains(value))
            {
                eMailArchive.Add(value);
            }
            eMail = value;
        }
    }

    public List<string> EmailArchive
    {
        get { return eMailArchive; }
        set
        {
            eMailArchive = value;
        }
    }

    public EmailEvents(string eMail)
    {
        this.eMail = eMail;
        eMailArchive = new List<string>();
    }
}