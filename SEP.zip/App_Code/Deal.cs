﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Deal
/// </summary>
public class Deal
{
	public Deal()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    int PID;

    public int PID1
    {
        get { return PID; }
        set { PID = value; }
    }


    int discount;

    public int Discount
    {
        get { return discount; }
        set { discount = value; }
    }


    String deal;

    public String Deal1
    {
        get { return deal; }
        set { deal = value; }
    }

    DateTime startDate;

    public DateTime StartDate
    {
        get { return startDate; }
        set { startDate = value; }
    }

    DateTime endDate;

    public DateTime EndDate
    {
        get { return endDate; }
        set { endDate = value; }
    }
}