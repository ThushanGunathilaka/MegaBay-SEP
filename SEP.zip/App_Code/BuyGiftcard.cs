﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BuyGiftcard
/// </summary>
public class BuyGiftcard
{
	public BuyGiftcard()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int uniquegiftId;

    public int UniquegiftId
    {
        get { return uniquegiftId; }
        set { uniquegiftId = value; }
    }

    String category;

    public String Category
    {
        get { return category; }
        set { category = value; }
    }
    int price;

    public int Price
    {
        get { return price; }
        set { price = value; }
    }

    int quantity;

    public int Quantity
    {
        get { return quantity; }
        set { quantity = value; }
    }

    byte[] image;

    public byte[] Image
    {
        get { return image; }
        set { image = value; }
    }
}