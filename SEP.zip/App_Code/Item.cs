﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Item
/// </summary>
public class Item
{
	public Item()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    int CusID;

    public int CusID1
    {
        get { return CusID; }
        set { CusID = value; }
    }
string size;

    public string Size
    {
        get { return size; }
        set { size = value; }
    }
    string colour;

    public string Colour
    {
        get { return colour; }
        set { colour = value; }
    }
    string material;

    public string Material
    {
        get { return material; }
        set { material = value; }
    }

    int PID;

    public int productID
    {
        get { return PID; }
        set { PID = value; }
    }

    string pname;

    public string Pname
    {
        get { return pname; }
        set { pname = value; }
    }

    string tipsAdd;

    public string TipsAdd
    {
        get { return tipsAdd; }
        set { tipsAdd = value; }
    }

    string message;

    public string Message
    {
        get { return message; }
        set { message = value; }
    }


    string promotion;

    public string Promotion
    {
        get { return promotion; }
        set { promotion = value; }
    }

    string gender;

    public string Gender
    {
        get { return gender; }
        set { gender = value; }
    }


    string condition;



    public string Condition
    {
        get { return condition; }
        set { condition = value; }
    }
    string Company;

    public string Company1
    {
        get { return Company; }
        set { Company = value; }
    }
    byte[] image;

    public byte[] Image
    {
        get { return image; }
        set { image = value; }
    }
    //new
    double price;

    public double Price
    {
        get { return price; }
        set { price = value; }
    }
    string modle;

    public string Modle
    {
        get { return modle; }
        set { modle = value; }
    }
    string description;

    public string Description
    {
        get { return description; }
        set { description = value; }
    }
    double height;

    public double Height
    {
        get { return height; }
        set { height = value; }
    }
    double width;

    public double Width
    {
        get { return width; }
        set { width = value; }
    }
    double depth;

    public double Depth
    {
        get { return depth; }
        set { depth = value; }
    }
    string priority;

    public string Priority
    {
        get { return priority; }
        set { priority = value; }
    }
    string availability;

    public string Availability
    {
        get { return availability; }
        set { availability = value; }
    }
    string comment;

    public string Comment
    {
        get { return comment; }
        set { comment = value; }
    }
    string feedback;

    public string Feedback
    {
        get { return feedback; }
        set { feedback = value; }
    }
    string category;

    public string Category
    {
        get { return category; }
        set { category = value; }
    }
    string subCategory;

    public string SubCategory
    {
        get { return subCategory; }
        set { subCategory = value; }
    }
    int rating;

    public int Rating
    {
        get { return rating; }
        set { rating = value; }
    }
    DateTime addedDate;

    public DateTime AddedDate
    {
        get { return addedDate; }
        set { addedDate = value; }
    }
    DateTime expDate;

    public DateTime ExpDate
    {
        get { return expDate; }
        set { expDate = value; }
    }

    
    
}
