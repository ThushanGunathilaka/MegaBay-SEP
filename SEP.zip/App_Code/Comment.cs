﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Comment
/// </summary>

public class Comment
{
	public Comment()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    int pId;
    int uId;

    public int UId
    {
        get { return uId; }
        set { uId = value; }
    }
    String comment_des;

    public String Comment_des
    {
        get { return comment_des; }
        set { comment_des = value; }
    }

   

    public int PId
    {
        get { return pId; }
        set { pId = value; }
    }

}