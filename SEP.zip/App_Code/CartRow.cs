﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CartRow
/// </summary>
public class CartRow
{
	public CartRow()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string image;
    public string name;
    public string price;
    public string items;
}