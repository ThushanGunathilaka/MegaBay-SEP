﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for catdata
/// </summary>
public class catdata
{
	public catdata()
	{}
		//
		// TODO: Add constructor logic here
		//
        Boolean catvalue;
        public Boolean Value
    {
        get { return catvalue; }
        set { catvalue = value; }
    }

        string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        string idname;
        public string Idname
        {
            get { return idname; }
            set { idname = value; }
        }

        string parent;
        public string Parent
        {
            get { return parent; }
            set { parent = value; }
        }
}