﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for JavascriptWrapper
/// </summary>
public static class JavascriptWrapper
{

    public static string Serialize(object o)
    {
        JavaScriptSerializer js = new JavaScriptSerializer();
        return js.Serialize(o);
    }

   // public static string Serializer(object o)
//{
    // logic
    // Edit you don't need to serialize it just return the object

   // return Newtonsoft.Json.JsonConvert.SerializeObject(o); ;
//}




}