﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Like1
/// </summary>
public class Like1
{
	public Like1()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int pId;

    public int PId
    {
        get { return pId; }
        set { pId = value; }
    }
    int count;

    public int Count
    {
        get { return count; }
        set { count = value; }
    }

    int uId;

    public int UId
    {
        get { return uId; }
        set { uId = value; }
    }

    
}