﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Author : IT13024482 N.H.P. Ravi Supunya
/// Project : E marketing portal 
/// This is the class to handle data of bidding.
/// </summary>
public class BidItem
{
	public BidItem()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    int cusID;

    public int CusID
    {
        get { return cusID; }
        set { cusID = value; }
    }
    int bidItemId;

    public int BidItemId
    {
        get { return bidItemId; }
        set { bidItemId = value; }
    }
    string bItemName;

    public string BItemName
    {
        get { return bItemName; }
        set { bItemName = value; }
    }
    decimal bItemPrice;

    public decimal BItemPrice
    {
        get { return bItemPrice; }
        set { bItemPrice = value; }
    }
    string bDescription;

    public string BDescription
    {
        get { return bDescription; }
        set { bDescription = value; }
    }
    byte[] image;

    public byte[] Image
    {
        get { return image; }
        set { image = value; }
    }
    DateTime bEndDate;

    public DateTime BEndDate
    {
        get { return bEndDate; }
        set { bEndDate = value; }
    }
}