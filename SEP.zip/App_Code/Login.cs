﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Login
/// </summary>
public class Login1
{
	public Login1()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private String username;
    private String password;
    public static User user;

    public Login1(string username, string password)
    {
        User.getUser(username, password);
    }
}