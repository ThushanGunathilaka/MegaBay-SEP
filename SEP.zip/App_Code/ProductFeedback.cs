﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ProductFeedback
/// </summary>
public class ProductFeedback
{
	public ProductFeedback()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int PID;
    int cusID;
    int pro_rating;
    string pro_feedback;

    public int PID1
    {
        get { return PID; }
        set { PID = value; }
    }
    

    public int CusID
    {
        get { return cusID; }
        set { cusID = value; }
    }
    

    public int Pro_rating
    {
        get { return pro_rating; }
        set { pro_rating = value; }
    }
    

    public string Pro_feedback
    {
        get { return pro_feedback; }
        set { pro_feedback = value; }
    }

    

    


}