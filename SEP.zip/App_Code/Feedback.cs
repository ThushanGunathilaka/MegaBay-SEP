﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Feedback
/// </summary>
public class Feedback
{
	public Feedback()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    String feedBack;
    String user;
    int rating;

    public int Rating
    {
        get { return rating; }
        set { rating = value; }
    }

    public String User
    {
        get { return user; }
        set { user = value; }
    }
    
    public String FeedBack
    {
        get { return feedBack; }
        set { feedBack = value; }
    }
}