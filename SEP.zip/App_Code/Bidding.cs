﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

/// <summary>
/// Author : IT13024482 N.H.P. Ravi Supunya
/// Project : E marketing portal 
/// This is the class to handle all operations of bidding.
/// </summary>
public class Bidding
{
	public Bidding()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

    /*Inset item method will insert bidding items to bid list
     * When Admin click Add Item on AddItemsToBid.aspx this method will fire.
     * */
    public int insertItem(BidItem item)
    {

        conn1.Open();

        string insertItem = "INSERT INTO BiddingItems(ItemName,ItemPrice,Description,Image,BidEndDate) VALUES(@ItemName,@ItemPrice,@Description,@Image,@BidEndDate)";

        SqlCommand cmmnd = new SqlCommand(insertItem, conn1);

        cmmnd.CommandType = CommandType.Text;
        cmmnd.Parameters.AddWithValue("@ItemName", item.BItemName);
        cmmnd.Parameters.AddWithValue("@ItemPrice", item.BItemPrice);
        cmmnd.Parameters.AddWithValue("@Description", item.BDescription);
        cmmnd.Parameters.AddWithValue("@Image", item.Image);
        cmmnd.Parameters.AddWithValue("@BidEndDate", item.BEndDate);
        
        return cmmnd.ExecuteNonQuery();
    }

    /*Place bid method will Place a new bid.Then a customer clicks Place bid button on
     * VwBidItem.aspx,This method will work.
     * */
    public int PlaceBid(BidItem item)
    {
        
            conn1.Open();

            string insertItem = "INSERT INTO BiddingDetails(ItemId,CusID,Price) VALUES(@ItemId,@CusID,@Price)";

            SqlCommand cmmnd = new SqlCommand(insertItem, conn1);

            cmmnd.CommandType = CommandType.Text;
            cmmnd.Parameters.AddWithValue("@ItemId", item.BidItemId);
            cmmnd.Parameters.AddWithValue("@CusID", item.CusID);
            cmmnd.Parameters.AddWithValue("@Price", item.BItemPrice);
            return cmmnd.ExecuteNonQuery();  
    }

    /*This method updates price of Bidding items into maximum bid of that item.
     * This fires while a customer placing a new bid
     * */
    public int UpdateBidPrice(BidItem item)
    {
        string insertItem = "Update BiddingItems set ItemPrice=@Price where ItemId=@ItemId";

        SqlCommand cmmnd = new SqlCommand(insertItem, conn1);

        cmmnd.CommandType = CommandType.Text;
        cmmnd.Parameters.AddWithValue("@ItemId", item.BidItemId);
        cmmnd.Parameters.AddWithValue("@Price", item.BItemPrice);
        return cmmnd.ExecuteNonQuery();
    }

    /*This loads details of items in bidlist
     * When a user click on View items in bidlist on MyAccount.aspx this method will fire.
     * */
    public void BindGridViewForBidList(GridView gvname)
    {

        String query = "select ItemId,ItemName,ItemPrice,Description,Image,BidEndDate from BiddingItems where BidEndDate > GETDATE()";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, conn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /*This method loads details of seperate item when a user click on View product 
     * on VwBidItems.aspx
     * */
    public void BindGridViewForSeperateBid(GridView gvname,string pid)
    {

        String query = "select ItemId,ItemName,ItemPrice,Description,Image,BidEndDate from BiddingItems where BidEndDate > GETDATE() and ItemId="+pid+"";
        Console.WriteLine(query);
        SqlDataAdapter da = new SqlDataAdapter(query, conn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvname.DataSource = ds;
        gvname.DataBind();

    }

    /*This method get expiredate of bid on selected item
     * 
     * */
    public string getExpireDate(string pid)
    {
        String query = "select BidEndDate from BiddingItems where ItemId =" + pid;
        SqlDataAdapter da = new SqlDataAdapter(query, conn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string date = ds.Tables[0].Rows[0][0].ToString();
        return date;
    }

    /*This method will get number of bids for a selected item.
     */
    public string getNoOfBids(string pid)
    {
        String query = "select COUNT(CusID) from BiddingDetails where ItemId =" + pid;
        SqlDataAdapter da = new SqlDataAdapter(query, conn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string bids = ds.Tables[0].Rows[0][0].ToString();
        return bids;
    }

    /*This will get current maximum bid for a selected item
     * 
     * */
    public string getCurrentMaxPrice(string pid)
    {
        String query = "select ISNULL(Max(Price),0) from BiddingDetails where ItemId =" + pid;
        SqlDataAdapter da = new SqlDataAdapter(query, conn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        string price = ds.Tables[0].Rows[0][0].ToString();
        return price;
    }

    /*This will find winners of bids on current day.
     * 
     * */
    public System.Data.DataTable FindWinners()
    {
        try
        {

            return RunSP_DataTable(conn1, "FindWinners");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    /*This will get winners on current day
     * 
     * */
    public System.Data.DataTable GetWinners()
    {
        try
        {

            return RunSP_DataTable(conn1, "GetWinners");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    /*This method is to execute store procedure that returns a data table
     * It will get SqlConnection name and Stored procedure name as parameters.
     * */
    public static DataTable RunSP_DataTable(SqlConnection conn, string SPName)
    {
        SqlDataReader rdr = null;


        try
        {
            conn.Open();

            SqlCommand cmd = new SqlCommand(SPName, conn);

            cmd.CommandType = CommandType.StoredProcedure;

            rdr = cmd.ExecuteReader();

            DataTable dt = new DataTable();

            dt.Load(rdr);

            return dt;
        }

        finally
        {
            if (conn != null)
            {
                conn.Close();
            }
            if (rdr != null)
            {
                rdr.Close();
            }
        }


    }

}