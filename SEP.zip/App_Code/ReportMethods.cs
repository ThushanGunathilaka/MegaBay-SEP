﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

/// <summary>
/// IT13024482 -N.H.P.Ravi Supunya.
/// E marketing portal system.
/// This is the class with all methods to execute store procedures to get data for reports
/// </summary>
public class ReportMethods
{
	public ReportMethods()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    //Make the connection
    SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
    //Get data to the best selling products report

    public System.Data.DataTable GetBestSellingProducts()
    {
        try
        {

            return RunSP_DataTable(conn1, "GetBestSellingProducts");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the best buyers report
    public System.Data.DataTable GetBestBuyers()
    {
        try
        {

            return RunSP_DataTable(conn1, "GetListOfBestBuyers");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the products with promotions report
    public System.Data.DataTable GetProductsWithPromotions()
    {
        try
        {

            return RunSP_DataTable(conn1, "GET_ProductsWithPromotions");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the prodducts with ratings report
    public System.Data.DataTable GetProductRatings()
    {
        try
        {

            return RunSP_DataTable(conn1, "GET_ProductsRatings");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the best sellers report
    public System.Data.DataTable GetBestSellers()
    {
        try
        {

            return RunSP_DataTable(conn1, "GetListOfBestSellers");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get details about all products 
    public System.Data.DataTable GetAllProducts()
    {
        try
        {

            return RunSP_DataTable(conn1, "GetProductsByCategory");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the My Products report
    public System.Data.DataTable GetMyProducts(int CusID)
    {
        try
        {
            SqlParameter[] paramList = new SqlParameter[] {
                
                new SqlParameter("@CusID", CusID) };
            return RunSP_DataTableWithParam(conn1, "GetProducts", paramList);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the products within given price range report
    public System.Data.DataTable GetProductsByPriceRange(decimal upperBound,decimal lowerBound)
    {
        try
        {
            SqlParameter[] paramList = new SqlParameter[] {
                
            new SqlParameter("@LowerBound", lowerBound),
            new SqlParameter("@UpperBound", upperBound)};
            return RunSP_DataTableWithParam(conn1, "GET_ProductsByPriceRange", paramList);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the products by category report
    public System.Data.DataTable GetProductsByCategory(string Category)
    {
        try
        {
            SqlParameter[] paramList = new SqlParameter[] {
                
                new SqlParameter("@category", Category) };
            return RunSP_DataTableWithParam(conn1, "GET_ProductsByCatName", paramList);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the products by added date report
    public System.Data.DataTable GetProductsByAddedDate(DateTime date)
    {
        try
        {
            SqlParameter[] paramList = new SqlParameter[] {
                
                new SqlParameter("@RegisteredDate", date) };
            return RunSP_DataTableWithParam(conn1, "GET_ProductsByRegisteredDate", paramList);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Get data to the transaction report
    public System.Data.DataTable GetTransactionReport(int CusID)
    {
        try
        {
            SqlParameter[] paramList = new SqlParameter[] {
                
                new SqlParameter("@CusID", CusID) };
            return RunSP_DataTableWithParam(conn1, "GetTransactionReport", paramList);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
    }

    //Method to retriewe a DataTable from database (Without parameters)
    public static DataTable RunSP_DataTable(SqlConnection conn, string SPName)
    {
        SqlDataReader rdr = null;


        try
        {
            conn.Open();

            SqlCommand cmd = new SqlCommand(SPName, conn);

            cmd.CommandType = CommandType.StoredProcedure;

            rdr = cmd.ExecuteReader();

            DataTable dt = new DataTable();

            dt.Load(rdr);

            return dt;
        }

        finally
        {
            if (conn != null)
            {
                conn.Close();
            }
            if (rdr != null)
            {
                rdr.Close();
            }
        }


    }

    //Method to retriewe a DataTable from database (With parameters)
    public static DataTable RunSP_DataTableWithParam(SqlConnection conn, string SPName, SqlParameter[] myParams)
    {
        SqlDataReader rdr = null;


        try
        {
            conn.Open();

            SqlCommand cmd = new SqlCommand(SPName, conn);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 600;
            cmd.Parameters.AddRange(myParams);

            rdr = cmd.ExecuteReader();

            DataTable dt = new DataTable();

            dt.Load(rdr);

            return dt;
        }

        finally
        {
            if (conn != null)
            {
                conn.Close();
            }
            if (rdr != null)
            {
                rdr.Close();
            }
        }


    }
}