﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; /*****************/
/// <summary>
/// Summary description for db_conn
/// </summary>
public class db_conn
{
    //static string EmarketingConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename='|DataDirectory|\Database.mdf';Integrated Security=True";
	static string EmarketingConnectionString=ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString; /**************/

    public SqlConnection connect()
	{
        SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);
        return conn1;
	}
}
