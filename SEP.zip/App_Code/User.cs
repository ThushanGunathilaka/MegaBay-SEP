﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for User
/// </summary>
public class User
{
	public User()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public  int uid;
    public  string username;
    public  string pwd;

    

    public static void getUser(string un, string pwd)
    {
        User user = new User();
        string EmarketingConnectionString = @"Data Source=RAVI\SQLEXPRESS;Initial Catalog=Eportal;Integrated Security=True";
        SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);

        SqlCommand commn = new SqlCommand("select * from ECustomer where username=@username,password=@password" , conn1);
        SqlDataReader myReader;
        commn.Parameters.Add("@username", SqlDbType.NVarChar).Value =user.username;
        commn.Parameters.Add("@password", SqlDbType.NVarChar).Value = user.pwd;
        conn1.Open();
        myReader = commn.ExecuteReader();
        while (myReader.Read())
        {
            user.uid = int.Parse( myReader.GetString(0));
            user.username = myReader.GetString(5);
            pwd  = myReader.GetString(6);

        }
        conn1.Close();
    }
}