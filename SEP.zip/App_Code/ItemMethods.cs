﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

/// <summary>
/// Summary description for Insert_Item
/// </summary>
public class Insert_Item
{
    public Insert_Item()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

   // SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);

    //Insert Items to database
   public int insertItem(Item item)
    {
        
        conn1.Open();

        string insertItem = "INSERT INTO Product(pname,condition,company,Image,CusID,price,modle,description,availability,category,subCategory,priority,height,width,depth,Size,Colour,Material,added_date,expire_date) VALUES(@pname,@condition,@company,@image,@CusID,@price,@modle,@description,@availability,@category,@subCategory,@priority,@height,@width,@depth,@Size,@Colour,@Material,@added_date,@expire_date)";

        SqlCommand cmmnd = new SqlCommand(insertItem, conn1);

        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@CusID", item.CusID1);
        cmmnd.Parameters.AddWithValue("@pname", item.Pname);
        cmmnd.Parameters.AddWithValue("@condition", item.Condition);
        cmmnd.Parameters.AddWithValue("@company", item.Company1);
        cmmnd.Parameters.AddWithValue("@image", item.Image);
        cmmnd.Parameters.AddWithValue("@price", item.Price);
        cmmnd.Parameters.AddWithValue("@modle", item.Modle);
        cmmnd.Parameters.AddWithValue("@description", item.Description);
        cmmnd.Parameters.AddWithValue("@availability", item.Availability);
        cmmnd.Parameters.AddWithValue("@category", item.Category);
        cmmnd.Parameters.AddWithValue("@subCategory", item.SubCategory);
        cmmnd.Parameters.AddWithValue("@priority", item.Priority);
        cmmnd.Parameters.AddWithValue("@height", item.Height);
        cmmnd.Parameters.AddWithValue("@width", item.Width);
        cmmnd.Parameters.AddWithValue("@depth", item.Depth);
        cmmnd.Parameters.AddWithValue("@Size", item.Size);
        cmmnd.Parameters.AddWithValue("@Colour", item.Colour);
        cmmnd.Parameters.AddWithValue("@Material", item.Material);
        cmmnd.Parameters.AddWithValue("@added_date", item.AddedDate);
        cmmnd.Parameters.AddWithValue("@expire_date", item.ExpDate);

        return cmmnd.ExecuteNonQuery();
    }

    //Update Items in database
  public  void updateItems(Item item)
    {
        conn1.Open();
        string insertItem = "update Product set pname=@pname,condition=@condition,company=@company,price=@price,modle=@modle,description=@description,Size=@Size,Colour=@Colour,Material=@Material,priority=@priority,availability=@availability,category=@category,subCategory=@subCategory,added_date=@added_date where PID=@PID";
        SqlCommand cmmnd = new SqlCommand(insertItem, conn1);
        cmmnd.CommandType = CommandType.Text;

        cmmnd.Parameters.AddWithValue("@PID", item.CusID1);
        cmmnd.Parameters.AddWithValue("@pname",item.Pname);
        cmmnd.Parameters.AddWithValue("@condition",item.Condition);
        cmmnd.Parameters.AddWithValue("@company", item.Company1);
        cmmnd.Parameters.AddWithValue("@price", item.Price);
        cmmnd.Parameters.AddWithValue("@modle", item.Modle);
        cmmnd.Parameters.AddWithValue("@description", item.Description);
       cmmnd.Parameters.AddWithValue("@Size", item.Size);
        cmmnd.Parameters.AddWithValue("@Colour", item.Colour);
        cmmnd.Parameters.AddWithValue("@Material", item.Material);
        cmmnd.Parameters.AddWithValue("@priority", item.Priority);
        cmmnd.Parameters.AddWithValue("@availability", item.Availability);
        cmmnd.Parameters.AddWithValue("@category", item.Category);
        cmmnd.Parameters.AddWithValue("@subCategory", item.SubCategory);
        cmmnd.Parameters.AddWithValue("@added_date", item.AddedDate);
        
        cmmnd.ExecuteNonQuery();

    }

    //Update Images
  public void updateImg(Item item)
  {
       conn1.Open();
       string updateImg = "update Product set Image=@image where PID=@PID";
       SqlCommand cmmnd2 = new SqlCommand(updateImg, conn1);
       cmmnd2.CommandType = CommandType.Text;
       cmmnd2.Parameters.AddWithValue("@PID", item.CusID1);
       cmmnd2.Parameters.AddWithValue("@image", item.Image);
       cmmnd2.ExecuteNonQuery();

  }

  public void BindGrid(GridView gvname,int CusID)
  {
      SqlDataAdapter da = new SqlDataAdapter("select PID,pname,condition,company,price,modle,description,height,width,depth,priority,availability,category,subCategory,Image from Product where CusID="+CusID+";", conn1);
      DataSet ds = new DataSet();
      da.Fill(ds);
      gvname.DataSource = ds;
      gvname.DataBind();

  }

  public string deleteItems(DropDownList listId)
  {
      conn1.Open();
      SqlCommand commn = new SqlCommand("DELETE FROM Product WHERE PID=" + listId.SelectedItem + ";", conn1);       
      commn.CommandType = CommandType.Text;
      commn.ExecuteNonQuery();
      conn1.Close();
      return "Data Deleted successfully!!!";
  }

}
    



