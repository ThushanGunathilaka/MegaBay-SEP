﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Promotion
/// </summary>
public class Promotion
{
	public Promotion()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int PID;
    int discount;
    String promotion;


    public int PID1
    {
        get { return PID; }
        set { PID = value; }
    }
    

    public int Discount
    {
        get { return discount; }
        set { discount = value; }
    }
    

    public String Promotion1
    {
        get { return promotion; }
        set { promotion = value; }
    }
}