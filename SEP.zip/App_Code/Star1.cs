﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Star1
/// </summary>
public class Star1
{
	public Star1()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int PID;

    public int PID1
    {
        get { return PID; }
        set { PID = value; }
    }

    int CusID;

    public int CusID1
    {
        get { return CusID; }
        set { CusID = value; }
    }

    int Rate;

    public int Rate1
    {
        get { return Rate; }
        set { Rate = value; }
    }
}