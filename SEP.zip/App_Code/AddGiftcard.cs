﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AddGiftcard
/// </summary>
public class AddGiftcard
{
	public AddGiftcard()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    int giftId;

    public int GiftId
    {
        get { return giftId; }
        set { giftId = value; }
    }

    String category;

    public String Category
    {
        get { return category; }
        set { category = value; }
    }
    int price;

    public int Price
    {
        get { return price; }
        set { price = value; }
    }
    
    int quantity;

    public int Quantity
    {
        get { return quantity; }
        set { quantity = value; }
    }

    byte[] image;

    public byte[] Image
    {
        get { return image; }
        set { image = value; }
    }
    
    
}