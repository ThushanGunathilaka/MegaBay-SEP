﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web;
using System.Net.Mail;

/// <summary>
/// Summary description for WebService
/// </summary>
/// 

[WebService]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{
    protected int link = -1;
    protected string host = "";
    public WebService()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    /*subscriber model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string saveSubscriber(String username, String email)
    {
        int rowsAffected = -1;
        using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
        {
            string cmdText = "SELECT * FROM subscriber WHERE email='" + email.Replace('\r', ' ').Replace('\n', ' ').Trim() + "';";
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conx);

            if (conx.State == System.Data.ConnectionState.Closed)
            {
                conx.Open();
            }

            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                return "You are already subscribed to our mailing list.";
            }

            if (conx.State != System.Data.ConnectionState.Closed)
            {
                conx.Close();
            }

            string haveAccount = "FALSE";
            string query = "insert into subscriber(email,haveAccount) values(@email,@haveAccount);";
            if (username != null && username.Length > 0) {
                haveAccount = "TRUE";
            }
            if (email != null && email.Length > 0)
            {
                try {
                    using (SqlCommand cmdx = new SqlCommand(query, conx))
                    {
                        cmdx.CommandType = CommandType.Text;
                        cmdx.Parameters.AddWithValue("@email", email.Replace('\r',' ').Replace('\n',' ').Trim());
                        cmdx.Parameters.AddWithValue("@haveAccount", haveAccount.Replace('\r', ' ').Replace('\n', ' ').Trim());
                        conx.Open();
                        rowsAffected = cmdx.ExecuteNonQuery();
                        conx.Close();
                    }
                    return "You are successfully subsribe to our mailing list.";
                }
                catch (SqlException e) {
                    return "Cannot connect with our servers at the moment. Please try again later!";
                }
            }
        }
            return "Unexpected Error Occured, Please try again!";
    }
    /*Unsubscriber model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string saveUnSubscriber(String username,String email)
    {
        using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
        {
            int count = 1;
            int rowsAffected = -1;
            string query = "delete from subscriber where email = @email;";
            if (username != null && username.Length > 0)
            {
                query += "update ECustomer set IsSubscriber ='false' where username=@username;";
                count = 2;
            }
            if (email != null && email.Length > 0)
            {
                try
                {
                    using (SqlCommand cmdx = new SqlCommand(query, conx))
                    {
                        cmdx.CommandType = CommandType.Text;
                        cmdx.Parameters.AddWithValue("@email", email.Replace('\r', ' ').Replace('\n', ' ').Trim());
                        if (username != null && username.Length > 0)
                        {
                            cmdx.Parameters.AddWithValue("@username", username);
                        }
                        conx.Open();
                        rowsAffected = cmdx.ExecuteNonQuery();
                        conx.Close();
                    }
                    if (rowsAffected == count)
                    {
                        return "You are successfully Unsubsribed from our mailing list.";
                    }
                    else {
                        return "You are not currently subscribed to our mailing list.";
                    }
                }
                catch (SqlException e)
                {
                    return "Cannot connect with our servers at the moment. Please try again later!";
                }
            }
        }
        return "Unexpected Error Occured, Please try again!";
    }
    /*Inquiry-model */
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string saveInquiry(String comment,String username, String email)
    {
        using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
        {
            string haveAccount = "FALSE";
            string query = "insert into inquiries(inqMessage,replyMail) values (@comment,@email);";
            if (username != null && username.Length > 0)
            {
                haveAccount = "TRUE";
                query = "insert into inquiries(inqMessage,userAccount,replyMail) values (@comment,@username,@email);";
            }

            if (email != null && comment != null && email.Length > 0 && comment.Length > 0)
            {
                try
                {
                    using (SqlCommand cmdx = new SqlCommand(query, conx))
                    {
                        cmdx.CommandType = CommandType.Text;
                        cmdx.Parameters.AddWithValue("@comment", comment);
                        if (haveAccount.CompareTo("TRUE")==0) {
                            cmdx.Parameters.AddWithValue("@username", username);
                        }
                        cmdx.Parameters.AddWithValue("@email", email);
                        conx.Open();
                        int rowsAffected = cmdx.ExecuteNonQuery();
                        conx.Close();
                    }
                    return "We`ll get back to you as soon as posible";
                }
                catch (SqlException e)
                {
                    return "Cannot connect with our servers at the moment. Please try again later!";
                }
            }
        }
        return "Unexpected Error Occured, Please try again!";
    }

    /*reply model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string sendReply(String to,String subject, String username, String email)
    {
        try {
            SendEmail(to, "Guest", "thushan.ddtmg@gmail.com", "MegaBay", subject, email, true);
            draftReply(to, subject, username, email);
            using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
            {
                string query = "update inquiries set isReplyed ='false' where inqMessage='"+ email + "'";

                using (SqlCommand cmdx = new SqlCommand(query, conx))
                {
                    cmdx.CommandType = CommandType.Text;
                    conx.Open();
                    int rowsAffected = cmdx.ExecuteNonQuery();
                    conx.Close();
                }
            }
                
            return "Reply sent successfully";
        }
        catch (Exception e) {
            return "Not Connected to the mail server";
        }
    }
    /*draft model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string draftReply(String to, String subject, String username, String email)
    {

        String to_temp = to;
        String subject_temp = subject;
        String username_temp = username;
        String email_temp = email;
        using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
        {

            if (to == null || to.Trim().CompareTo("") == 0)
            {
                to_temp = "";
            }
            if (subject == null || subject.Trim().CompareTo("") == 0)
            {
                subject_temp = "";
            }
            if (username == null || username.Trim().CompareTo("") == 0)
            {
                username_temp = "";
            }
            if (email == null || email.Trim().CompareTo("") == 0)
            {
                email_temp = "";
            }

            string query = "insert into messageDraft(draftTo,draftSubject,username,email) values (@to,@subject,@username,@email);";

            try
            {
                using (SqlCommand cmdx = new SqlCommand(query, conx))
                {
                    cmdx.CommandType = CommandType.Text;
                    cmdx.Parameters.AddWithValue("@to", to_temp);
                    cmdx.Parameters.AddWithValue("@subject", subject_temp);
                    cmdx.Parameters.AddWithValue("@username", username_temp);
                    cmdx.Parameters.AddWithValue("@email", email_temp);
                    conx.Open();
                    int rowsAffected = cmdx.ExecuteNonQuery();
                    conx.Close();
                }
                return "Draft Saved";
            }
            catch (SqlException e)
            {
                return "Cannot connect with our servers at the moment. Please try again later!";
            }

        }
    }
    /*newsletter draft model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string storeDraft(String subject, String username, string email)
    {

        String subject_temp = subject;
        String username_temp = username;
        String email_temp = email;
        using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
        {

            if (subject == null || subject.Trim().CompareTo("") == 0)
            {
                subject_temp = "";
            }
            if (username == null || username.Trim().CompareTo("") == 0)
            {
                username_temp = "";
            }
            if (email == null || email.Trim().CompareTo("") == 0)
            {
                email_temp = "";
            }

            string query = "insert into newsletterDraft(draftSubject,username,email) values (@subject,@username,@email);";

            try
            {
                using (SqlCommand cmdx = new SqlCommand(query, conx))
                {
                    cmdx.CommandType = CommandType.Text;
                    cmdx.Parameters.AddWithValue("@subject", subject_temp);
                    cmdx.Parameters.AddWithValue("@username", username_temp);
                    cmdx.Parameters.AddWithValue("@email", email_temp);
                    conx.Open();
                    int rowsAffected = cmdx.ExecuteNonQuery();
                    conx.Close();
                }
                return "Draft Saved";
            }
            catch (SqlException e)
            {
                return "Cannot connect with our servers at the moment. Please try again later!";
            }
        }
    }
    /*send reply model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string storeNewsLetter(String subject, String username, String email)
    {
        try
        {
            SendEmail("thushan.ddtmg@gmail.com", "Guest", "thushan.ddtmg@gmail.com", "MegaBay", subject, email, true);
            storeDraft(subject,username,email);
            return "Reply sent successfully";
        }
        catch (Exception e)
        {
            return "Not Connected to the mail server";
        }
    }
    /*newsletter subject model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string getNewsLetterSubject()
    {
        try
        {
            string cmdText = "select TOP(1) draftSubject from newsletterDraft order by id desc;";

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }

            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            string subject = "";
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    subject = dr.GetString(0);

                }
            }

            conn.Close();
            return subject;
        }
        catch (Exception e) {
            return "";
        }
    }
    /*news letter body html model*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string getNewsLetterContent()
    {
        try
        {
            string cmdText = "select TOP(1) email from newsletterDraft order by id desc;";

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }

            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            string email = "";
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    email = dr.GetString(0);

                }
            }

            conn.Close();
            return email;
        }
        catch (Exception e)
        {
            return "";
        }
    }

    /*new messages*/
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string getNewInquiries()
    {
        String jsonString = "";

        try
        {
            string cmdText = "select inqMessage,replyMail from inquiries where isReplyed='false' order by id desc;";

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }

            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            string email = "";
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    email += newMailListMessages(dr.GetString(0), dr.GetString(1));

                }
            }

            conn.Close();
            jsonString = JsonHelper.JsonSerializer<String>(email);


        }
        catch (Exception e)
        { }

        return jsonString;

    }

    private string newMailListMessages(string message,string to) {
        return "<tr><td><a href=\"#\" class=\"hoaxClass\"><span class=\"glyphicon glyphicon-comment text-success\"></span>" + message + "<input id=\"recieverEmail\" type=\"hidden\" value=\"" + to + "\"/></a><span class=\"badge\">New</span></td></tr>";
    }



    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string getOldInquiries()
    {
        String jsonString = "";

        try
        {
            string cmdText = "select inqMessage from inquiries where isReplyed='true' order by id desc;";

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }

            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            string email = "";
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    email += oldReplyListMessages(dr.GetString(0));
                    
                }
            }
            
            conn.Close();
            jsonString = JsonHelper.JsonSerializer<String>(email);


        }
        catch (Exception e)
        {}

       return jsonString;

    }


    private string oldReplyListMessages(string message)
    {
        return "<tr><td><a href = \"#\"><span class =\"glyphicon glyphicon-comment text-success\"></span>"+ message + "</a></td></tr>";
    }


    public static bool SendEmail(string To, string ToName, string From, string FromName, string Subject, string Body, bool IsBodyHTML)
    {
        try
        {
            MailAddress FromAddr = new MailAddress(From, FromName, System.Text.Encoding.UTF8);
            MailAddress ToAddr = new MailAddress(To, ToName, System.Text.Encoding.UTF8);
            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 25,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new System.Net.NetworkCredential("thushan.ddtmg@gmail.com", "QWE123asd!@#")
            };

            using (MailMessage message = new MailMessage(FromAddr, ToAddr)
            {
                Subject = Subject,
                Body = Body,
                IsBodyHtml = IsBodyHTML,
                BodyEncoding = System.Text.Encoding.UTF8,
            })
            {
                smtp.Send(message);
            }
            return true;
        }
        catch
        {
            return false;
        }
    }

    //mssqldb slow,don`t let sort or filter
    private KeyValuePair<bool, List<Item>> mssqlread(String host, string port)
    {
        List<Item> items;
        Item item;
        this.link = int.Parse(port);
        this.host = host;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
        String cmdText = "";
        Boolean messagenoitems = false;
        cmdText = "select top(30) PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product order by case IsNumeric(viewCount) when 1 then Replicate('0', 100 - Len(viewCount)) + viewCount else viewCount end desc;";
        SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);
        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }
        items = new List<Item>();
        try
        {
            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    item = new Item();

                    byte[] bytes = new byte[0];
                    try
                    {
                        item.productID = int.Parse(dr["PID"].ToString().Trim());
                        item.Promotion = dr["promotion"].ToString();
                        item.Gender = dr["gender"].ToString();
                        item.Pname = dr["Product Name"].ToString().Trim();
                        bytes = (byte[])dr["Image"];
                        item.Image = bytes;
                        item.Price = double.Parse(dr["Price"].ToString());
                        item.Description = dr["Description"].ToString();
                        item.Category = dr["Category"].ToString();
                        item.SubCategory = dr["SubCategory"].ToString();
                        items.Add(item);
                    }
                    catch (Exception e2) { }
                }   //while
            }
            else
            {
                messagenoitems = true;
            }
        }
        catch (Exception v) { }
        con.Close();
        return new KeyValuePair<bool, List<Item>>(messagenoitems, items);
    }

    private string whereClauseAppend(List<string> pIDSet) {
        String whereClause = " WHERE ";
        for (int i= pIDSet.Count-1;i>=0;i--) { 
            whereClause += "PID = '" + pIDSet[i] + "' OR ";
        }
        return (pIDSet.Count > 0) ? whereClause.Substring(0,whereClause.Length-4) : "";
    }


    private KeyValuePair<bool, List<Item>> mssqlread(List<string> pIDSet,String host, string port)
    {
        List<Item> items;
        Item item;
        this.link = int.Parse(port);
        this.host = host;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
        String cmdText = "";
        Boolean messagenoitems = false;
        cmdText = "select top(30) PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product "+ whereClauseAppend(pIDSet) + " order by case IsNumeric(viewCount) when 1 then Replicate('0', 100 - Len(viewCount)) + viewCount else viewCount end desc;";
        SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);
        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }
        items = new List<Item>();
        try
        {
            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    item = new Item();

                    byte[] bytes = new byte[0];
                    try
                    {
                        item.productID = int.Parse(dr["PID"].ToString().Trim());
                        item.Promotion = dr["promotion"].ToString();
                        item.Gender = dr["gender"].ToString();
                        item.Pname = dr["Product Name"].ToString().Trim();
                        bytes = (byte[])dr["Image"];
                        item.Image = bytes;
                        item.Price = double.Parse(dr["Price"].ToString());
                        item.Description = dr["Description"].ToString();
                        item.Category = dr["Category"].ToString();
                        item.SubCategory = dr["SubCategory"].ToString();
                        items.Add(item);
                    }
                    catch (Exception e2) { }
                }   //while
            }
            else
            {
                messagenoitems = true;
            }
        }
        catch (Exception v) { }
        con.Close();
        return new KeyValuePair<bool, List<Item>>(messagenoitems, items);
    }
    //ovarride to get trending products
    //mssqldb slow,don`t let sort or filter
    private KeyValuePair<bool, List<Item>> mssqlread(String username,String host, string port)
    {
        List<Item> items;
        Item item;
        this.link = int.Parse(port);
        this.host = host;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
        String cmdText = "";
        Boolean messagenoitems = false;
        cmdText = "select top(30) PID,promotion,gender,Image As 'Image', pname AS 'Product Name',price AS 'Price',description AS 'Description',rating AS 'Rating',category AS 'Category',subCategory AS 'SubCategory' from Product where PID in (select distinct PID from Recent where username ='"+username+"') order by case IsNumeric(viewCount) when 1 then Replicate('0', 100 - Len(viewCount)) + viewCount else viewCount end desc;";
        SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);
        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }
        items = new List<Item>();
        try
        {
            System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    item = new Item();
                    byte[] bytes = new byte[0];
                    try
                    {
                        //need more data? ask ravi
                        item.productID = int.Parse(dr["PID"].ToString().Trim());
                        item.Promotion = dr["promotion"].ToString();
                        item.Gender = dr["gender"].ToString();
                        item.Pname = dr["Product Name"].ToString().Trim();
                        bytes = (byte[])dr["Image"];
                        item.Image = bytes;
                        item.Price = double.Parse(dr["Price"].ToString());
                        item.Description = dr["Description"].ToString();
                        item.Category = dr["Category"].ToString();
                        item.SubCategory = dr["SubCategory"].ToString();
                        items.Add(item);
                    }
                    catch (Exception e2) { }
                }   //while
            }
            else
            {
                messagenoitems = true;
            }
        }
        catch (Exception v) { }
        con.Close();
        return new KeyValuePair<bool, List<Item>>(messagenoitems, items);
    }
    //recent products - season 4
    [System.Web.Services.WebMethod(EnableSession = true)]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public void ClearRecentProducts(String username, String host, string port)
    {

        HttpContext.Current.Session["RecentSerialized"] = "";
        HttpContext.Current.Session["Recent"] = new List<string>();
        if (username != null && username.Length > 1)
        {
            using (SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString))
            {
                using (SqlCommand cmdx = new SqlCommand("DELETE FROM Recent WHERE username = @user;", conx))
                {
                    cmdx.CommandType = CommandType.Text;
                    cmdx.Parameters.AddWithValue("@user", username);
                    conx.Open();
                    int rowsAffected = cmdx.ExecuteNonQuery();
                    conx.Close();
                }
            }
        }
    }
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string GetRecentProducts(String username,String host,string port)
    {
        KeyValuePair<bool, List<Item>> data = mssqlread(username,host, port);
        List<Item> items = data.Value;
        Boolean messagenoitems = data.Key;
        List<string> tabs = new List<string>();
            foreach (Item it in items)
            {
                if (!tabs.Contains(it.Category))
                {
                    tabs.Add(it.Category);
                }
            }
            string tabcontent = custmnavi(tabs); //html string start
            int y = tabs.Count;
            foreach (string cat in tabs)
            {
                tabcontent += "<div class=\"tab-pane fade";

                if (tabs.Count == 0)
                {
                   //no problemo
                }
                else
                {
                    tabcontent += " active in";
                }
                tabcontent += "\" id=\"" + new String(cat.Where(char.IsLetter).ToArray()).ToLower() + "\">"; //tab content
                tabcontent += " <div class=\"row\">";
                int iii = 0;    // result row can only have 4 items
                bool check = false;
                string name = "";
                string price = "";
                byte[] url = null;
                string desc = "";
                string pid = "";
                string promo = "";

                if (items != null)
                {
                    foreach (Item ii in items)
                    {
                        if (ii.Category.CompareTo(cat) == 0)
                        {
                            if (iii == 0)
                            {
                                check = true;
                            }
                            name = ii.Pname;
                            pid = ii.productID.ToString();
                            price = String.Format("{0:0.00}", ii.Price);
                            url = ii.Image;
                            desc = ii.Description;
                            promo = ii.Promotion;
                            tabcontent += oneobject(promo, pid, name, price, url, desc);
                            iii++;
                            if (check)
                            {
                                iii = 0;
                                check = false;
                            }
                        }
                    }
                }
                tabcontent += "</div>"; //row
                tabcontent += "</div>";
            }
            tabcontent += "</div>";     //tab content
            tabcontent += "</div>";     //tab all
        JavaScriptSerializer js = new JavaScriptSerializer();// Use this when formatting the data as JSON
        return js.Serialize(tabcontent);
    }

    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string GetRecents(String pids, String host, string port)
    {
        JavaScriptSerializer json = new JavaScriptSerializer();
        List<string> pIDSet = json.Deserialize<List<string>>(pids);

        KeyValuePair<bool, List<Item>> data = mssqlread(pIDSet, host, port);
        List<Item> items = data.Value;
        Boolean messagenoitems = data.Key;
        List<string> tabs = new List<string>();
        foreach (Item it in items)
        {
            if (!tabs.Contains(it.Category))
            {
                tabs.Add(it.Category);
            }
        }
        string tabcontent = custmnavi(tabs); //html string start
        int y = tabs.Count;
        foreach (string cat in tabs)
        {
            tabcontent += "<div class=\"tab-pane fade";

            if (tabs.Count == 0)
            {
                //no problemo
            }
            else
            {
                tabcontent += " active in";
            }
            tabcontent += "\" id=\"" + new String(cat.Where(char.IsLetter).ToArray()).ToLower() + "\">"; //tab content
            tabcontent += " <div class=\"row\">";
            int iii = 0;    // result row can only have 4 items
            bool check = false;
            string name = "";
            string price = "";
            byte[] url = null;
            string desc = "";
            string pid = "";
            string promo = "";

            if (items != null)
            {
                foreach (Item ii in items)
                {
                    if (ii.Category.CompareTo(cat) == 0)
                    {
                        if (iii == 0)
                        {
                            check = true;
                        }
                        name = ii.Pname;
                        pid = ii.productID.ToString();
                        price = String.Format("{0:0.00}", ii.Price);
                        url = ii.Image;
                        desc = ii.Description;
                        promo = ii.Promotion;
                        tabcontent += oneobject(promo, pid, name, price, url, desc);
                        iii++;
                        if (check)
                        {
                            iii = 0;
                            check = false;
                        }
                    }
                }
            }
            tabcontent += "</div>"; //row
            tabcontent += "</div>";
        }
        tabcontent += "</div>";     //tab content
        tabcontent += "</div>";     //tab all
        JavaScriptSerializer js = new JavaScriptSerializer();// Use this when formatting the data as JSON
        return js.Serialize(tabcontent);
    }
    //must deploy to avoid .ajax onsuccess delay
    [WebMethod]
    [ScriptMethod(UseHttpGet = false, ResponseFormat = ResponseFormat.Json)]
    public string GetTrendingInfo(String host, string port)
    {
        KeyValuePair<bool, List<Item>> data = mssqlread(host, port);
        List<Item> items = data.Value;
        Boolean messagenoitems = data.Key;
        List<string> tabs = new List<string>();
        foreach (Item it in items)
        {
            if (!tabs.Contains(it.Category))
            {
                tabs.Add(it.Category);
            }
        }
        string tabcontent = custmnavi(tabs); //html string start
        int y = tabs.Count;
        foreach (string cat in tabs)
        {
            tabcontent += "<div class=\"tab-pane fade";
            if (tabs.Count == 0)
            {
                //no harm,no foul
            }
            else
            {
                tabcontent += " active in";
            }
            tabcontent += "\" id=\"" + new String(cat.Where(char.IsLetter).ToArray()).ToLower() + "\">"; //tab content
            tabcontent += " <div class=\"row\">";
            int iii = 0;    // result row can only have 4 items
            bool check = false;
            string name = "";
            string price = "";
            byte[] url = null;
            string desc = "";
            string pid = "";
            string promo = "";
            int viewCountPOS = 1;
            if (items != null)
            {
                foreach (Item ii in items)
                {
                    if (ii.Category.CompareTo(cat) == 0)
                    {
                        if (iii == 0)
                        {
                            check = true;
                        }

                        name = ii.Pname;
                        pid = ii.productID.ToString();
                        price = String.Format("{0:0.00}", ii.Price);
                        url = ii.Image;
                        desc = ii.Description;
                        promo = ii.Promotion;
                        tabcontent += oneobject(viewCountPOS.ToString(),promo, pid, name, price, url, desc);
                        iii++;
                        viewCountPOS++;
                        if (check)
                        {
                            iii = 0;
                            check = false;
                        }
                    }
                }
            }
            tabcontent += "</div>"; //row
            tabcontent += "</div>";
        }
        tabcontent += "</div>";     //tab content
        tabcontent += "</div>";     //tab all
        JavaScriptSerializer js = new JavaScriptSerializer();
        return js.Serialize(tabcontent);//~JSON
    }
    //navigation header for grouping
    private string custmnavi(List<string> list)
    {
        string navigationbar = ""
        + "<div class=\"col-sm-12\">"
        + "<ul class=\"nav nav-tabs\">";
        Boolean c = true;   // set active tab
        foreach (string t in list)
        {
            if (c)
            {
                navigationbar += "<li class=\"active\"><a href=\"#" + new String(t.Where(char.IsLetter).ToArray()).ToLower() + "\" data-toggle=\"tab\">" + t + "</a></li>";
                c = false;
            }
            else
            {
                navigationbar += "<li><a href=\"#" + new String(t.Where(char.IsLetter).ToArray()).ToLower() + "\" data-toggle=\"tab\">" + t + "</a></li>";
            }
        }
        navigationbar += "</ul>"
        + "</div>"
        + "<div class=\"tab-content\">";
        return navigationbar;
    }
    //one product with layout
    private string oneobject(string promotion, string pid, string name, string value, byte[] image, string alter)
    {
        string i = ""
        + "<div class=\"col-xs-12 col-sm-6 col-md-4 col-lg-3\">"
        + "<div class=\"product-image-wrapper\">"
        + "<div class=\"single-products\">"
        + "<div class=\"productinfo text-center\">"
        + "<img src=\"" + @"http://" + @host + @":" + @link.ToString() + @"/getImageFromDB.ashx?param=" + @pid + "\" width=\"200\" height=\"180\"  alt=\"" + alter + "\" />"
        + "<h2>RS. " + value + "</h2>"
        + "<p>" + name + "</p>"
        + "<a href=\"" + @"http://" + @host + @":" + @link.ToString() + @"/Product_Thushan.aspx?product=megabay" + @pid + "\" class=\"btn btn-default add-to-cart\"><i class=\"fa fa-shopping-cart\"></i>View Product</a>"
        + "</div><div class=\"product-overlay\">"
        + "<div class=\"overlay-content\">"
        + "<!-- --><!-- -->"
        + "<h2>" + value + "</h2>"
        + "<p>" + name + "</p>"
        + "<a href=\"" + @"http://" + @host + @":" + @link.ToString() + @"/Product_Thushan.aspx?product=megabay" + @pid + "\" class=\"btn btn-default add-to-cart\"><i class=\"fa fa-shopping-cart\"></i>View Product</a>"
        + "</div></div>";
        if (promotion.CompareTo("sale") == 0 || promotion.CompareTo("Sale") == 0 || promotion.CompareTo("SALE") == 0)
        {
            i += "<img src=\"images/home/sale.png\" class=\"new\" alt=\"\" />";
        }
        else if (promotion.CompareTo("new") == 0 || promotion.CompareTo("New") == 0 || promotion.CompareTo("NEW") == 0)
        {
            i += "<img src=\"images/home/new.png\" class=\"new\" alt=\"\" />";
        }
       i += "</div>"
            + "<div class=\"choose\">"
            + "<ul class=\"nav nav-pills nav-justified\">"
            + "<li><a href=\"\"><i class=\"fa fa-plus-square\"></i><p>Add to wishlist</p></a></li>"
            + "<li><a href=\"\"><i class=\"fa fa-plus-square\"></i><p>Add to compare</p></a></li>"
            + "</ul>"
            + "</div>"
            + "</div></div>";
        return i;
    }
    //one trending product with layout
    private string oneobject(string trend,string promotion, string pid, string name, string value, byte[] image, string alter)
    {

        string i = ""
        + "<div class=\"col-xs-12 col-sm-6 col-md-4 col-lg-3\">"
        + "<div class=\"product-image-wrapper\">"
        + "<div class=\"single-products\">"
        + "<div class=\"productinfo text-center\">"
        + "<img src=\"" + @"http://" + @host + @":" + @link.ToString() + @"/getImageFromDB.ashx?param=" + @pid + "\" width=\"200\" height=\"180\"  alt=\"" + alter + "\" />"
        + "<h2>RS. " + value + "</h2>"
        + "<p>" + name + "</p>"
        + "<a href=\"" + @"http://" + @host + @":" + @link.ToString() + @"/Product_Thushan.aspx?product=megabay" + @pid + "\" class=\"btn btn-default add-to-cart\"><i class=\"fa fa-shopping-cart\"></i>View Product</a>"
        + "</div><div class=\"product-overlay\">"
        + "<div class=\"overlay-content\">"
        + "<!-- --><!-- -->"
        + "<h2>" + value + "</h2>"
        + "<p>" + name + "</p>"
        + "<a href=\"" + @"http://" + @host + @":" + @link.ToString() + @"/Product_Thushan.aspx?product=megabay" + @pid + "\" class=\"btn btn-default add-to-cart\"><i class=\"fa fa-shopping-cart\"></i>View Product</a>"
        + "<script>alert( \"rtretert\" );</script>"
        + "</div></div>";
        if (promotion.CompareTo("sale") == 0 || promotion.CompareTo("Sale") == 0 || promotion.CompareTo("SALE") == 0)
        {
            i += "<img src=\"images/home/sale.png\" class=\"new\" alt=\"\" />";
        }
        else if (promotion.CompareTo("new") == 0 || promotion.CompareTo("New") == 0 || promotion.CompareTo("NEW") == 0)
        {
            i += "<img src=\"images/home/new.png\" class=\"new\" alt=\"\" />";
        }
        int trnd = int.Parse(trend);
        String trendNumber = "";
        if (trnd <= 10)
        {
            trendNumber = "0"+trend;
        }
        i += "<div class=\"heart\"></div>";
        i += "<label class=\"numberCircle\">" + trendNumber + "</label>";
        i += "</div>"
            + "<div class=\"choose\">"
            + "<ul class=\"nav nav-pills nav-justified\">"
            + "<li><a href=\"\"><i class=\"fa fa-plus-square\"></i><p>Add to wishlist</p></a></li>"
            + "<li><a href=\"\"><i class=\"fa fa-plus-square\"></i><p>Add to compare</p></a></li>"
            + "</ul>"
            + "</div>"
            + "</div></div>";
        return i;
    }
}
