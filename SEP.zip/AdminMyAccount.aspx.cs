﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class AdminMyAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GridView2.Visible = false;
    }
    Bidding bidding = new Bidding();
    DataTable Winners;

    /*Timer is for get list of winners on current date
     * only Admin can view who are winners.
     * 
     * */
    protected void btnFindWinners_Click(object sender, EventArgs e)
    {        
        GridView2.Visible = true;
        btnFindWinners.Enabled = false;
    }

    /*Timer is used to find winners of bids automatically.
     * Winners are selecting at 12.00 AM.
     * 
     * */
    protected void Timer1_Tick(object sender, EventArgs e)
    {
        Label8.Text = DateTime.Now.TimeOfDay.ToString();
        if (Label8.Text == "12:00:00:0000000")
        {
            Winners = bidding.FindWinners();
        }
    }
}