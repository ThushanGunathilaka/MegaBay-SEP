﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Boolean allowlogin = true;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
        string cmdText = "SELECT * FROM IECustomer WHERE username='" + TextBoxsigninUsername.Text + "';";
        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
        }

        System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
          
        if (dr.HasRows)
        {
            allowlogin = false;
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "You deactivated your account permanently" + "');", true);
        }

        conn.Close();

        cmdText = "SELECT * FROM UserRestrictedAccounts WHERE username='" + TextBoxsigninUsername.Text + "';";
        cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

        if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }

            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                allowlogin = false;
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Your account is restricted. Contact Admin" + "');", true);

            }
            conn.Close();
        


























        ////////////////////
            if (allowlogin)
            {
                conn.Open();

                string checkuser = "select count(*) from ECustomer where username='" + TextBoxsigninUsername.Text + "'";
                SqlCommand com = new SqlCommand(checkuser, conn);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            string password = "";
            string cusIDSaved = "";
            string IsSubscriber = "";
            string email = "";
            if (temp == 1)
                {
                string getdatafromlogintable = "select password,CusID,email,IsSubscriber from ECustomer where username='" + TextBoxsigninUsername.Text + "'";
                SqlCommand comData = new SqlCommand(getdatafromlogintable, conn);

                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                using (SqlDataReader reader = comData.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        // Read advances to the next row.
                        while (reader.Read())
                        {


                            int customerIDCoulmn = reader.GetOrdinal("CusID");
                            if (!reader.IsDBNull(customerIDCoulmn))
                            {
                                int temper = (int) reader.GetInt32(customerIDCoulmn);
                                cusIDSaved = temper.ToString();
                            }
                            int passwordCoulmn = reader.GetOrdinal("password");
                            if (!reader.IsDBNull(passwordCoulmn))
                            {
                                password = reader.GetString(passwordCoulmn);
                            }
                            int emailCoulmn = reader.GetOrdinal("email");
                            if (!reader.IsDBNull(emailCoulmn))
                            {
                                email = reader.GetString(emailCoulmn);
                            }
                            int isSubscriberCoulmn = reader.GetOrdinal("IsSubscriber");
                            if (!reader.IsDBNull(isSubscriberCoulmn))
                            {
                                IsSubscriber = reader.GetString(isSubscriberCoulmn);
                            }

                            Session["IsSubscriber"] = IsSubscriber;
                            Session["EMail"] = email;
                            Session["New"] = TextBoxsigninUsername.Text;
                            Session["CusID"] = cusIDSaved;

                        }
                    }
                }

                if (password == TextBoxsignInPass.Text)
                    {
                        Session["New"] = TextBoxsigninUsername.Text;
                        Session["CusID"] = cusIDSaved;
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", " document.getElementById(\"<%= buttonlogin.ClientID %>\").value = \"Logout\"; $('#accountlink').show(); $('#a').show();$('#b').show();$('#d').show();", false);


                        if (TextBoxsigninUsername.Text.CompareTo("admin") == 0)
                        {
                            Response.Redirect("AdminMyAccount.aspx");
                        }
                        else
                        {

                            SqlConnection conx = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
                            conx.Open();

                            string insertQuery = "insert into UserLoginStatus (username,currentDate,lastActiveDate,registeredDate) values (@username,@currentDate,@lastActiveDate,(select registered_date from ECustomer where username='" + TextBoxsigninUsername.Text + "'));";
                            SqlCommand comm = new SqlCommand(insertQuery, conx);

                            comm.Parameters.AddWithValue("@username", TextBoxsigninUsername.Text);
                            comm.Parameters.AddWithValue("@currentDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            comm.Parameters.AddWithValue("@lastActiveDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            comm.ExecuteNonQuery();

                        Response.Redirect("MyAccount.aspx",false);
                        }
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Incorrect Password!" + "');", true);
                    }
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Incorrect User Name!" + "');", true);
                }

                conn.Close();


            


        }
    }
}
