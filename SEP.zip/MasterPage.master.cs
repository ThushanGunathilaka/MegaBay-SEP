﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Configuration;
using System.Drawing;
using System.Web.Services;
using System.Web.Script.Services;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected string[] Values;
    protected string[] Deals;

    protected Dictionary<int, string> categoryTable;
    protected Dictionary<int, List<string>> subCategoryTable;
    protected Dictionary<int, List<string>> dealsTable;
    protected Dictionary<string, List<string>> setCategory;
    protected List<Item> items;
    protected List<catdata> mycatdata;
    protected Item item;
    protected string json;
    protected double maxprice;
   

    protected System.Collections.Generic.List<string> obj;
    protected System.Collections.Generic.List<string> category;

    protected void Page_Load(object sender, EventArgs e)
    {
        //loading data for side panel
        //check with master.master and global.asax
        int link = Request.Url.Port;   // to show thumbnails from .aspx qstring
        string host = Request.Url.Host;

        Session["Port"] = link;   // to show thumbnails from .aspx qstring
        Session["Host"] = host;

        string x = (string)Session["New"];

        maxprice = 0.0;
        
        Values = new string[] { };
        Deals = new string[] { };
        categoryTable = new Dictionary<int, string>();
        subCategoryTable = new Dictionary<int, List<string>>();
        dealsTable = new Dictionary<int, List<string>>();

        obj = new System.Collections.Generic.List<string>();

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

        string cmdText = "SELECT * FROM Categories";
        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }
        //update categories checkboxes
        System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                obj.Add(dr["Category"].ToString().Trim());

                categoryTable.Add(int.Parse(dr["Id"].ToString().Trim()), dr["Category"].ToString().Trim());

            }
        }

        con.Close();

        //update subcategories set
        cmdText = "SELECT * FROM SubCategories";
        cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }

        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                subCategoryTable.Add(int.Parse(dr["Id"].ToString().Trim()), new List<string>() { dr["CategoryIndex"].ToString().Trim(), dr["SubCategory"].ToString().Trim() });
            }
        }

        con.Close();

        Values = obj.ToArray();
        //updating deal set
        cmdText = "SELECT * FROM Deal";
        cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }

        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                dealsTable.Add(int.Parse(dr["Id"].ToString().Trim()), new List<string>() { dr["Name"].ToString().Trim(), dr["Precentage"].ToString().Trim(), dr["Offset"].ToString().Trim(), dr["Priority"].ToString().Trim(), dr["Brand"].ToString().Trim(), dr["Product"].ToString().Trim(), dr["Start"].ToString().Trim(), dr["End"].ToString().Trim() });  
            }
        }

        con.Close();



        //getting product set
        cmdText = "SELECT * FROM Product";
        cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }

        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {


            items = new List<Item>();
            while (dr.Read())
            {
                item = new Item();
                item.productID = int.Parse(dr["PID"].ToString());
                item.Pname = dr["pname"].ToString().Trim();

                item.Price = double.Parse(dr["price"].ToString().Trim());

                item.Description = dr["description"].ToString().Trim();

                item.Category = dr["category"].ToString().Trim();
                item.SubCategory = dr["subCategory"].ToString().Trim();
                item.TipsAdd = dr["tips"].ToString().Trim();
                item.Message = dr["message"].ToString().Trim();
                items.Add(item);
               


            }
            //smart search data assigning
            //TODO: move to a web method and update page with .ajax 
            if (!Page.ClientScript.IsClientScriptBlockRegistered("mssqldata"))
            {
                var serializedClass = new JavaScriptSerializer().Serialize(items);
                
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(),

                    "mssqldata", string.Format("var datarr ={0}", serializedClass), true);

            }


        }

        con.Close();
        //price range update
        cmdText = "SELECT MAX(price) AS a FROM Product";
        cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }

        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {

            while (dr.Read())
            {
      
                maxprice = double.Parse(dr["a"].ToString().Trim());
              
            }



        }

        con.Close();

        //assign product data
        setCategory = new Dictionary<string, List<string>>();

        foreach (KeyValuePair<int, string> parent in categoryTable)
        {

            category = new System.Collections.Generic.List<string>();
            foreach (KeyValuePair<int, List<string>> child in subCategoryTable)
            {

                List<string> a = child.Value;
                string b = a.First();

                int c = int.Parse(b);

                int d = parent.Key;
                if (d == c)
                {

                    try
                    {
                        category.Add(a.ElementAt(1));

                    }
                    catch (Exception e1) { }
                }
            }

            try
            {

                setCategory.Add(parent.Value, category);

            }
            catch (Exception e2) { }
        }

        //creating products display section
        mycatdata = new List<catdata>();
        catdata cat;

        string html = "";

        int i = 0;
        html += "<div class=\"panel panel-default\">";
        foreach (KeyValuePair<string, List<string>> parent in setCategory)
        {
            string key = parent.Key.Substring(0, 3).ToLower() + i;
            string value = parent.Key;
            html += "<ul class=\"someclass\"><div  id=\"acc" + key + "\"  class=\"panel-heading\">"
            + "<h4 class=\"panel-title checkbox-inline\">"

            + "<li><input type=\"checkbox\" runat =\"server\" id=\"" + key + "\" value=\"none\"  onclick=\"checkboxcheck(this)\" name =\"" + value + "\"/></li>"
            + "<a data-toggle=\"collapse\" data-parent=\"#accordian\" href=\"#" + key + "subid" + "\">"

            + "<span class=\"badge pull-left\"><i class=\"fa fa-th\"></i></span>"
            + value
            + "</a></h4></div>"

            + "<div id=\"" + key + "subid" + "\" class=\"panel-collapse collapse\">"
            + "<div class=\"panel-body\"><ul>";

            foreach (string child in parent.Value)
            {
                i++;
                string keychild = child.Substring(0, 3).ToLower() + i;
                html += "<div class =\"container\">"
                + "<div class =\"row \">"
                + "<label class=\"checkbox-inline no_indent\">"

                 + "<li><input type=\"checkbox\" runat =\"server\" id=\"" + keychild + "\" value=\"" + key + "\" onclick=\"checkboxcheck(this)\" name =\"" + child + "\"/></li>"
                + child
                + "</label></div></div>";

                cat = new catdata();
                cat.Idname = keychild;
                cat.Name = child;
                cat.Parent = key;
                cat.Value = false;
                mycatdata.Add(cat);

            }
            i++;

            html += "</ul></div></div></ul>";
        }

        html += "</div>";


        //assign categories and subcategories ti div element
        accordian.Controls.Add(new LiteralControl(html));

        //gnerating price slider
        string priceslider =""
            +"<div class=\"price-range\"><h2>Price Range</h2><div class=\"well text-center\">"
            +"<input type=\"text\" class=\"span2\" value=\"\" data-slider-min=\"0\" data-slider-max=\""+(int)maxprice+"\" data-slider-step=\""+(int)maxprice/20+"\" data-slider-value=\"["+((int)0)+","+((int)maxprice)+"]\" id=\"rangecheck\"/><br /><b class=\"pull-left\">Rs. 0</b> <b class=\"pull-right\">Rs. "+maxprice+"</b>"
            +"</div></div>";
        pricelider.Controls.Add(new LiteralControl(priceslider));

        string dealtypes = ""
        + "<div id=\"" + "dealset" + "\" class=\"panel panel-default\">"
           + "<div class=\"panel-body\"><ul>";

          
        //assigning deal set
        foreach (KeyValuePair<int, List<string>> data in dealsTable)
        {
             i++;
            string keychild = "promo"+data.Key.ToString() + i;
            dealtypes += "<div class =\"container\">"
            + "<div class =\"row \">"
            + "<label class=\"checkbox-inline no_indent\">"
            + "<li><input type=\"checkbox\" runat =\"server\" id=\"" + keychild + "\" value=\"none\" onclick=\"dealpromocheck(this)\" name =\"" + data.Value[0].ToString() + "\"/></li>"
            + data.Value[0].ToString()
            + "</label></div></div>";
        }
        dealtypes += "</ul></div></div>";

        dealsset.Controls.Add(new LiteralControl(dealtypes));
        //needed code for recent model. dont delete
      //  var serialized = new JavaScriptSerializer().Serialize(mycatdata);

       // string n = string.Format("{0}", Request.Form["Men`s"]);
       // Response.Write(n);

       // Session["thushan"] = new String[]{""};
       // Session["thushan"] = serialized;//mycatdata;

        tipsdata.Controls.Add(new LiteralControl(tipsmethod()));
    }
    //needed code for save images in server folder.don`t delete
    /*
    public string imagelink(string name,byte[] image) {
        string x = "";
        if (item.TipsAdd.CompareTo("play") == 0)
        {
            String img = "";
            img = "data:image/Png;base64" + Convert.ToBase64String(CreateThumbnail(image, 200));

            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\eportal";

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            string thumb = new String(name.Where(char.IsLetter).ToArray()).ToLower() + ".Png";  // set thumbnail name
            string thumbloc = @path + @"\thumb" + new String(name.Where(char.IsLetter).ToArray()).ToLower() + ".Png";    // thumbnail absolute path

            if (!File.Exists(thumbloc))
            {
                File.WriteAllBytes(thumbloc, CreateThumbnail(image, 200));
            }

            int link = Request.Url.Port;   // to show thumbnails from .aspx qstring
            string host = Request.Url.Host;
            //string imagelink = "<img src=\"" + @"http://" + @host + @":" + @link.ToString() + @"/imagedata.aspx?param=thumb" + @thumb + "\" width=\"200\" height=\"180\" u=\"image\" class=\"img-responsive\" data-u=\"image\" alt=\"" + name + "\" />";
            string linkonly = @"http://" + @host + @":" + @link.ToString() + @"/imagedata.aspx?param=thumb" + @thumb + "\"";

            x = linkonly;

           

        }
        return x;
    }

    */
    public string tipsmethod() {

       // Response.Write(items[0].Pname);

        //image slider (jessor)
        String data = "" +
             "<div id=\"closeablepanel3\">" +
                                        "<div class=\"header-middle\">" +
                                     //       "<div class=\"container\">" +
                                      //          "<div class=\"row\">" +
                                       //             "<div class=\"col-sm-12\">" +


                                                     "<div id=\"slider1_container\" style=\"position: relative; top: 0px; left: 0px; width: 600px; height: 290px;\">" +
        "<!-- Slides Container -->" +
        "<div u=\"slides\" style=\"cursor: move; position: absolute; left: 0px; top: 0px; width: 600px; height: 290px;overflow: hidden;\">";


        foreach (Item item in items)
        {
            if (item.TipsAdd.CompareTo("play") == 0)
            {
                data += "<div class=\"slide\"><a href=\"" + @"http://" + @Request.Url.Host + @":" + @Request.Url.Port.ToString() + @"/getImageFromDB.ashx?param=" +item.productID  + "\" data-lightbox=\"image-1\" data-title=\"" + item.Pname + "\">" +
                            "<img u=\"image\" data-u=\"image\" src=\"" + @"http://" + @Request.Url.Host + @":" + @Request.Url.Port.ToString() + @"/getImageFromDB.ashx?param=" + item.productID + "\" /></a>";
               
               // data += "<div><img u=\"image\" src=\"" + @"http://" + @Request.Url.Host + @":" + @Request.Url.Port.ToString() + @"/imagedata.aspx?param=thumb" + new String(item.Pname.Where(char.IsLetter).ToArray()).ToLower() + ".Png" + "\" />" +
                        data += "<div u=\"caption\"  class=\"caption\" data-u=\"caption\"  t=\"MCLIP|B\"  style=\"position: absolute; top: 250px; left: 0px;width: 600px; height: 50px;\">" +
                                    "<div style=\"position: absolute; top: 0px; left: 0px; width: 600px; height: 50px;background-color: Black; opacity: 0.5; filter: alpha(opacity=50);\"></div>" +
                                    "<div style=\"position: absolute; top: 0px; left: 0px; width: 600px; height: 50px;color: White; font-size: 16px; font-weight: bold; line-height: 50px; text-align: center;\">"+

                                    "<p class=\"pull-left\">"+
                            item.Pname +
                        "</p></div></div></div>";
            }
        }
     

      data += "</div>" +
    
    "</div>"+
    //TODO:performance issue
    //cannot see product page links until the site hosted
   //www.jessorslider.com

                                     // "</div></div></div>"+
                                      "</div></div>";



            
    
        return data;
    }
    //login function assigin sessions
    //TODO: logout text not visible when db is busy
    [WebMethod]
    public void logingclick(object sender, EventArgs e)
    {
        string x = (string)Session["New"];
       // Response.Write(x);
        if(x !=null && x.Length >2){
            buttonlogin.Text = "Logout";
          //  ClientScript.RegisterStartupScript(this.GetType(), "myalert", " document.getElementById(\"<%= buttonlogin.ClientID %>\").value = \"Logout\"; $('#accountlink').show(); $('#a').show();$('#b').show();$('#d').show();", false);

        }
        //Response.Write(buttonlogin.Text);

        if (buttonlogin.Text.CompareTo("Logout")==0)
        {
            Session["New"] = null;
            Session["EMail"] = "";
            Session["IsSubscriber"] = "";
            Response.Redirect("Home.aspx",false);
        }
        else {
            Response.Redirect("Login.aspx",false);
        }
    }
    //search button click
    //assigning data from hidden fileds 
    //use firebug to check data
    //todo:get data as json object
    public void searchbuttonclick(object sender, EventArgs e)
    {
        // Page.ClientScript.RegisterStartupScript(this.GetType(),"script","myfunc();",true);
        //  string s = passdata.Value;
        // Response.Write(sort.Value);

        Session["thushan"] = passdata.Value;
        Session["minprice"] = minh.Value;
        Session["maxprice"] = maxh.Value;
        Session["searchtext"] = searchtext.Value;
        Session["sort"] = sort.Value;
        Session["dealpromo"] = dealpromo.Value;
        Session["filtergender"] = filtergender.Value;
        Session["filterdeals"] = filterdeals.Value;
        Session["filtercondition"] = filtercondition.Value;
        if (realatedSYN.Value != null && realatedSYN.Value.Trim().Length > 1)
        {

            //sysnonims from bighugh data
            //cannot check until deployed
            //can bypass using IF>9
            //todo:get synonims from mutiple web services to avoide server busy message
            List<string> relatedList = new List<string>(realatedSYN.Value.Split(",".ToCharArray()));
            Session["realatedSYN"] = relatedList;
            Response.Redirect("Content_Thushan.aspx?related=related", false);
            // Response.Write(relatedList[0]);
        }
        else
        {
            Response.Redirect("Content_Thushan.aspx");
        }
        /*
        System.Web.UI.HtmlControls.HtmlButton button = (System.Web.UI.HtmlControls.HtmlButton)sender;

        button.ServerClick += (sa, ea) =>
        {

            
        };*/
    }
    //needed code dont delete
    //find button click() cannot by pass web link fin forefox
    //to avoide firefox,global event missing error 
/*
    public void relatebuttonclick(object sender, EventArgs e)
    {
        
        //  string s = passdata.Value;
        // Response.Write(sort.Value);

        Session["thushan"] = passdata.Value;
        Session["minprice"] = minh.Value;
        Session["maxprice"] = maxh.Value;
        Session["searchtext"] = searchtext.Value;
        Session["sort"] = sort.Value;
        Session["dealpromo"] = dealpromo.Value;
        Session["filtergender"] = filtergender.Value;
        Session["filterdeals"] = filterdeals.Value;
        Session["filtercondition"] = filtercondition.Value;
        Session["realatedSYN"] = new List<string>(realatedSYN.Value.Split(",".ToCharArray()));


        /*
        var s = new System.Web.Script.Serialization.JavaScriptSerializer();
        Object objx = s.DeserializeObject(realatedSYN.Value);
        List<String> x = JsonConvert.DeserializeObject<RootObject>(string json);

        string[] output = (from o in objx
                           select o.ToString()).ToArray()
        // Response.Write(Session["realatedSYN"].ToString());
        Response.Redirect("Content_Thushan.aspx", false);
        /*
        System.Web.UI.HtmlControls.HtmlButton button = (System.Web.UI.HtmlControls.HtmlButton)sender;

        button.ServerClick += (sa, ea) =>
        {

            
        };
    }*/
    //find button
    //not valid redirect method
    public void asp_click(object sender, EventArgs e)
    {
        Response.Redirect("Content_Thushan.aspx");
    }
    //to save images in server
    /*
    // Create a thumbnail in byte array format from the image encoded in the passed byte array.  
    public static byte[] CreateThumbnail(byte[] PassedImage, int LargestSide)
    {
        byte[] ReturnedThumbnail;

        using (MemoryStream StartMemoryStream = new MemoryStream(), NewMemoryStream = new MemoryStream())
        {
            // write the string to the stream  
            StartMemoryStream.Write(PassedImage, 0, PassedImage.Length);

            // create the start Bitmap from the MemoryStream that contains the image  
            Bitmap startBitmap = new Bitmap(StartMemoryStream);

            // set thumbnail height and width proportional to the original image.  
            int newHeight;
            int newWidth;
            double HW_ratio;

            if (startBitmap.Height > startBitmap.Width)
            {
                newHeight = LargestSide;
                HW_ratio = (double)((double)LargestSide / (double)startBitmap.Height);
                newWidth = (int)(HW_ratio * (double)startBitmap.Width);
            }
            else
            {
                newWidth = LargestSide;
                HW_ratio = (double)((double)LargestSide / (double)startBitmap.Width);
                newHeight = (int)(HW_ratio * (double)startBitmap.Height);
            }

            // create a new Bitmap with dimensions for the thumbnail.  
            Bitmap newBitmap = new Bitmap(newWidth, newHeight);

            // Copy the image from the START Bitmap into the NEW Bitmap.  
            // This will create a thumnail size of the same image.  
            newBitmap = ResizeImage(startBitmap, newWidth, newHeight);

            // Save this image to the specified stream in the specified format.  
            newBitmap.Save(NewMemoryStream, System.Drawing.Imaging.ImageFormat.Png);

            // Fill the byte[] for the thumbnail from the new MemoryStream.  
            ReturnedThumbnail = NewMemoryStream.ToArray();
        }

        // return the resized image as a string of bytes.  
        return ReturnedThumbnail;
    }

    private static Bitmap ResizeImage(Bitmap image, int width, int height)
    {
        Bitmap resizedImage = new Bitmap(width, height);

        using (Graphics gfx = Graphics.FromImage(resizedImage))
        {
            gfx.DrawImage(image, new Rectangle(0, 0, width, height), new Rectangle(0, 0, image.Width, image.Height), GraphicsUnit.Pixel);
        }

        return resizedImage;
    } 
     * */

        //todo: inquiry model
        //can move to webservice.asax

    //client side data rendor
    protected override void Render(HtmlTextWriter writer)
    {
        Page.ClientScript.RegisterForEventValidation(buttonlogin.UniqueID.ToString());
        base.Render(writer);
    }
}

