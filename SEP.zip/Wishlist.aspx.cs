﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    protected string productIDFinal = "";
    protected int UId = -1;
    protected int PId = -1;
    protected String usersID = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)//////
        {
            LoadData();
        }
        productIDFinal = Request.QueryString["product"];
        usersID = Session["CusID"].ToString();
        UId = Convert.ToInt32((usersID == null || usersID.CompareTo("")==0) ? "-1" : usersID);
        PId = int.Parse((productIDFinal == null) ? "-1" : productIDFinal);
        String prodId;
        //prodId = Session["pid"].ToString();
        prodId = productIDFinal;//////
        dba.BindGrid(GridView1, prodId);
    }
    private void LoadData()
    {
        int cusId;
        //cusId = (int)Session["uid"];        
        cusId = UId;//////

        DataSet ds = dba.getWishListNames(cusId);
        int rowCount = ds.Tables[0].Rows.Count;///////
        
        if (rowCount == 0)
        {
            Label2.Text = "0 Lists, create a list first";
           // DropDownList1.Visible = false;
            Label2.Visible = true;
        }
        else
        {
            DropDownList1.Visible = true;
            Label2.Visible = false;
            DropDownList1.Items.Clear();
            for (int i = 0; i < rowCount; i++)
            {
                DropDownList1.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> onclick=window.open(\"Wishlist_Added.aspx\",\"mywindow\",\"menubar=1,resizable=1,width=350,height=250\")</SCRIPT>");
        
        String uid;
        //uid=Session["uid"].ToString();
        uid = usersID;///////

        String listName = TextBox1.Text;

        if (listName != "")
        {
            if (dba.insertNewList(uid, listName) == -1)
            {
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"List name already exists \")</SCRIPT>");
            }
            else
            {
                Label7.Text = "New List Successfully Added";
                Label7.Visible = true;
            }

            LoadData();//////
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Please Enter a List name ! \")</SCRIPT>");
        }
        
        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        String prodId;
        //prodId = Session["pid"].ToString();
        prodId = productIDFinal;//////

        String list = DropDownList1.SelectedItem.ToString();
        String memo = TextBox2.Text;

        if (dba.insertWishListItem(list, prodId, memo) >= 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Successfully added to wish list. \")</SCRIPT>");
            Label7.Visible = false;
            DropDownList1.Items.Clear();
            TextBox2.Text = "";
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Product Already in List! \")</SCRIPT>");
        }
        Label7.Visible = false;



    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
}