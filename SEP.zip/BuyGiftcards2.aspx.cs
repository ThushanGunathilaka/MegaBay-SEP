﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    String UIDtemp = "4";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //String UIDtemp = Session["uid_temp"].ToString();
            
            //display gift card details in the grid view by using user id
            dba.BindGrid_uniqviewgiftcard(GridView1, UIDtemp);
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView2.Rows)
        {
            //check each row is a data row
            if (row.RowType == DataControlRowType.DataRow)
            {
                //get the unique id from the grid view and that get to the session
                string lbl = (row.Cells[0].FindControl("Label10") as Label).Text;
                Session["BgiftcardClick2"] = lbl;
                Response.Redirect("Email.aspx");
            }
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String BgiftId = btn.CommandArgument.ToString();

        //give the gift id and dispaly in gridview
        dba.BindGrid_getGiftcard(GridView2, BgiftId);       

        //call javascript function from code behind
        Page.ClientScript.RegisterStartupScript(this.GetType(), "viewGift", "viewGift()", true);
        Label4.Visible = true;
        Button4.Visible = true;
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}