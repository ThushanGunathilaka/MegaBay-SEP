﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    ReportMethods reportMethods = new ReportMethods();
    DataTable ProductsWithRatings_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductRatingRpt.rdlc");
            ProductsWithRatings_dt = reportMethods.GetProductRatings();
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsWithRatings";
            source1.Value = ProductsWithRatings_dt;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(source1);
            ReportViewer1.LocalReport.Refresh();

        }
    }
}