﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class orderHistory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = (String)Session["New"];

        System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

        SqlCommand sqlCommand = new SqlCommand("select orderNo,orderDate,shippedAddress,totalPurchase from OrderDetails where userName = '"+name+"'", sqlConnection);

        sqlConnection.Open();

        SqlDataReader reader = sqlCommand.ExecuteReader();
        GridView1.DataSource = reader;
        GridView1.DataBind();
    }
}