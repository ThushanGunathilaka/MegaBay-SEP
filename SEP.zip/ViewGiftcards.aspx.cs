﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        //Page load first time
        if (!Page.IsPostBack)
        {
            //fill the gridview with gift card products
            dba.BindGridViewGiftcard_common(GridView1);
            dba.BindGridViewGiftcard_elec(GridView2);
            dba.BindGridViewGiftcard_fashion(GridView3);
            dba.BindGridViewGiftcard_coll(GridView4);
            dba.BindGridViewGiftcard_home(GridView5);
            dba.BindGridViewGiftcard_sport(GridView6);
            dba.BindGridViewGiftcard_moto(GridView7);
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");
    
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");

    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");

    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");

    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["giftcardClick"] = pid;
        Response.Redirect("BuyGiftcards.aspx");

    }
}