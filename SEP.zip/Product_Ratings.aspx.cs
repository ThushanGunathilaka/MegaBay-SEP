﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    Star1 st = new Star1();
    
    //int PId = 4;
    //int UId = 3;
    //prodId = Session["pid"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        st.PID1 = 4;
        st.CusID1 = 3;
        
        //gridwiew fill with given product
        dba.BindGridpro_ratings(GridView1,st.PID1);

        //clear the lables
        Label4.Text = "0";
        Label5.Text = "0";
        Label6.Text = "0";
        Label7.Text = "0";
        Label8.Text = "0";

        //get single user rate and fill stars with color
        DataSet ds1 = dba.viewStarRate(st.PID1, st.CusID1);
        int rowCount1 = ds1.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount1; i++)
        {
            int rate = (int)ds1.Tables[0].Rows[i][0];
            if (rate == 1)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 2)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 3)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
                ImageButton3.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 4)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
                ImageButton3.ImageUrl = "~/images/Star_2.png";
                ImageButton4.ImageUrl = "~/images/Star_2.png";
            }
            else if (rate == 5)
            {
                ImageButton1.ImageUrl = "~/images/Star_2.png";
                ImageButton2.ImageUrl = "~/images/Star_2.png";
                ImageButton3.ImageUrl = "~/images/Star_2.png";
                ImageButton4.ImageUrl = "~/images/Star_2.png";
                ImageButton5.ImageUrl = "~/images/Star_2.png";
            }
        }


        //view the given ratings 
        DataSet ds = dba.viewStarRatings();
        int rowCount = ds.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount; i++)
        {
            int rate = (int)ds.Tables[0].Rows[i][0];
            if (rate == 1)
            {
                Label4.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 2)
            {
                Label5.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 3)
            {
                Label6.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 4)
            {
                Label7.Text = ds.Tables[0].Rows[i][1].ToString();
            }
            else if (rate == 5)
            {
                Label8.Text = ds.Tables[0].Rows[i][1].ToString();
            }
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public void updatestar(int rate)
    {
        st.PID1 = 4;
        st.CusID1 = 3;

        //clear the stars
        ImageButton1.ImageUrl = "~/images/Star_1.png";
        ImageButton2.ImageUrl = "~/images/Star_1.png";
        ImageButton3.ImageUrl = "~/images/Star_1.png";
        ImageButton4.ImageUrl = "~/images/Star_1.png";
        ImageButton5.ImageUrl = "~/images/Star_1.png"; 
      
        
        //update the rates
        dba.updatestardb(st.PID1, st.CusID1, rate);

        if (rate == 1)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
        }
        else if(rate == 2)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 3)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 4)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 5)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
            ImageButton5.ImageUrl = "~/images/Star_2.png";
        }
      
    }

    public void inseartstar(int rate)
    {
        st.PID1 = 4;
        st.CusID1 = 3;

        //clear the stars
        ImageButton1.ImageUrl = "~/images/Star_1.png";
        ImageButton2.ImageUrl = "~/images/Star_1.png";
        ImageButton3.ImageUrl = "~/images/Star_1.png";
        ImageButton4.ImageUrl = "~/images/Star_1.png";
        ImageButton5.ImageUrl = "~/images/Star_1.png";


        //inseart the rates
        dba.insertstar1(st.PID1, st.CusID1, rate);

        if (rate == 1)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 2)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 3)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 4)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
        }
        else if (rate == 5)
        {
            ImageButton1.ImageUrl = "~/images/Star_2.png";
            ImageButton2.ImageUrl = "~/images/Star_2.png";
            ImageButton3.ImageUrl = "~/images/Star_2.png";
            ImageButton4.ImageUrl = "~/images/Star_2.png";
            ImageButton5.ImageUrl = "~/images/Star_2.png";
        }

    }
    
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = 4;
        st.CusID1 = 3;
        st.Rate1 = 1;
        //int rate = 1;

        if (st.Rate1 == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            //check the rate is given by uer and product
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;
            //Debug.WriteLine(rowCount);

            if (rowCount == 0)
            {
                inseartstar(st.Rate1);
            }
            else if (rowCount >= 1)
            {
                updatestar(st.Rate1);
            }
        }
        Page_Load(this, e);
    }


    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = 4;
        st.CusID1 = 3;
        //st.Rate1 = 1;

        int rate = 2;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;
            
            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);             
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = 4;
        st.CusID1 = 3;

        int rate = 3;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
     }


    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = 4;
        st.CusID1 = 3;

        int rate = 4;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
    }


    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        st.PID1 = 4;
        st.CusID1 = 3;

        int rate = 5;

        if (rate == -1 || st.CusID1 == -1 || st.PID1 == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Give a Star Rate \")</SCRIPT>");
        }
        else
        {
            DataSet ds1 = dba.checkstar(st.PID1, st.CusID1);
            int rowCount = ds1.Tables[0].Rows.Count;

            if (rowCount == 0)
            {
                inseartstar(rate);
            }
            else if (rowCount >= 1)
            {
                updatestar(rate);
            }
        }
        Page_Load(this, e);
    }
}