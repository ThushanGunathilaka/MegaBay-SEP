﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    BuyGiftcard giftcard = new BuyGiftcard();

    //userId = Session["uid"].ToString();
    int uId = 4;

    protected void Page_Load(object sender, EventArgs e)
    {
        //get the session value
        String PID = Session["giftcardClick"].ToString();
        //given gift id show the data in the grid view
        dba.BindGrid_viewgiftcard(GridView1, PID);
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            //check each row is a data row
            if (row.RowType == DataControlRowType.DataRow)
            {
                //uniquely identify the id of the gift card by lable4
                string lbl = (row.Cells[0].FindControl("Label4") as Label).Text;
                int gId = int.Parse(lbl);
                
                //generate unique id
                Double Unique = DateTime.Now.ToString().GetHashCode();
                //Debug.WriteLine(Unique);
                
                //convert unique id to + value
                String UniqueId = Math.Abs(Unique).ToString();

                try
                {
                    String Q_data1 = dba.selesctQtygiftcerds(gId);
                    int Q_data = int.Parse(Q_data1);

                    //get the newly entered quntity 
                    int Qty = int.Parse(TextBox1.Text);

                    //check the newly given qty is less than the qty of the given in the database
                    if (Q_data >= Qty)
                    {
                        //update the quntity of the gift card
                        dba.updateQtygiftcerds(Qty);
                        //insert unique id, gift id, user id to the buyGiftcard table
                        dba.insertQtygiftcerds(UniqueId, gId, uId);
                        Session["uid_temp"] = uId;
                        Response.Redirect("BuyGiftcards2.aspx");
                    }
                    else
                    {
                        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a quantity less than stock in hand \")</SCRIPT>");
                    }
                }
                catch(Exception)
                {
                    System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a valid amount \")</SCRIPT>");
                }
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddNewItem.aspx");
    }
}