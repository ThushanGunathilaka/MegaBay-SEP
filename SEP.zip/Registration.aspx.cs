﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);
            conn.Open();

            string checkuser = "select count(*) from ECustomer where username='"+TextBoxusername.Text+"'";
            SqlCommand com = new SqlCommand(checkuser,conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1) {
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "User Name already exists!" + "');", true);

            }


            conn.Close();

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        Guid newGUID = Guid.NewGuid();
        Boolean a = false;
        String username = TextBoxusername.Text.ToString();
        string cmdText = "select username from ECustomer where username='" + TextBoxusername.Text + "'";

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);


        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
        }

        System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
        
        string userIndex = "null";
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                userIndex = dr.GetString(0);
               
            }
        }

        conn.Close();
        Boolean allowRegister = true;

        cmdText = "SELECT * FROM IECustomer WHERE username='" + TextBoxusername.Text + "';";
       cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
        }

       dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            allowRegister = false;
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Username already exists!" + "');", true);

        }

        conn.Close();

        cmdText = "SELECT * FROM UserRestrictedAccounts WHERE username='" + TextBoxusername.Text + "';";
        cmd = new System.Data.SqlClient.SqlCommand(cmdText, conn);

        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
        }

        dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            allowRegister = false;
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Username already exists!" + "');", true);

        }
        conn.Close();


        if (userIndex.CompareTo(TextBoxusername.Text) != 0 && allowRegister)
        {
            string insertQuery = "insert into ECustomer (ICusID,username,Fname,Lname,password,email,registered_date) values (@ICusID,@username,@Fname,@Lname,@password,@email,@registered_date)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.AddWithValue("@ICusID", newGUID.ToString());
            com.Parameters.AddWithValue("@username", TextBoxusername.Text);
            com.Parameters.AddWithValue("@Fname", TextBoxfirstname.Text);
            com.Parameters.AddWithValue("@Lname", TextBoxlastname.Text);
            com.Parameters.AddWithValue("@password", TextBoxpass.Text);
            com.Parameters.AddWithValue("@email", TextBoxemail.Text);
            com.Parameters.AddWithValue("@registered_date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

            //insert to UserLoginStatus
            
            string insertQuery2 = "insert into UserLoginStatus (username,currentDate,lastActiveDate,registeredDate) values (@username,@currentDate,@lastActiveDate,(select registered_date from ECustomer where username='" + TextBoxusername.Text + "'));";
            SqlCommand comm = new SqlCommand(insertQuery2, conn);

            comm.Parameters.AddWithValue("@username", TextBoxusername.Text);
            comm.Parameters.AddWithValue("@currentDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            comm.Parameters.AddWithValue("@lastActiveDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

         
            try
            {
                
                conn.Open();
                com.ExecuteNonQuery();
                comm.ExecuteNonQuery();
                Session["New"] = username;
                Response.Redirect("MyAccount.aspx");
                
            
            }
            catch (Exception es)
            {
           ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Ooops!. Unexpected error occured while creating your account.Please try again later. " + "');", true);

               
            }
            //Response.Redirect("");
           
            conn.Close();
        }

    }
       /* catch (Exception ex)
        {
            //   Response.Write("Error"+ex.ToString());

        }*/
    
    
}