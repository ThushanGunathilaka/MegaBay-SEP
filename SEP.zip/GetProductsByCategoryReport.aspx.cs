﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    //Make instance from ReportMethods class
    ReportMethods reportMethods = new ReportMethods();
    DataTable AllProducts_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Load the report
        if (!IsPostBack)
        {
            rpvProductsByCategory.ProcessingMode = ProcessingMode.Local;
            rpvProductsByCategory.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsByCategoryRpt.rdlc");
            AllProducts_dt = reportMethods.GetAllProducts();
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DataSet1";
            source1.Value = AllProducts_dt;
            rpvProductsByCategory.LocalReport.DataSources.Clear();
            rpvProductsByCategory.LocalReport.DataSources.Add(source1);
            rpvProductsByCategory.LocalReport.Refresh();

        }
    }
}