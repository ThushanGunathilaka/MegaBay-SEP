﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        String PID = Session["promoClick"].ToString();
        //String PID = "7";

        //display target item values 
        dba.BindGrid_viewpromo(GridView1, PID);

    }

    public string TargetDate
    {
        get
        {
            String PID = Session["promoClick"].ToString();
            //String PID = "7";
            //get the expire date from the database and give to date string
            String date = dba.getExpireDatepromo(PID);
            DateTime dt = Convert.ToDateTime(date);
            String expDate = dt.ToString("dd MMMM yyyy H:mm:ss");
            return expDate;
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}