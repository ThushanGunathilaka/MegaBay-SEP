﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        //[TestMethod]
        //public void TestMethod1()
        //{
        //    localhost. service = new localhost();
        //    //string saveSubscriber(String username, String email)
        //    String output = service.saveSubscriber("admin", "thushan.ddtmg@gmail.com");
        //    Assert.AreEqual("You are already subscribed to our mailing list.", output);
        //}


        [TestMethod()]
        [HostType("ASP.NET")]
       // [AspNetDevelopmentServerHost("C:\\Users\\thushan1\\Desktop\\SEP", "\\App_Code")]
       // [UrlToTest("")]
        [Microsoft.VisualStudio.TestTools.UnitTesting.Web.AspNetDevelopmentServer("HelloWorldServer", @"C:\\Users\\thushan1\\Desktop\\SEP")]
        public void HelloWorldTest()
        {
            //ServiceReference1.WebServiceSoapChannel targert = new ServiceReference1.WebServiceSoapClient();
            //WebCustomControl1 x = new WebCustomControl1();
           // IServiceProvider x = new IServiceProvider();
            WebService webService = new WebService();
       
            //string i = webService.

            //Assert.IsTrue(WebServiceHelper.TryUrlRedirection
            //            (
            //             webService,
            //             ,
            //             "HelloWorldServer"
            //            ),
            //      "Web service redirection failed."
            //      );
            //ServiceReference1.WebServiceSoap target = new ServiceReference1.WebServiceSoap();
            //string x = webService.GetRecentsResponse();
            //Assert.IsTrue(WebServiceHelper.TryUrlRedirection
            //                    (
            //                     target,
            //                     testContextInstance,
            //                     "HelloWorldServer"
            //                    ),
            //              "Web service redirection failed."
            //              );

            string expected = "Hello World";
            string actual;

         

            Assert.AreEqual(
                            expected,
                            actual,
                            "TestProject1.localhost.HelloWorldService.HelloWorld did not return the expected value."
                            );
        }
    }
}
