﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        int selec = DropDownList1.SelectedIndex;
        String selVal = "";

        if (selec == 0)
            selVal = "PID";
        else if (selec == 1)
            selVal = "pname";
        else if (selec == 2)
            selVal = "company";
        else if (selec == 3)
            selVal = "dealID";

        String search = TextBox4.Text;

        DataSet ds = dba.searchDeal(search, selVal);
        GridView1.DataSource = ds.Tables[0].DefaultView;
        GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        String id = TextBox1.Text;
        //Debug.WriteLine(id);
        int stat = dba.removeDeals(id);
        if (stat > 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Deal successfully Removed \")</SCRIPT>");
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            Button3_Click(this, e);
        }
        else if (stat == 0)
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Select a valid item to remove\")</SCRIPT>");
        else
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Unsuccessfull !\")</SCRIPT>");
    
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        String id = TextBox1.Text;
        //Debug.WriteLine(id);
        String disc = TextBox2.Text;
        String deal = TextBox3.Text;
        if (id != "")
        {
            if (dba.insertDeals(id, disc, deal) >= 0)
            {
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Deal successfully added.  \")</SCRIPT>");
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                Button3_Click(this, e);
            }
            else
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Deal Already given !\")</SCRIPT>");
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Please select a product\")</SCRIPT>");          
        }
    
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        String id = GridView1.SelectedRow.Cells[0].Text;
        TextBox1.Text = id;
        DataSet ds = dba.getDealDisc(id);
        int rowCount = ds.Tables[0].Rows.Count;
        if (rowCount == 0)
        {
            TextBox2.Text = "0";
        }
        else
        {
            TextBox2.Text = ds.Tables[0].Rows[0][2].ToString();
            TextBox3.Text = ds.Tables[0].Rows[0][3].ToString();
        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}