﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    Bidding bidding = new Bidding();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //fill the gridview with not expire promotions products
            bidding.BindGridViewForBidList(GridView1);
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //Identify button with commandArgument
        Button btn = (Button)sender;
        String pid = btn.CommandArgument.ToString();
        Session["promoClick"] = pid;
        Response.Redirect("VwBidItem.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}