﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    AddGiftcard giftcard = new AddGiftcard();

    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //check ithems are not equal to default ones
        if (DropDownList_category.SelectedItem.ToString() != "-Select-" && int.Parse(DropDownList_price.SelectedItem.ToString()) != 0 && TextBox_qty.Text != "0" && FileUpload1.PostedFile.InputStream != null)
        {
            try
            {
                giftcard.Category = DropDownList_category.SelectedItem.ToString();
                giftcard.Price = int.Parse(DropDownList_price.SelectedItem.ToString());
                giftcard.Quantity = int.Parse(TextBox_qty.Text);

                //creating byte array and store binary values
                byte[] image;
                Stream s = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(s);
                image = br.ReadBytes((Int32)s.Length);
                giftcard.Image = image;
                
                if (giftcard.Quantity >= 0)
                {
                    //inserting values to da through calling the method
                    if (dba.insertgiftcerds(giftcard.Category, giftcard.Price, giftcard.Quantity, giftcard.Image) >= 0)
                    {
                        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Gift Card successfully Added \")</SCRIPT>");
                        DropDownList_category.SelectedValue = "-Select-";
                        DropDownList_price.SelectedValue = "0";
                        TextBox_qty.Text = " ";
                    }
                    else
                    {
                        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error \")</SCRIPT>");
                        DropDownList_category.SelectedValue = "-Select-";
                        DropDownList_price.SelectedValue = "0";
                        TextBox_qty.Text = " ";
                    }
                }
                else
                {
                    System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter Quantity is greater than zero \")</SCRIPT>");
                    DropDownList_category.SelectedValue = "-Select-";
                    DropDownList_price.SelectedValue = "0";
                    TextBox_qty.Text = " ";
                }
            }
            catch (Exception)
            {
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a valid inputs \")</SCRIPT>");
                DropDownList_category.SelectedValue = "-Select-";
                DropDownList_price.SelectedValue = "0";
                TextBox_qty.Text = " ";
            }
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter valid values for Filds \")</SCRIPT>");
            DropDownList_category.SelectedValue = "-Select-";
            DropDownList_price.SelectedValue = "0";
            TextBox_qty.Text = " ";
        }
    }
    protected void Calendar_end_SelectionChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox_qty_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList_price_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}