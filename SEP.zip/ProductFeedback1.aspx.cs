﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Diagnostics;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();

    protected void Page_Load(object sender, EventArgs e)
    {
        Label15.Text = "0";
        Label4.Text = "0";
        Label16.Text = "0";

        //int prId = (int)Session["pid_fdb"];
        int prId = 1; /////

        DataSet ds = dba.viewProdFeedbak(prId);
        int rowCount = ds.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount; i++)
        {
            int rate = (int)ds.Tables[0].Rows[i][0];
            if (rate == 1)
                Label15.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 2)
                Label4.Text = ds.Tables[0].Rows[i][1].ToString();
            else if (rate == 3)
                Label16.Text = ds.Tables[0].Rows[i][1].ToString();
        }


        DataSet ds2 = dba.getProdFeed(prId);
        /*int rowCount2 = ds.Tables[0].Rows.Count;

        for (int i = 0; i < rowCount2; i++)
        {
            if (ds2.Tables[0].Rows[i][0].ToString() == "1")
                ds2.Tables[0].Rows[i][0] = 4;

            else if (ds2.Tables[0].Rows[i][0].ToString() == "2")
                ds2.Tables[0].Rows[i][0] = 5;

            else if (ds2.Tables[0].Rows[i][0].ToString() == "3")
                ds2.Tables[0].Rows[i][0] = 6;
        }*/
        GridView1.DataSource = ds2.Tables[0].DefaultView;
        GridView1.DataBind();

        int c = GridView1.Rows.Count;
        for (int i = 0; i < c; i++)
        {
            if (GridView1.Rows[i].Cells[0].Text == "1")
                GridView1.Rows[i].Cells[0].Text = "Positive";

            else if (GridView1.Rows[i].Cells[0].Text == "2")
                GridView1.Rows[i].Cells[0].Text = "Neutral";

            else if (GridView1.Rows[i].Cells[0].Text == "3")
                GridView1.Rows[i].Cells[0].Text = "Negative";
        }
            

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ProductFeedback ProB = new ProductFeedback();

        if (RadioButton1.Checked)
            ProB.Pro_rating = 1;
        else if (RadioButton2.Checked)
            ProB.Pro_rating = 2;
        else if (RadioButton3.Checked)
            ProB.Pro_rating = 3;
        else
            ProB.Pro_rating = 0;



        ProB.Pro_feedback = TextBox1.Text;

        if (ProB.Pro_feedback == "" || ProB.Pro_rating == 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter all \")</SCRIPT>");
            ////TextBox1.Text = "hhh";

            //if(feedB.Rating == 1)
            //  RadioButton1.
        }
        else
        {
            
            //ProB.CusID = (int)Session["pid_fdb"];
            ProB.CusID = 1;//////////
            

           
            ///ProB.PID1 = (int)Session["pid_fdb"];
            ProB.PID1 = 1; ///////////

            //db_access dba = new db_access();
            if (dba.insertProductFeedbak(ProB) >= 0)
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Feedback successfully added. \")</SCRIPT>");
            else
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error ! \")</SCRIPT>");

            TextBox1.Text = "";
            RadioButton1.Checked = false;
            RadioButton2.Checked = false;
            RadioButton3.Checked = false;
            Page_Load(this, e);
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {

    }
}