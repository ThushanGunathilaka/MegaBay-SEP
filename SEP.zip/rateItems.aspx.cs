﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class rateItems : System.Web.UI.Page
{
    protected List<String> list;

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void GridView1_SelectedIndexChanged2(object sender, EventArgs e)
    {
        list = new List<string>();
        list.Add(GridView1.SelectedRow.Cells[1].Text.ToString());
        list.Add(GridView1.SelectedRow.Cells[2].Text.ToString());
        list.Add(GridView1.SelectedRow.Cells[3].Text.ToString());
     //   list.Add(GridView1.SelectedRow.Cells[4].Text.ToString());
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try {
            list = new List<string>();
            list.Add(GridView1.SelectedRow.Cells[1].Text.ToString());
            list.Add(GridView1.SelectedRow.Cells[2].Text.ToString());
            list.Add(GridView1.SelectedRow.Cells[3].Text.ToString());
          //  list.Add(GridView1.SelectedRow.Cells[4].Text.ToString());
        }
        catch (Exception me) { }


        String v = DropDownList1.SelectedItem.Value.ToString();
        if (v != null && list != null && v.Trim().CompareTo("") != 0 )
        {
            string insertQuery = "insert into ProductRated (productName,rate,date,price) values (@productName,@rate,@date,@price)";
            System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

            SqlCommand com = new SqlCommand(insertQuery, sqlConnection);

            com.Parameters.AddWithValue("@productName", list[0]);
            com.Parameters.AddWithValue("@rate", v);
            com.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            com.Parameters.AddWithValue("@price", list[1]);
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Rating added successfully" + "');", true);

            try
            {
                sqlConnection.Open();
                com.ExecuteNonQuery();
             
            }
            catch (Exception es)
            {
              //  Response.Write(es.Message);
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Error Occurred" + "');", true);

            }

            sqlConnection.Close();
        }
        else {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Error Occured! Make necessary selections to save the rating details" + "');", true);

        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewRatedItems.aspx");
    }
}