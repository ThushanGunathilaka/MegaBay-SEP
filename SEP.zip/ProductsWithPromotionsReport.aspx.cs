﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    ReportMethods reportMethods = new ReportMethods();
    DataTable ProductsWithPromotions_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsWithPromotionsRpt.rdlc");
            ProductsWithPromotions_dt = reportMethods.GetProductsWithPromotions();
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsWithPromotions";
            source1.Value = ProductsWithPromotions_dt;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(source1);
            ReportViewer1.LocalReport.Refresh();

        }
    }
}