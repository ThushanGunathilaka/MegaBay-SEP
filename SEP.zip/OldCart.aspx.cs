﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click1(object sender, EventArgs e)
    {
        string EmarketingConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename='C:\Users\USER\Desktop\thushan did\sep project\iteration1_V2\Eportal_V1.6\App_Data\Database.mdf';Integrated Security=True";
        SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);
        conn1.Open();

        string sql = "Delete from ShoppingCart where CusId=1";        

        SqlCommand cmmnd = new SqlCommand(sql, conn1);
        cmmnd.CommandType = CommandType.Text;
        cmmnd.ExecuteNonQuery();

        Response.Redirect("OldCart.aspx");
        Label2.Text = "Cart History cleared!!!";
        
    }
}