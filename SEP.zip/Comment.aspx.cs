﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    db_access dba = new db_access();
    int UId = 4;
    int PId = 12;

    //prodId = Session["pid"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        //fill the gridview with given product
        dba.BindGridpro_comment(GridView3,PId);

        //lable5 is clear
        Label5.Text = "0";

        //get the likes count and display like count in the lable
        DataSet ds = dba.getProLikes(PId);
        int rowCount = ds.Tables[0].Rows.Count;
        Label5.Text = rowCount.ToString();

        //paticulr user with paticular product get that and color the like button
        DataSet ds1 = dba.getProLikes_color(PId, UId);
        int rowCount1 = ds1.Tables[0].Rows.Count;
        
        if (rowCount1 >= 1)
        {
            ImageButton1.ImageUrl = "~/images/like2.JPG";
        }
        else
        {
            ImageButton1.ImageUrl = "~/images/like1.JPG";
        }

        //get the comments and display comments on gridview
        DataSet ds2 = dba.viewProComment(PId);
        GridView2.DataSource = ds2.Tables[0].DefaultView;
        GridView2.DataBind();

        //check pid and uid and get comment and dipaly "delete my comment" button
        DataSet ds3 = dba.displaycommbutton(PId, UId);
        int row = ds3.Tables[0].Rows.Count;

        if (row >= 1)
        {
            Button2.Visible = true;
        }
        else
        {
            Button2.Visible = false;
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Comment com = new Comment();

        //set textbox value to the column called Comment_des 
        com.Comment_des = TextBox1.Text;
        
        if (com.Comment_des == " ")
            {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a comment \")</SCRIPT>");
            }
        else
            {
                com.UId = 4;
                com.PId = 12;

                if (dba.insertcomment(com) >= 0)
                {
                    System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Comment successfully added. \")</SCRIPT>");
                    //diplay the "delete my comment" button
                    Button2.Visible = true;
                }
                else
                {
                    System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error ! \")</SCRIPT>");
                }
            }
        TextBox1.Text = "";
        Page_Load(this, e);
    }


    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Like1 li = new Like1();
           
        li.Count = 1;
        li.UId = 4;
        li.PId = 12;
    
        if (li.Count == -1 || li.UId == -1 || li.PId == -1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Enter a Like \")</SCRIPT>");
        }
        else
        {
            //check the like count 
            DataSet ds = dba.checkuid(li.UId,li.PId);
            int rowCount = ds.Tables[0].Rows.Count;

            if (rowCount >= 1)
            {
                    dba.dislike(li.UId);
                    ImageButton1.ImageUrl = "~/images/like1.JPG";
                    //ImageButton imgButton1 = sender as ImageButton;
                    //imgButton1.ImageUrl = "~/images/like1.JPG";
            }
            else if (rowCount == 0)
            {
                    dba.insertlike(li);
                    ImageButton1.ImageUrl = "~/images/like2.JPG";
            }
        }
         Page_Load(this, e);
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        //remove comment from paticular user
        int comm = dba.removecomment(UId);
        if (comm >= 1)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Comment successfully Removed \")</SCRIPT>");
            TextBox1.Text = "";
            Button2.Visible = false;
        }
        else if (comm == 0)
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Select a valid item to remove\")</SCRIPT>");
        }
        else
        {
            System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"JavaScript\"> alert(\"Error !\")</SCRIPT>");
        }
        Page_Load(this, e);
    }


    protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}
