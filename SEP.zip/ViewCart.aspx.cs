﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblEmpty.Visible = true;
        if (Session["total"] == null)
        {
            Button2.Visible = false;
            Button3.Visible = false;
            Label12.Visible = false;
            Label13.Visible = false;
            Label14.Visible = false;
            Label15.Visible = false;
            Label17.Visible = false;
            Button4.Visible = false;
        }
        //Load items in cart//////////////////////////////////////////////////////////////
        if (Session["throw"] != null)
        {
            TableRow trow = new TableRow();
            trow = (TableRow)Session["throw"];
            Table1.Rows.Add(trow);

            Button btn = new Button();
            btn = (Button)Session["btn"];
            btn.Click += new System.EventHandler(this.button_Click);
        }
        

        if (Session["throw2"] != null)
        {
            TableRow trow2 = new TableRow();
            trow2 = (TableRow)Session["throw2"];
            Table1.Rows.Add(trow2);

            Button btn1 = new Button();
            btn1 = (Button)Session["btn1"];
            btn1.Click += new System.EventHandler(this.button1_Click);
        }

        if (Session["throw3"] != null)
        {
            TableRow trow2 = new TableRow();
            trow2 = (TableRow)Session["throw3"];
            Table1.Rows.Add(trow2);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn3"];
            btn3.Click += new System.EventHandler(this.button3_Click);
        }

        if (Session["throw4"] != null)
        {
            TableRow trow4 = new TableRow();
            trow4 = (TableRow)Session["throw4"];
            Table1.Rows.Add(trow4);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn4"];
            btn3.Click += new System.EventHandler(this.button4_Click);
        }

        if (Session["throw5"] != null)
        {
            TableRow trow5 = new TableRow();
            trow5 = (TableRow)Session["throw5"];
            Table1.Rows.Add(trow5);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn5"];
            btn3.Click += new System.EventHandler(this.button5_Click);
        }
        if (Session["throw6"] != null)
        {
            TableRow trow5 = new TableRow();
            trow5 = (TableRow)Session["throw6"];
            Table1.Rows.Add(trow5);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn6"];
            btn3.Click += new System.EventHandler(this.button6_Click);
        }

        if (Session["throw7"] != null)
        {
            TableRow trow5 = new TableRow();
            trow5 = (TableRow)Session["throw7"];
            Table1.Rows.Add(trow5);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn7"];
            btn3.Click += new System.EventHandler(this.button7_Click);
        }
        if (Session["throw8"] != null)
        {
            TableRow trow5 = new TableRow();
            trow5 = (TableRow)Session["throw8"];
            Table1.Rows.Add(trow5);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn8"];
            btn3.Click += new System.EventHandler(this.button8_Click);
        }

        if (Session["throw9"] != null)
        {
            TableRow trow5 = new TableRow();
            trow5 = (TableRow)Session["throw9"];
            Table1.Rows.Add(trow5);

            Button btn3 = new Button();
            btn3 = (Button)Session["btn9"];
            btn3.Click += new System.EventHandler(this.button9_Click);
        }


        if (Session["total"] != null)
        {
            double tot = Convert.ToDouble(Session["total"]);
            lbltotal.Text = Session["total"].ToString();
            Button2.Visible = true;
            Button3.Visible = true;
            Button4.Visible = true;
            lblEmpty.Visible = false;
        }
        
        
    }

    double newTot = 0.0;
    //button click event for dynamically created buttons/////////////////////////////////////////////////////
    protected void button1_Click(object sender, EventArgs e)
    {
        Session["throw2"] = null;
        Session["name2"] = null;
        Session["image2"] = null;
        Session["btn1"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price2"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price2"];
        Session["price2"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
        
    }

    protected void button3_Click(object sender, EventArgs e)
    {
        Session["throw3"] = null;
        Session["name3"] = null;
        Session["image3"] = null;
        Session["btn3"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price3"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price3"];
        Session["price3"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }

    protected void button4_Click(object sender, EventArgs e)
    {
        Session["throw4"] = null;
        Session["name4"] = null;
        Session["image4"] = null;
        Session["btn4"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price4"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price4"];
        Session["price4"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }
    protected void button5_Click(object sender, EventArgs e)
    {
        Session["throw5"] = null;
        Session["name5"] = null;
        Session["image5"] = null;
        Session["btn5"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price5"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price5"];
        Session["price5"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }
    protected void button6_Click(object sender, EventArgs e)
    {
        Session["throw6"] = null;
        Session["name6"] = null;
        Session["image6"] = null;
        Session["btn6"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price6"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price6"];
        Session["price6"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }
    protected void button7_Click(object sender, EventArgs e)
    {
        Session["throw7"] = null;
        Session["name7"] = null;
        Session["image7"] = null;
        Session["btn7"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price7"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price7"];
        Session["price7"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }
    protected void button8_Click(object sender, EventArgs e)
    {
        Session["throw8"] = null;
        Session["name8"] = null;
        Session["image8"] = null;
        Session["btn8"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price8"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price8"];
        Session["price8"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }
    protected void button9_Click(object sender, EventArgs e)
    {
        Session["throw9"] = null;
        Session["name9"] = null;
        Session["image9"] = null;
        Session["btn9"] = null;

        newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price9"]);
        Session["total"] = newTot;
        Session["diduction"] = Session["price9"];
        Session["price9"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
    }

    protected void button_Click(object sender, EventArgs e)
    {
        Session["throw"] = null;        
        Session["name"] = null;        
        Session["image"] = null;
        Session["btn"] = null;
        
         newTot = Convert.ToDouble(Session["total"]) - Convert.ToDouble(Session["price"]);        
        Session["total"] = newTot;
        Session["diduction"] = Session["price"];
        Session["price"] = null;
        lbltotal.Text = Session["total"].ToString();
        Response.Redirect("ViewCart.aspx");
        
        
    }
    //Code for save shopping cart/////////////////////////////////////////////////////////////////////
    protected void Button2_Click1(object sender, EventArgs e)
    {
        if (Session["CusID"] == null)
        {
            Response.Redirect("Login.aspx");
        }
        string EmarketingConnectionString = @"Data Source=SQL5016.myASP.NET;Initial Catalog=DB_9CC2E0_Megabay;User Id=DB_9CC2E0_Megabay_admin;Password=qwe123asd";
        SqlConnection conn1 = new SqlConnection(EmarketingConnectionString);
        conn1.Open();

        string sql = "";
        int count = Table1.Rows.Count;
        for (int i = 0; i < count; i++)
        {

            sql = sql + "insert into ShoppingCart (ItemName, quantity,Item_price,CusId,date,Total_price) values('"
                //+ (string)Table1.Rows[i].Cells[0].Text + "','"
                  + Table1.Rows[i].Cells[1].Text + "','"
                  + Table1.Rows[i].Cells[3].Text + "','"
                  + Table1.Rows[i].Cells[2].Text + "','"
                  + Convert.ToInt32(Session["CusID"].ToString())+ "','"
                  + DateTime.Now + "','"
                  +lbltotal.Text + "')";

            SqlCommand cmmnd = new SqlCommand(sql, conn1);
            cmmnd.CommandType = CommandType.Text;
            cmmnd.ExecuteNonQuery();
        }
        lblres.Text = "Cart Saved!!!";
        
    }
    //code for clear cart button////////////////////////////////////////////
    protected void Button3_Click1(object sender, EventArgs e)
    {
        Session.Clear(); 
        Response.Redirect("Home.aspx");
    }
    protected void Button4_Click1(object sender, EventArgs e)
    {
         if (Session["CusID"] == null)
        {
            Response.Redirect("Login.aspx");
        }       
        Response.Redirect("OldCart.aspx");
    }
    protected void Button5_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Wishlist_Added.aspx");
    }
}


