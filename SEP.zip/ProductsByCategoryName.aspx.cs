﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class Default3 : System.Web.UI.Page
{
    ReportMethods reportMethods = new ReportMethods();
    DataTable ProductsByCatName_dt;
    protected void Page_Load(object sender, EventArgs e)
    {
       // ddlCategory.SelectedItem = ddlCategory.Items[0];
        //if (!IsPostBack)
        //{
        //    string catName = ddlCategory.SelectedItem.ToString();
        //    ReportViewer1.ProcessingMode = ProcessingMode.Local;
        //    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsByCategoryName.rdlc");
        //    ProductsByCatName_dt = reportMethods.GetProductsByCategory("Fashion");
        //    ReportDataSource source1 = new ReportDataSource();
        //    source1.Name = "DsProductsByCategoryName";
        //    source1.Value = ProductsByCatName_dt;
        //    ReportViewer1.LocalReport.DataSources.Clear();
        //    ReportViewer1.LocalReport.DataSources.Add(source1);
        //    ReportViewer1.LocalReport.Refresh();

        //}
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        {
            string catName = ddlCategory.SelectedItem.ToString();
            rpvProductsByCatName.ProcessingMode = ProcessingMode.Local;
            rpvProductsByCatName.LocalReport.ReportPath = Server.MapPath("~/Reports/ProductsByCategoryName.rdlc");
            ProductsByCatName_dt = reportMethods.GetProductsByCategory(catName);
            ReportDataSource source1 = new ReportDataSource();
            source1.Name = "DsProductsByCategoryName";
            source1.Value = ProductsByCatName_dt;
            rpvProductsByCatName.LocalReport.DataSources.Clear();
            rpvProductsByCatName.LocalReport.DataSources.Add(source1);
            rpvProductsByCatName.LocalReport.Refresh();

        }
    }
}