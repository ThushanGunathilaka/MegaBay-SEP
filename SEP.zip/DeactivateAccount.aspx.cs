﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class DeactivateAccount : System.Web.UI.Page
{
    protected string name = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        name = Session["New"].ToString();
        TextBoxusernameD.Text = name;
        TextBoxusernameD.Enabled = false;

        Session["message"] = "";

    }
    protected void Buttondeactivate_Click(object sender, EventArgs e)
    {
        
        string password = "";
        string check = TextBoxpasswordD.Text;
        Boolean compare = false;

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["EportalConnectionString"].ConnectionString);

        string cmdText = "SELECT * FROM ECustomer where username =\'" + name + "\'";
       // Response.Write(cmdText);
       
        
        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(cmdText, con);

        if (con.State == System.Data.ConnectionState.Closed)
        {
            con.Open();
        }


        System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                password = dr["password"].ToString().Trim();
            }
        }

        con.Close();

        if (password.CompareTo(check) == 0) {
            compare = true;
        }


        if (compare)
        {
            string move = "INSERT INTO IECustomer (CusID,username,Fname,Lname,password,registered_date,activeStatus,email,rating,fbaccount) SELECT CusID,username,Fname,Lname,password,registered_date,activeStatus,email,rating,fbaccount FROM ECustomer WHERE username = \'" + name + "\'";
             
            cmd = new SqlCommand(move, con);
              
            int updated = 0;
          
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                try
                {
                    updated = cmd.ExecuteNonQuery();
                }
                catch (Exception se) { }

                con.Close();

                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
            
                string deleteSQL;
                deleteSQL = "DELETE FROM ECustomer WHERE username=\'"+ name +"\'";
          //      Response.Write(deleteSQL);
                cmd = new SqlCommand(deleteSQL, con);


                int deleted = 0;
                try
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    deleted = cmd.ExecuteNonQuery();
                    Session["message"] = "Account Deactivated";
                  //  Response.Redirect("Home.aspx");

                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Account Deactivated" + "');", true);
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert1", " document.getElementById(\"<%= buttonlogin.ClientID %>\").value = \"Login\"; $('#accountlink').hide(); $('#a').hide(); $('#b').hide(); $('#d').hide();", false);
                    Session["New"] = "";
                    Response.Redirect("Home.aspx");

                }
                catch (Exception err)
                {
                    
                    Response.Write(err.Message);
                }
                finally
                {
                    con.Close();
                }


        }
        else {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" +"Incorrect passwords" + "');", true);
        }
    
       
    }

 
}